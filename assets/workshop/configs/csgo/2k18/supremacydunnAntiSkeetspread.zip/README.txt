 All Sales are final, no refunds are given. 
 Leak will result in a ban from iwebz and, ofc, supremacy.
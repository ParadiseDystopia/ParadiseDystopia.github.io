UI.AddLabel("Spin AA");
UI.AddCheckbox("Enable Spin AA");
UI.AddSliderInt("Spin Step", 1, 80);
var ogYaw = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset");
spinYaw = 0;

function appmain() {
    var scriptitems = ["Misc", "JAVASCRIPT", "Script Items"];
    var enabled = UI.GetValue(scriptitems, "Enable Spin AA");
    var spinStep = UI.GetValue(scriptitems, "Spin Step");
    if (enabled) {
        if (spinYaw >= 180) {
            spinYaw = -180;
        }
        setYaw(spinYaw);
        spinYaw += spinStep;
    }
}

function setYaw(yawVal) {
    UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", yawVal);
}

function onUnload() {
    setYaw(ogYaw);
}

Cheat.RegisterCallback("CreateMove", "appmain");
Cheat.RegisterCallback("Unload", "onUnload");
// estamaloka

var local_state = 0;
var velocity;
var isInversed;
var inversedBodyLean;
var bodyLeanState = 0;

function main()
{
UI.AddLabel("           Default/Air/Micromove");
	UI.AddSliderInt("Default or Air Inversed body lean", 0, 100);
    UI.AddSliderInt("Default or Air Body lean", 0, 100);
	UI.AddSliderInt("Default or Air Choke Limit", 0, 16);
UI.AddLabel("           Running");
	UI.AddSliderInt("Running Inversed body lean", 0, 100);
    UI.AddSliderInt("Running Body lean", 0, 100);
	UI.AddSliderInt("Running Choke Limit", 0, 16);
UI.AddLabel("           Slow Motion");
	UI.AddSliderInt("Slow Walk Inversed body lean", 0, 100);
    UI.AddSliderInt("Slow Walk Body lean", 0, 100);
	UI.AddSliderInt("Slow Walk Choke Limit", 0, 16);
}
main()

function get_velocity()
{
  var localplayer_index = Entity.GetLocalPlayer();
  getvelocity = Entity.GetProp(localplayer_index, "CBasePlayer", "m_vecVelocity[0]");
  velocity = Math.floor(Math.min(9999, Math.sqrt(getvelocity[0] * getvelocity[0] + getvelocity[1] * getvelocity[1]) + 0.2))

    if (velocity < 5) {
		local_state = 1;
		UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Default or Air Choke Limit") ) 
	}
	if (velocity > 5) {

		if (UI.IsHotkeyActive("Anti-Aim", "Extra", "Slow walk")) {
			local_state = 2;
					UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Slow Walk Choke Limit") ) 
		}
		else {
			local_state = 3;
				UI.SetValue("Anti-Aim", "Fake-Lag", "Limit", UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Running Choke Limit") ) 
		}
	}
		 
}


function calculated_bodylean() {
	 isInversed = UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter");
	freestanding = UI.GetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction");
	
	 if (isInversed == 0) {
        if (local_state == 1) {
		bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Default or Air Body lean")));
	}
	 if (local_state == 2) {
        bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Slow Walk Body lean")));
		}
	 if (local_state == 3) {
		bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Running Body lean")));
		}
	 }
	 if (isInversed == 1) {
		 if (local_state == 1) {
		bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Default or Air Inversed body lean")));
	}
	 if (local_state == 2) {
        bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Slow Walk Inversed body lean")));
		}
	 if (local_state == 3) {
		bodyLeanState = 59 - Math.floor((0.59 * UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Running Inversed body lean")));
		}
	 }
	 
}

function set_calculated_bodylean() {
	UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Yaw offset", bodyLeanState);
	UI.SetValue("Anti-Aim", "Rage Anti-Aim", "Auto direction", 0);
	UI.SetValue("Anti-Aim", "Fake Angles", "LBY mode", 1);
	UI.SetValue("Anti-Aim", "Fake Angles", "At targets", UI.GetValue("MISC", "JAVASCRIPT", "Script items", "Yaw Base"));
}


Cheat.RegisterCallback("Draw", "calculated_bodylean");
Cheat.RegisterCallback("Draw", "set_calculated_bodylean");
Cheat.RegisterCallback("Draw", "get_velocity");
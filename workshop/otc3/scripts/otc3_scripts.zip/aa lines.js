UI.AddLabel("            -----AA Lines-----");
UI.AddSliderInt("Length", 1, 200);
UI.AddCheckbox("Use Head Distance");
UI.AddColorPicker("Fake Head");
UI.AddColorPicker("Head");
UI.AddColorPicker("Real");
UI.AddColorPicker("Fake");
UI.AddColorPicker("LBY");
UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Fake Head", [255,136,0,255]);
UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Fake", [255,0,0,255]);
UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Real", [0,255,0,255]);
UI.SetColor("Misc", "JAVASCRIPT", "Script items", "Head", [0,0,255,255]);
UI.SetColor("Misc", "JAVASCRIPT", "Script items", "LBY", [255,0,255,255]);
UI.AddLabel("         --------------------------");

function getVector(yaw){
    
    local = Entity.GetLocalPlayer();
    base_pos = Entity.GetRenderOrigin(local);
    
    x1 = base_pos[0];
    y1 = base_pos[1];
    
    x2 = getUIVal("Length") * Math.cos(yaw * (Math.PI/180)) + x1;
    y2 = getUIVal("Length") * Math.sin(yaw * (Math.PI/180)) + y1;
    z = base_pos[2];
    
    inter = Render.WorldToScreen([x2,y2,z]);
    
    return inter.concat([x2, y2]);
    
}

function getAngle(vert ,p1, p2){
    
    theta = Math.atan2(p2[1] - vert[1], p2[0] - vert[0]) - Math.atan2(p1[1] - vert[1], p1[0] - vert[0]);
    return theta * (180/Math.PI);
    
}

function getUIVal(str){
    return UI.GetValue("Misc", "JAVASCRIPT", "Script items", str);
}

function getColor(str){
    return UI.GetColor("Misc", "JAVASCRIPT", "Script items", str);
}

function isRifle(){
    
    local = Entity.GetLocalPlayer();
    local_weapon = Entity.GetWeapon(local);
    weapon_name = Entity.GetName(local_weapon);
    
    if((weapon_name === "ak 47" || weapon_name === "aug" || weapon_name === "famas" || weapon_name === "galil ar" || weapon_name === "m4a1 s" || weapon_name === "m4a4" || weapon_name === "sg 553" || weapon_name === "awp" || weapon_name === "scar 20" || weapon_name === "g3sg1" || weapon_name === "ssg 08")) return true
    
}

function draw(){
    
    if(!Entity.GetLocalPlayer( ) || !Entity.IsAlive( Entity.GetLocalPlayer( ) ) || !Entity.IsValid( Entity.GetLocalPlayer( ) )) return;
    
    local = Entity.GetLocalPlayer();
    base_world_pos = Entity.GetRenderOrigin(local);
    base_pos1 = Render.WorldToScreen(base_world_pos);
    
    fake1 = getVector(Local.GetFakeYaw());
    real1 = getVector(Local.GetRealYaw());
    lby1 = getVector(Entity.GetProp(local, "DT_CSPlayer", "m_flLowerBodyYawTarget"));
    if(Math.abs(fake1[0] - lby1[0]) < 10) draw_lby = false;
    else draw_lby = true;
    
    head_pos = Entity.GetHitboxPosition(local, 0);
    
    vertex = [base_world_pos[0], base_world_pos[1]];
    point1 = [real1[3], real1[4]];
    point2 = [head_pos[0], head_pos[1]];
    head_offset = getAngle(vertex, point1, point2);
    
    if(getUIVal("Use Head Distance")) head1 = Render.WorldToScreen([head_pos[0], head_pos[1], base_world_pos[2]]);
    else head1 = getVector(Local.GetRealYaw() + head_offset);
    
    fhead1 = getVector(Local.GetFakeYaw() - head_offset);
    
    real2fake = Math.abs(Local.GetRealYaw() - Local.GetFakeYaw());
    if(( (real2fake >= 117 && real2fake <= 123) || (real2fake >= 237 && real2fake <= 243) ) && isRifle()) extend = true;
    else extend = false;
    
    fh = "FAKE HEAD";
    h = "HEAD";
    r = "REAL";
    f = "FAKE";
    l = "LBY";
    
    if(extend) Render.Line(base_pos1[0], base_pos1[1], fhead1[0], fhead1[1], getColor("Fake Head"));
    if(draw_lby) Render.Line(base_pos1[0], base_pos1[1], lby1[0], lby1[1], getColor("LBY")); //KJNF:JLNESPINFNSLKNES LBY
    Render.Line(base_pos1[0], base_pos1[1], head1[0], head1[1], getColor("Head"));
    Render.Line(base_pos1[0], base_pos1[1], fake1[0], fake1[1], getColor("Fake"));
    Render.Line(base_pos1[0], base_pos1[1], real1[0], real1[1], getColor("Real"));
    
    Render.String( fake1[0] - 9, fake1[1] + 11, 0, f, [0,0,0,getColor("Fake")[3]], 3 );
    Render.String( real1[0] - 9, real1[1] + 11, 0, r, [0,0,0,getColor("Real")[3]], 3 );
    Render.String( head1[0] - 9, head1[1] + 11, 0, h, [0,0,0,getColor("Head")[3]], 3 );
    if(draw_lby) Render.String( lby1[0] - 9, lby1[1] + 11, 0, l, [0,0,0,getColor("LBY")[3]], 3 );
    if(extend) Render.String( fhead1[0] - 9, fhead1[1] + 11, 0, fh, [0,0,0,getColor("Fake Head")[3]], 3 );
    
    if(draw_lby) Render.String( lby1[0] - 10, lby1[1] + 10, 0, l, getColor("LBY"), 3 );
    Render.String( fake1[0] - 10, fake1[1] + 10, 0, f, getColor("Fake"), 3 );
    Render.String( real1[0] - 10, real1[1] + 10, 0, r, getColor("Real"), 3 );
    Render.String( head1[0] - 10, head1[1] + 10, 0, h, getColor("Head"), 3 );
    if(extend) Render.String( fhead1[0] - 10, fhead1[1] + 10, 0, fh, getColor("Fake Head"), 3 );
    
}

Cheat.RegisterCallback("Draw", "draw");
UI.AddCheckbox("Insta break")
UI.AddCheckbox("Fake-lag break")
var last = 0
var teste = 0
var wait = 0
var lasthotkey = false
var hotkey = false
function test(){
    if(!UI.GetValue("Insta Break"))
    var a = Entity.GetProp(Entity.GetLocalPlayer(),"DT_BasePlayer","m_vecVelocity[0]")
    last = teste
    teste = Math.sqrt(Math.pow(a[0],2) +Math.pow(a[1],2) + Math.pow(a[2],2) )
    lasthotkey = hotkey
    hotkey = UI.IsHotkeyActive("Anti-Aim","Fake angles","Inverter")

    if((teste < 65 && last > 65) || (lasthotkey != hotkey)){
        UI.SetValue("Anti-Aim","Yaw offset", hotkey ? -110 : 110)
        if(UI.GetValue("Script Items","Fake-lag break")){
            UI.SetValue("Anti-Aim","Fake-Lag","Enabled",false)
        }
        wait = 3
       
    }
    if(wait <= 0){
    UI.SetValue("Anti-Aim","Yaw offset",0)
    }
    if(wait <= -16 && UI.GetValue("Script Items","Fake-lag break")){
        UI.SetValue("Anti-Aim","Fake-Lag","Enabled",true)
    }
    wait--
}
Cheat.RegisterCallback("CreateMove","test")
function drawString( )
{
	Cheat.Print("zalupes");
AntiAim.SetOverride(1);
AntiAim.SetFakeOffset(12); // <----- This will setup your fake offset.
AntiAim.SetRealOffset(-58);
AntiAim.SetLBYOffset(180);
	Render.String( 500, 500, 0, " " + Local.GetFakeYaw(), [ 255, 255, 255, 255 ] );
	Render.String( 500, 600, 0, " " + Local.GetRealYaw(), [ 255, 255, 255, 255 ] );
}

Cheat.RegisterCallback("Draw", "drawString")
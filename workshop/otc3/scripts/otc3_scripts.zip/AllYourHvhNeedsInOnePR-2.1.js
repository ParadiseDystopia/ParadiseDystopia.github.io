/***************************************************************************/
/*    ALL YOUR HVH NEEDS IN ONE                                                                     */
/*  This is the public version and may not match results of the alpha.*/
/*  For onetap v3              */
/*  Created by Ominous#7262                                         */
/*  Join our discord for updates.                                              */
/*                                                                               */
/* If you purchased this you got scammed!!!!!!! this is a free and public script!!!!    */      
/***************************************************************************/
var _$_68fa=["\x62\x61\x63\x6B","\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x46\x61\x6B\x65\x20\x61\x6E\x67\x6C\x65\x73","\x49\x6E\x76\x65\x72\x74\x65\x72","\x49\x73\x48\x6F\x74\x6B\x65\x79\x41\x63\x74\x69\x76\x65","\x54\x6F\x67\x67\x6C\x65\x48\x6F\x74\x6B\x65\x79","\x4D\x69\x73\x63","\x4A\x41\x56\x41\x53\x43\x52\x49\x50\x54","\x53\x63\x72\x69\x70\x74\x20\x49\x74\x65\x6D\x73","\x41\x75\x74\x6F\x2D\x49\x6E\x76\x65\x72\x74\x65\x72","\x47\x65\x74\x56\x61\x6C\x75\x65","\x67\x65\x74\x49\x6E\x76\x65\x72\x74","\x75\x73\x65\x72\x69\x64","\x47\x65\x74\x49\x6E\x74","\x47\x65\x74\x45\x6E\x74\x69\x74\x79\x46\x72\x6F\x6D\x55\x73\x65\x72\x49\x44","\x47\x65\x74\x4C\x6F\x63\x61\x6C\x50\x6C\x61\x79\x65\x72","\x73\x65\x74\x41\x41\x49\x6E\x76\x65\x72\x74","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6C\x6C\x59\x6F\x75\x72\x48\x76\x68\x4E\x65\x65\x64\x73\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x4C\x61\x62\x65\x6C","\x20\x20\x20\x20\x20\x20\x20\x43\x72\x65\x61\x74\x65\x64\x20\x62\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x20","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x46\x6C\x6F\x61\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x52\x61\x67\x65\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6E\x74\x69\x41\x69\x6D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x59\x61\x77\x20\x4C\x69\x6D\x69\x74","\x59\x61\x77\x20\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x59\x61\x77\x20\x43\x65\x6E\x74\x65\x72","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x46\x61\x6B\x65\x6C\x61\x67\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x55\x70\x70\x65\x72\x20\x41\x6E\x64\x20\x4C\x6F\x77\x65\x72\x20\x4C\x69\x6D\x69\x74","\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x43\x65\x6E\x74\x65\x72\x20\x56\x61\x6C\x75\x65","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x4F\x74\x68\x65\x72\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x43\x68\x65\x63\x6B\x62\x6F\x78","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x54\x65\x73\x74\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x20\x48\x65\x69\x67\x68\x74\x20\x41\x64\x76\x61\x6E\x74\x61\x67\x65","\x5E\x20\x57\x61\x72\x6E\x69\x6E\x67\x20\x74\x68\x69\x73\x20\x64\x69\x73\x61\x62\x6C\x65\x73\x20\x63\x75\x73\x74\x6F\x6D\x20\x61\x61","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x2D\x42\x72\x75\x74\x65\x66\x6F\x72\x63\x65","\x4F\x66\x66","\x4F\x6E\x20\x48\x69\x74","\x4F\x6E\x20\x53\x68\x6F\x74","\x41\x64\x64\x44\x72\x6F\x70\x64\x6F\x77\x6E","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x45\x78\x70\x6C\x6F\x69\x74\x20\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x50\x72\x65\x2D\x41\x6C\x70\x68\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x54\x72\x69\x70\x6C\x65\x2D\x54\x61\x70","\x4F\x6C\x64","\x49\x6D\x70\x72\x6F\x76\x65\x64","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6C\x70\x68\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x44\x6F\x75\x62\x6C\x65\x2D\x54\x61\x70","\x50\x65\x72\x66\x65\x63\x74","\x41\x64\x61\x70\x74\x69\x76\x65","\x53\x63\x75\x66\x66\x65\x64","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x47\x65\x74\x53\x63\x72\x65\x65\x6E\x53\x69\x7A\x65","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x78","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x49\x6E\x74","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x79","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x43\x6F\x6E\x73\x6F\x6C\x65","\x45\x6E\x61\x62\x6C\x65\x20\x56\x69\x73\x75\x61\x6C\x20\x4C\x6F\x67\x73","\x45\x6E\x61\x62\x6C\x65\x20\x43\x6F\x6E\x73\x6F\x6C\x65\x20\x4C\x6F\x67\x73","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x49\x6E\x64\x69\x63\x61\x74\x6F\x72\x73\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x44\x6F\x75\x62\x6C\x65\x74\x61\x70","\x48\x69\x64\x65\x20\x53\x68\x6F\x74\x73","\x46\x61\x6B\x65\x20\x44\x75\x63\x6B","\x20\x20\x20\x20\x20\x20\x20\x43\x72\x65\x61\x74\x65\x64\x20\x42\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4F\x66\x66\x69\x63\x69\x61\x6C\x20\x44\x69\x73\x63\x6F\x72\x64","\x20\x20\x20\x20\x20\x20\x68\x74\x74\x70\x73\x3A\x2F\x2F\x64\x69\x73\x63\x6F\x72\x64\x2E\x67\x67\x2F\x51\x50\x63\x58\x46\x78\x61","\x52\x65\x61\x6C\x74\x69\x6D\x65","\x53\x63\x72\x69\x70\x74\x20\x69\x74\x65\x6D\x73","\x63\x6F\x73","\x52\x61\x67\x65\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x59\x61\x77\x20\x6F\x66\x66\x73\x65\x74","\x53\x65\x74\x56\x61\x6C\x75\x65","\x46\x61\x6B\x65\x2D\x4C\x61\x67","\x4C\x69\x6D\x69\x74","\x50\x49","\x73\x69\x6E","\x73\x71\x72\x74","\x68\x69\x74\x67\x72\x6F\x75\x70","\x43\x75\x72\x74\x69\x6D\x65","\x61\x62\x73","\x78","\x47\x65\x74\x46\x6C\x6F\x61\x74","\x79","\x7A","\x49\x73\x56\x61\x6C\x69\x64","\x49\x73\x45\x6E\x65\x6D\x79","\x49\x73\x44\x6F\x72\x6D\x61\x6E\x74","\x47\x65\x74\x45\x79\x65\x50\x6F\x73\x69\x74\x69\x6F\x6E","\x43\x42\x61\x73\x65\x45\x6E\x74\x69\x74\x79","\x6D\x5F\x76\x65\x63\x4F\x72\x69\x67\x69\x6E","\x47\x65\x74\x50\x72\x6F\x70","\x47\x65\x74\x52\x65\x61\x6C\x59\x61\x77","\x47\x65\x74\x46\x61\x6B\x65\x59\x61\x77","\x47\x65\x74\x57\x65\x61\x70\x6F\x6E","\x47\x65\x74\x4E\x61\x6D\x65","\x67\x33\x73\x67\x31","\x69\x6E\x63\x6C\x75\x64\x65\x73","\x73\x63\x61\x72","\x78\x6D\x31\x30\x31\x34","\x65\x6C\x69\x74\x65","\x64\x65\x73\x65\x72\x74","\x6E\x6F\x76\x61","\x73\x61\x77\x65\x64\x20\x6F\x66\x66","\x52\x61\x67\x65","\x47\x45\x4E\x45\x52\x41\x4C","\x45\x78\x70\x6C\x6F\x69\x74\x73","\x44\x6F\x75\x62\x6C\x65\x74\x61\x70\x20\x66\x61\x73\x74\x20\x72\x65\x63\x6F\x76\x65\x72\x79","\x54\x65\x6C\x65\x70\x6F\x72\x74\x20\x72\x65\x6C\x65\x61\x73\x65","\x65\x78\x70\x6C\x6F\x69\x74","\x48\x69\x64\x65\x20\x73\x68\x6F\x74\x73","\x68\x69\x74\x62\x6F\x78","\x66\x6C\x6F\x6F\x72","\x72\x6F\x75\x6E\x64","\x4D\x49\x53\x43","\x47\x72\x61\x64\x69\x65\x6E\x74\x20\x53\x70\x65\x65\x64","\x4C\x61\x74\x65\x6E\x63\x79","\x46\x72\x61\x6D\x65\x74\x69\x6D\x65","\x67\x65\x74\x48\x6F\x75\x72\x73","\x67\x65\x74\x4D\x69\x6E\x75\x74\x65\x73","\x67\x65\x74\x53\x65\x63\x6F\x6E\x64\x73","\x30","\x3A","\x54\x69\x63\x6B\x72\x61\x74\x65","\x56\x65\x72\x64\x61\x6E\x61","\x41\x64\x64\x46\x6F\x6E\x74","\x46\x69\x6C\x6C\x65\x64\x52\x65\x63\x74","\x52\x65\x63\x74","\x4F\x6D\x69\x6E\x6F\x75\x73\x57\x61\x72\x65","\x53\x74\x72\x69\x6E\x67\x43\x75\x73\x74\x6F\x6D","\x74\x77\x6F\x20\x73\x74\x65\x70\x73\x20\x61\x68\x65\x61\x64\x20\x6F\x66\x20\x74\x68\x65\x20\x72\x65\x73\x74","\x47\x72\x61\x64\x69\x65\x6E\x74\x52\x65\x63\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20","\x7C","\x6D\x73","\x70\x69\x6E\x67\x20\x20\x20","\x66\x70\x73\x20\x20\x20","\x46\x61\x6B\x65\x20\x3D\x20","\x74\x6F\x46\x69\x78\x65\x64","\x53\x74\x72\x69\x6E\x67","\x52\x65\x61\x6C\x20\x3D\x20","\x44\x69\x66\x66\x65\x72\x65\x6E\x63\x65\x20\x3D\x20","\x49\x6E\x76\x65\x72\x74\x65\x64\x20\x3D\x20","\x47\x65\x74\x53\x65\x72\x76\x65\x72\x53\x74\x72\x69\x6E\x67","\x20\x3A\x20","\x47\x65\x74\x4D\x61\x70\x4E\x61\x6D\x65","","\x48\x65\x61\x64","\x4E\x65\x63\x6B","\x50\x65\x6C\x76\x69\x73","\x42\x6F\x64\x79","\x54\x68\x6F\x72\x61\x78","\x43\x68\x65\x73\x74","\x55\x70\x70\x65\x72\x20\x63\x68\x65\x73\x74","\x4C\x65\x66\x74\x20\x74\x68\x69\x67\x68","\x52\x69\x67\x68\x74\x20\x74\x68\x69\x67\x68","\x4C\x65\x66\x74\x20\x63\x61\x6C\x66","\x52\x69\x67\x68\x74\x20\x63\x61\x6C\x66","\x4C\x65\x66\x74\x20\x66\x6F\x6F\x74","\x52\x69\x67\x68\x74\x20\x66\x6F\x6F\x74","\x4C\x65\x66\x74\x20\x68\x61\x6E\x64","\x52\x69\x67\x68\x74\x20\x68\x61\x6E\x64","\x4C\x65\x66\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x4C\x65\x66\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x47\x65\x6E\x65\x72\x69\x63","\x74\x61\x72\x67\x65\x74\x5F\x69\x6E\x64\x65\x78","\x68\x69\x74\x63\x68\x61\x6E\x63\x65","\x73\x61\x66\x65\x70\x6F\x69\x6E\x74","\x47\x65\x74\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79","\x47\x65\x74\x53\x70\x72\x65\x61\x64","\x47\x65\x74\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73","\x0A","\x53\x70\x72\x65\x61\x64\x20\x3D\x20","\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79\x20\x3D\x20","\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73\x20\x3D\x20","\x50\x69\x6E\x67\x20\x3D\x20","\x50\x72\x69\x6E\x74\x43\x6F\x6C\x6F\x72","\x5B\x54\x41\x52\x47\x45\x54\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x42\x4F\x58\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x43\x48\x41\x4E\x43\x45\x5D\x20\x3D\x20","\x5B\x53\x41\x46\x45\x50\x4F\x49\x4E\x54\x5D\x20\x3D\x20","\x5B\x45\x58\x50\x4C\x4F\x49\x54\x5D\x20\x3D\x20","\x20\x0A","\x44\x54","\x48\x53","\x44\x75\x63\x6B","\x45\x78\x74\x72\x61","\x46\x61\x6B\x65\x20\x64\x75\x63\x6B","\x46\x61\x6B\x65\x20\x64\x65\x73\x79\x6E\x63","\x41\x74\x20\x74\x61\x72\x67\x65\x74\x73","\x41\x75\x74\x6F\x20\x64\x69\x72\x65\x63\x74\x69\x6F\x6E","\x47\x65\x74\x50\x6C\x61\x79\x65\x72\x73","\x47\x65\x74\x52\x65\x6E\x64\x65\x72\x4F\x72\x69\x67\x69\x6E","\x6C\x65\x6E\x67\x74\x68","\x49\x73\x41\x6C\x69\x76\x65","\x49\x73\x54\x65\x61\x6D\x6D\x61\x74\x65","\x61\x74\x74\x61\x63\x6B\x65\x72","\x64\x6D\x67\x5F\x68\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x50\x6C\x61\x79\x65\x72","\x6D\x5F\x69\x48\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x41\x74\x74\x72\x69\x62\x75\x74\x61\x62\x6C\x65\x49\x74\x65\x6D","\x6D\x5F\x69\x49\x74\x65\x6D\x44\x65\x66\x69\x6E\x69\x74\x69\x6F\x6E\x49\x6E\x64\x65\x78","\x52\x65\x76\x6F\x6C\x76\x65\x72\x20\x46\x69\x78","\x45\x6E\x61\x62\x6C\x65\x64","\x44\x72\x61\x77","\x64\x72\x61\x77\x44\x54","\x52\x65\x67\x69\x73\x74\x65\x72\x43\x61\x6C\x6C\x62\x61\x63\x6B","\x64\x72\x61\x77\x44\x55\x43\x4B","\x64\x72\x61\x77\x48\x53","\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x72\x61\x67\x65\x62\x6F\x74\x4C\x6F\x67\x73","\x70\x6C\x61\x79\x65\x72\x5F\x68\x75\x72\x74","\x43\x72\x65\x61\x74\x65\x4D\x6F\x76\x65","\x63\x72\x65\x61\x74\x65\x5F\x6D\x6F\x76\x65","\x64\x72\x61\x77\x49\x74","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x68\x65\x61\x64","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x6F\x6C\x64","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x37","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x35","\x53\x63\x75\x66\x66\x65\x64\x54\x61\x70","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x69\x6E\x76\x65\x72\x74","\x49\x6E\x69\x74\x69\x61\x6C\x69\x7A\x65","\x76\x69\x73\x75\x61\x6C\x73","\x4F\x6E\x48\x75\x72\x74","\x4F\x6E\x42\x75\x6C\x6C\x65\x74\x49\x6D\x70\x61\x63\x74","\x62\x75\x6C\x6C\x65\x74\x5F\x69\x6D\x70\x61\x63\x74","\x77\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x65\x6C\x63\x6F\x6D\x65\x20\x54\x6F\x20\x54\x61\x6E\x6B\x20\x53\x63\x68\x6F\x6F\x6C","\x50\x72\x69\x6E\x74"];
var master={dir:_$_68fa[0],cycle:false,iteration:1,showArrows:false,showCycle:false,showDegree:false,showInverted:false,getAAInvert:function()
{
	return UI[_$_68fa[4]](_$_68fa[1],_$_68fa[2],_$_68fa[3])
}
,setAAInvert:function()
{
	return UI[_$_68fa[5]](_$_68fa[1],_$_68fa[2],_$_68fa[3])
}
,getInvert:function()
{
	return UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[8],_$_68fa[9])
}
,setVisible:function()
{
	
}
};//1
function GetScriptOption(D)
{
	var E=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[8],D);//18
	return E
}
function invert()
{
	if(!master[_$_68fa[11]]()|| Entity[_$_68fa[14]](Event[_$_68fa[13]](_$_68fa[12]))!= Entity[_$_68fa[15]]())
	{
		return
	}
	//24
	master[_$_68fa[16]]()
}
function ui()
{
	UI[_$_68fa[18]](_$_68fa[17]);UI[_$_68fa[18]](_$_68fa[19]);UI[_$_68fa[18]](_$_68fa[20]);UI[_$_68fa[22]](_$_68fa[21],0,0);UI[_$_68fa[22]](_$_68fa[23],0,0);UI[_$_68fa[18]](_$_68fa[24]);UI[_$_68fa[22]](_$_68fa[25],0,180);UI[_$_68fa[22]](_$_68fa[26],0.01,1);UI[_$_68fa[22]](_$_68fa[27],-180,180);UI[_$_68fa[18]](_$_68fa[28]);UI[_$_68fa[22]](_$_68fa[29],0,5);UI[_$_68fa[22]](_$_68fa[30],0.01,1);UI[_$_68fa[22]](_$_68fa[31],0,16);UI[_$_68fa[18]](_$_68fa[32]);UI[_$_68fa[33]](_$_68fa[9]);UI[_$_68fa[18]](_$_68fa[34]);UI[_$_68fa[33]](_$_68fa[35]);UI[_$_68fa[18]](_$_68fa[36]);UI[_$_68fa[18]](_$_68fa[37]);UI[_$_68fa[42]](_$_68fa[38],[_$_68fa[39],_$_68fa[40],_$_68fa[41]]);UI[_$_68fa[22]](_$_68fa[21],0,0);UI[_$_68fa[22]](_$_68fa[43],0,0);UI[_$_68fa[18]](_$_68fa[44]);UI[_$_68fa[42]](_$_68fa[45],[_$_68fa[39],_$_68fa[46],_$_68fa[47]]);UI[_$_68fa[18]](_$_68fa[48]);UI[_$_68fa[18]](_$_68fa[21]);UI[_$_68fa[18]](_$_68fa[49]);UI[_$_68fa[42]](_$_68fa[50],[_$_68fa[39],_$_68fa[51],_$_68fa[52],_$_68fa[53]]);UI[_$_68fa[18]](_$_68fa[48]);UI[_$_68fa[22]](_$_68fa[21],0,0);UI[_$_68fa[22]](_$_68fa[54],0,0);var P=Global[_$_68fa[55]]();//81
	UI[_$_68fa[33]](_$_68fa[56]);UI[_$_68fa[58]](_$_68fa[57],0,P[0]);UI[_$_68fa[58]](_$_68fa[59],0,P[1]);UI[_$_68fa[22]](_$_68fa[21],0,0);UI[_$_68fa[22]](_$_68fa[60],0,0);UI[_$_68fa[33]](_$_68fa[61]);UI[_$_68fa[33]](_$_68fa[62]);UI[_$_68fa[18]](_$_68fa[63]);UI[_$_68fa[33]](_$_68fa[64]);UI[_$_68fa[33]](_$_68fa[65]);UI[_$_68fa[33]](_$_68fa[66]);UI[_$_68fa[22]](_$_68fa[21],0,0);UI[_$_68fa[22]](_$_68fa[67],0,0);UI[_$_68fa[18]](_$_68fa[68]);UI[_$_68fa[22]](_$_68fa[69],0,0)
}
function yawvalues()
{
	var y=Global[_$_68fa[70]]();//108
	var bM=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[25]);//109
	var bL=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[26]);//110
	var bK=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[27]);//111
	var bK=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[27]);//112
	var bJ=(bM* Math[_$_68fa[72]]((y)/ bL)+ bK);//113
	return bJ
}
function Initialize()
{
	UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[74],yawvalues());UI[_$_68fa[75]](_$_68fa[1],_$_68fa[76],_$_68fa[77],fakelagRando())
}
function radian(bo)
{
	return bo* Math[_$_68fa[78]]/ 180.0
}
function ExtendVector(t,q,r)
{
	var s=radian(q);//131
	return [r* Math[_$_68fa[72]](s)+ t[0],r* Math[_$_68fa[79]](s)+ t[1],t[2]]
}
function VectorAdd(h,j)
{
	return [h[0]+ j[0],h[1]+ j[1],h[2]+ j[2]]
}
function VectorSubtract(h,j)
{
	return [h[0]- j[0],h[1]- j[1],h[2]- j[2]]
}
function VectorMultiply(h,j)
{
	return [h[0]* j[0],h[1]* j[1],h[2]* j[2]]
}
function VectorLength(br,bs,bt)
{
	return Math[_$_68fa[80]](br* br+ bs* bs+ bt* bt)
}
function VectorNormalize(bu)
{
	var b=VectorLength(bu[0],bu[1],bu[2]);//157
	return [bu[0]/ b,bu[1]/ b,bu[2]/ b]
}
function VectorDot(h,j)
{
	return h[0]* j[0]+ h[1]* j[1]+ h[2]* j[2]
}
function VectorDistance(h,j)
{
	return VectorLength(h[0]- j[0],h[1]- j[1],h[2]- j[2])
}
function ClosestPointOnRay(f,e,d)
{
	var g=VectorSubtract(f,e);//173
	var a=VectorSubtract(d,e);//174
	var b=VectorLength(a[0],a[1],a[2]);//175
	a= VectorNormalize(a);var c=VectorDot(a,g);//178
	if(c< 0.0)
	{
		return e
	}
	//179
	if(c> b)
	{
		return d
	}
	//183
	return VectorAdd(e,VectorMultiply(a,[c,c,c]))
}
function Flip()
{
	UI[_$_68fa[5]](_$_68fa[1],_$_68fa[2],_$_68fa[3])
}
var lastHitTime=0.0;//195
var lastImpactTimes=[0.0];//196
var lastImpacts=[[0.0,0.0,0.0]];//201
function OnHurt()
{
	if(GetScriptOption(_$_68fa[38])== 0)
	{
		return
	}
	//208
	if(Entity[_$_68fa[14]](Event[_$_68fa[13]](_$_68fa[12]))!== Entity[_$_68fa[15]]())
	{
		return
	}
	//209
	var bn=Event[_$_68fa[13]](_$_68fa[81]);//210
	if(bn== 1|| bn== 6|| bn== 7)
	{
		var T=Global[_$_68fa[82]]();//214
		if(Math[_$_68fa[83]](lastHitTime- T)> 0.5)
		{
			lastHitTime= T;Flip()
		}
		
	}
	
}
function OnBulletImpact()
{
	if(GetScriptOption(_$_68fa[38])!== 2)
	{
		return
	}
	//225
	var T=Global[_$_68fa[82]]();//227
	if(Math[_$_68fa[83]](lastHitTime- T)< 0.5)
	{
		return
	}
	//228
	var U=Entity[_$_68fa[14]](Event[_$_68fa[13]](_$_68fa[12]));//230
	var bd=[Event[_$_68fa[85]](_$_68fa[84]),Event[_$_68fa[85]](_$_68fa[86]),Event[_$_68fa[85]](_$_68fa[87]),T];//231
	var bm;//232
	if(Entity[_$_68fa[88]](U)&& Entity[_$_68fa[89]](U))
	{
		if(!Entity[_$_68fa[90]](U))
		{
			bm= Entity[_$_68fa[91]](U)
		}
		else 
		{
			if(Math[_$_68fa[83]](lastImpactTimes[U]- T)< 0.1)
			{
				bm= lastImpacts[U]
			}
			else 
			{
				lastImpacts[U]= bd;lastImpactTimes[U]= T;return
			}
			
		}
		//235
		var be=Entity[_$_68fa[15]]();//249
		var bg=Entity[_$_68fa[91]](be);//250
		var bh=Entity[_$_68fa[94]](be,_$_68fa[92],_$_68fa[93]);//251
		var bf=VectorMultiply(VectorAdd(bg,bh),[0.5,0.5,0.5]);//252
		var R=ClosestPointOnRay(bf,bm,bd);//254
		var Q=VectorDistance(bf,R);//255
		if(Q< 128.0)
		{
			var bi=Local[_$_68fa[95]]();//259
			var V=Local[_$_68fa[96]]();//260
			var bc=ClosestPointOnRay(bg,bm,bd);//262
			var bb=VectorDistance(bg,bc);//263
			var ba=ClosestPointOnRay(bh,bm,bd);//264
			var Z=VectorDistance(bh,ba);//265
			var S;//267
			var bj;//268
			var W;//269
			if(Q< bb&& Q< Z)
			{
				S= R;bj= ExtendVector(R,bi+ 180.0,10.0);W= ExtendVector(R,V+ 180.0,10.0)
			}
			else 
			{
				if(Z< bb)
				{
					S= ba;var bk=ExtendVector(R,bi- 30.0+ 90.0,10.0);//280
					var bl=ExtendVector(R,bi- 30.0- 90.0,10.0);//281
					var X=ExtendVector(R,V- 30.0+ 90.0,10.0);//282
					var Y=ExtendVector(R,V- 30.0- 90.0,10.0);//283
					if(VectorDistance(ba,bk)< VectorDistance(ba,bl))
					{
						bj= bk
					}
					else 
					{
						bj= bl
					}
					//284
					if(VectorDistance(ba,X)< VectorDistance(ba,Y))
					{
						W= X
					}
					else 
					{
						W= Y
					}
					
				}
				else 
				{
					S= bc;bj= ExtendVector(R,bi,10.0);W= ExtendVector(R,V,10.0)
				}
				
			}
			//271
			if(VectorDistance(S,W)< VectorDistance(S,bj))
			{
				lastHitTime= T;Flip()
			}
			
		}
		//257
		lastImpacts[U]= bd;lastImpactTimes[U]= T
	}
	
}
function on_ragebot_fireold()
{
	if(GetScriptOption(_$_68fa[45])!== 1)
	{
		return
	}
	//323
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false);return
	}
	//329
	ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);if(ragebot_target_exploit== 2)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	
}
function on_ragebot_fire()
{
	if(GetScriptOption(_$_68fa[45])!== 2)
	{
		return
	}
	//349
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false);return
	}
	//355
	ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);if(ragebot_target_exploit== 2)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	
}
function on_ragebot_fire7()
{
	if(GetScriptOption(_$_68fa[45])!== 2)
	{
		return
	}
	//374
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false);return
	}
	//380
	ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);if(ragebot_target_exploit== 0)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	
}
function on_ragebot_fire5()
{
	if(GetScriptOption(_$_68fa[50])!== 1)
	{
		return
	}
	//401
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);return
	}
	//407
	ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);if(ragebot_target_exploit== 1)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	
}
function on_ragebot_firehead()
{
	if(GetScriptOption(_$_68fa[50])!== 2)
	{
		return
	}
	//427
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);return
	}
	//433
	ragebot_target_hitbox= Event[_$_68fa[13]](_$_68fa[114]);if(ragebot_target_hitbox> 1)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true);return
	}
	//439
	if(ragebot_target_hitbox> 2)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true);return
	}
	
}
function fakelagRando()
{
	var y=Global[_$_68fa[70]]();//470
	var x=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[29]);//471
	var w=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[30]);//472
	var v=UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[31]);//473
	var u=(x* Math[_$_68fa[72]]((y)/ w)+ v);//474
	return u
}
function ScuffedTap()
{
	if(GetScriptOption(_$_68fa[50])!== 3)
	{
		return
	}
	//486
	player= Entity[_$_68fa[15]]();weapon= Entity[_$_68fa[97]](player);weaponName= Entity[_$_68fa[98]](weapon);if(!(weaponName[_$_68fa[100]](_$_68fa[99])|| weaponName[_$_68fa[100]](_$_68fa[101])|| weaponName[_$_68fa[100]](_$_68fa[102])|| weaponName[_$_68fa[100]](_$_68fa[103])|| weaponName[_$_68fa[100]](_$_68fa[104])|| weaponName[_$_68fa[100]](_$_68fa[105])|| weaponName[_$_68fa[100]](_$_68fa[106])))
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false);return
	}
	//492
	ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);if(ragebot_target_exploit== 0)
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],true);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false)
	}
	else 
	{
		UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[64],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[110],false);UI[_$_68fa[75]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[111],false)
	}
	
}
function HSVtoRGB(H,M,O)
{
	var L,G,j,I,F,J,K,N;//522
	I= Math[_$_68fa[115]](H* 6);F= H* 6- I;J= O* (1- M);K= O* (1- F* M);N= O* (1- (1- F)* M);switch(I% 6)
	{
		case 0:L= 255,G= 0,j= 0;break//532
		case 1:L= 255,G= 0,j= 0;break//533
		case 2:L= 255,G= 0,j= 0;break//534
		case 3:L= 255,G= 0,j= 0;break//535
		case 4:L= 255,G= 0,j= 0;break//536
		case 5:L= 255,G= 0,j= 0;break
	}
	//530
	return {r:Math[_$_68fa[116]](L* 255),g:Math[_$_68fa[116]](G* 255),b:Math[_$_68fa[116]](j* 255)}
}
function getCustomValue(A)
{
	var z=UI[_$_68fa[10]](_$_68fa[117],_$_68fa[7],_$_68fa[71],A);//543
	return z
}
var position={x1:0,y1:0};//545
function watermark()
{
	if(UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[56],true))
	{
		var bv=HSVtoRGB(Global[_$_68fa[70]]()* UI[_$_68fa[10]](_$_68fa[117],_$_68fa[7],_$_68fa[8],_$_68fa[118]),1,1);//557
		const bE=Math[_$_68fa[115]](Global[_$_68fa[119]]()* 1000/ 1.5);//559
		const bw=Math[_$_68fa[115]](1/ Global[_$_68fa[120]]());//560
		x1= getCustomValue(_$_68fa[57]);y1= getCustomValue(_$_68fa[59]);var bI= new Date();//565
		var bB=bI[_$_68fa[121]]();//566
		var bD=bI[_$_68fa[122]]();//567
		var bG=bI[_$_68fa[123]]();//568
		var bA=bB<= 9?_$_68fa[124]+ bI[_$_68fa[121]]()+ _$_68fa[125]:bI[_$_68fa[121]]()+ _$_68fa[125];//569
		var bC=bD<= 9?_$_68fa[124]+ bI[_$_68fa[122]]()+ _$_68fa[125]:bI[_$_68fa[122]]()+ _$_68fa[125];//570
		var bF=bG<= 9?_$_68fa[124]+ bI[_$_68fa[123]]():bI[_$_68fa[123]]();//571
		var bH=Global[_$_68fa[126]]();//578
		font= Render[_$_68fa[128]](_$_68fa[127],28,800);font2= Render[_$_68fa[128]](_$_68fa[127],10,600);font3= Render[_$_68fa[128]](_$_68fa[127],7,500);font4= Render[_$_68fa[128]](_$_68fa[127],8,600);font5= Render[_$_68fa[128]](_$_68fa[127],6,600);Render[_$_68fa[129]](x1+ 120,y1- 17,146,50,[30,30,30,140]);Render[_$_68fa[130]](x1+ 118,y1+ 5,150,29,[30,30,30,0]);Render[_$_68fa[130]](x1+ 119,y1- 17,147,50,[30,30,30,155]);Render[_$_68fa[129]](x1+ 120,y1+ 7,146,25,[30,30,30,215]);Render[_$_68fa[132]](x1+ 125,y1- 18,0,_$_68fa[131],[255,255,255,255],font2);Render[_$_68fa[132]](x1+ 125,y1- 5,0,_$_68fa[133],[255,255,255,255],font3);Render[_$_68fa[134]](x1+ 120,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_68fa[134]](x1+ 133,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_68fa[134]](x1+ 120,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_68fa[134]](x1+ 133,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_68fa[132]](x1+ 116,y1+ 15,0,_$_68fa[135]+ bw,[255,255,255,254],font4);Render[_$_68fa[132]](x1+ 188,y1+ 14,0,_$_68fa[136],[155,155,155,0],font4);Render[_$_68fa[132]](x1+ 188,y1+ 8,0,_$_68fa[136],[155,155,155,0],font4);Render[_$_68fa[132]](x1+ 219,y1+ 15,0,_$_68fa[21]+ bE+ _$_68fa[137],[255,255,255,220],font4);Render[_$_68fa[132]](x1+ 230,y1+ 16,0,_$_68fa[138],[255,255,255,0],font4);Render[_$_68fa[129]](x1+ 193,y1+ 13,2,15,[155,155,155,255]);Render[_$_68fa[129]](x1+ 128,y1+ 14,21,13,[30,30,30,255]);Render[_$_68fa[130]](x1+ 127,y1+ 14,21,13,[43,253,28,255]);Render[_$_68fa[132]](x1+ 131,y1+ 15,0,_$_68fa[139],[255,255,255,220],font5);Render[_$_68fa[129]](x1+ 199,y1+ 14,5,12,[43,253,28,255]);Render[_$_68fa[129]](x1+ 206,y1+ 17,5,9,[43,253,28,255]);Render[_$_68fa[129]](x1+ 213,y1+ 20,5,6,[43,253,28,255]);Render[_$_68fa[130]](x1+ 199,y1+ 14,6,13,[0,0,0,255]);Render[_$_68fa[130]](x1+ 206,y1+ 17,6,10,[0,0,0,255]);Render[_$_68fa[130]](x1+ 213,y1+ 20,6,7,[0,0,0,255])
	}
	
}
function main()
{
	var P=Global[_$_68fa[55]]()
}
function drawIt()
{
	fakeyaw= Local[_$_68fa[96]]();realyaw= Local[_$_68fa[95]]();var o=Math[_$_68fa[83]](realyaw)- Math[_$_68fa[83]](fakeyaw);//633
	var p=UI[_$_68fa[4]](_$_68fa[1],_$_68fa[2],_$_68fa[3]);//634
	if(UI[_$_68fa[10]](_$_68fa[8],_$_68fa[61]))
	{
		Render[_$_68fa[142]](100,500,0,_$_68fa[140]+ fakeyaw[_$_68fa[141]](2),[247,99,88,255]);Render[_$_68fa[142]](100,520,0,_$_68fa[143]+ realyaw[_$_68fa[141]](2),[247,99,88,255]);Render[_$_68fa[142]](100,540,0,_$_68fa[144]+ Math[_$_68fa[83]](o[_$_68fa[141]](2)),[247,99,88,255]);Render[_$_68fa[142]](100,580,0,_$_68fa[145]+ p,[99,206,99,250]);Render[_$_68fa[142]](100,600,0,World[_$_68fa[146]]()+ _$_68fa[147]+ Global[_$_68fa[148]](),[99,206,99,250])
	}
	
}
function getHitboxName(C)
{
	var B=_$_68fa[149];//646
	switch(C)
	{
		case 0:B= _$_68fa[150];break//649
		case 1:B= _$_68fa[151];break//652
		case 2:B= _$_68fa[152];break//655
		case 3:B= _$_68fa[153];break//658
		case 4:B= _$_68fa[154];break//661
		case 5:B= _$_68fa[155];break//664
		case 6:B= _$_68fa[156];break//667
		case 7:B= _$_68fa[157];break//670
		case 8:B= _$_68fa[158];break//673
		case 9:B= _$_68fa[159];break//676
		case 10:B= _$_68fa[160];break//679
		case 11:B= _$_68fa[161];break//682
		case 12:B= _$_68fa[162];break//685
		case 13:B= _$_68fa[163];break//688
		case 14:B= _$_68fa[164];break//691
		case 15:B= _$_68fa[165];break//694
		case 16:B= _$_68fa[166];break//697
		case 17:B= _$_68fa[167];break//700
		case 18:B= _$_68fa[168];break//703
		default:B= _$_68fa[169]
	}
	//647
	return B
}
function ragebotLogs()
{
	ragebot_target= Event[_$_68fa[13]](_$_68fa[170]);ragebot_target_hitbox= Event[_$_68fa[13]](_$_68fa[114]);ragebot_target_hitchance= Event[_$_68fa[13]](_$_68fa[171]);ragebot_target_safepoint= Event[_$_68fa[13]](_$_68fa[172]);ragebot_target_exploit= Event[_$_68fa[13]](_$_68fa[112]);targetName= Entity[_$_68fa[98]](ragebot_target);inaccuracy= Local[_$_68fa[173]]();spread= Local[_$_68fa[174]]();fakeyaw= Local[_$_68fa[96]]();realyaw= Local[_$_68fa[95]]();var bq=Local[_$_68fa[175]]();//725
	var bp=Math[_$_68fa[115]](1/ Local[_$_68fa[119]]());//726
	if(UI[_$_68fa[10]](_$_68fa[8],_$_68fa[62]))
	{
		Cheat[_$_68fa[181]]([247,99,88,255],_$_68fa[176]+ _$_68fa[177]+ spread+ _$_68fa[176]+ _$_68fa[178]+ inaccuracy+ _$_68fa[176]+ _$_68fa[140]+ fakeyaw+ _$_68fa[176]+ _$_68fa[143]+ realyaw+ _$_68fa[176]+ _$_68fa[179]+ bq+ _$_68fa[176]+ _$_68fa[180]+ bp+ _$_68fa[176]);Cheat[_$_68fa[181]]([247,99,88,255],_$_68fa[176]+ _$_68fa[182]+ targetName+ _$_68fa[176]+ _$_68fa[183]+ getHitboxName(ragebot_target_hitbox)+ _$_68fa[176]+ _$_68fa[184]+ ragebot_target_hitchance+ _$_68fa[176]+ _$_68fa[185]+ ragebot_target_safepoint+ _$_68fa[176]+ _$_68fa[186]+ ragebot_target_exploit+ _$_68fa[187])
	}
	//727
	_$_68fa[176]+ _$_68fa[178]+ inaccuracy
}
function drawDT()
{
	if(UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[64],true))
	{
		Render[_$_68fa[142]](27,502- 5,0,_$_68fa[188],[67,19,18,255],4.6);Render[_$_68fa[142]](25,500- 5,0,_$_68fa[188],[247,99,88,255],4.6);if(UI[_$_68fa[4]](_$_68fa[107],_$_68fa[109],_$_68fa[64]))
		{
			Render[_$_68fa[142]](27,502- 5,0,_$_68fa[188],[9,76,14,250],4.6);Render[_$_68fa[142]](25,500- 5,0,_$_68fa[188],[99,206,99,250],4.6)
		}
		
	}
	
}
function drawHS()
{
	if(UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[65],true))
	{
		Render[_$_68fa[142]](27,532- 5,0,_$_68fa[189],[67,19,18,255],4.6);Render[_$_68fa[142]](25,530- 5,0,_$_68fa[189],[247,99,88,255],4.6);if(UI[_$_68fa[4]](_$_68fa[107],_$_68fa[108],_$_68fa[109],_$_68fa[113]))
		{
			Render[_$_68fa[142]](27,532- 5,0,_$_68fa[189],[9,76,14,250],4.6);Render[_$_68fa[142]](25,530- 5,0,_$_68fa[189],[99,206,99,250],4.6)
		}
		
	}
	
}
function drawDUCK()
{
	if(UI[_$_68fa[10]](_$_68fa[6],_$_68fa[7],_$_68fa[71],_$_68fa[66],true))
	{
		Render[_$_68fa[142]](27,562- 5,0,_$_68fa[190],[67,19,18,255],4.6);Render[_$_68fa[142]](25,560- 5,0,_$_68fa[190],[247,99,88,255],4.6);if(UI[_$_68fa[4]](_$_68fa[1],_$_68fa[191],_$_68fa[192]))
		{
			Render[_$_68fa[142]](27,562- 5,0,_$_68fa[190],[9,76,14,250],4.6);Render[_$_68fa[142]](25,560- 5,0,_$_68fa[190],[99,206,99,250],4.6)
		}
		
	}
	
}
var old_fake_desync=UI[_$_68fa[10]](_$_68fa[1],_$_68fa[2],_$_68fa[193]);//792
var old_at_targets=UI[_$_68fa[10]](_$_68fa[1],_$_68fa[73],_$_68fa[194]);//793
var old_auto_direction=UI[_$_68fa[10]](_$_68fa[1],_$_68fa[73],_$_68fa[195]);//794
var old_yaw_offset=UI[_$_68fa[10]](_$_68fa[1],_$_68fa[73],_$_68fa[74]);//795
var prevent_correction=false;//796
var last_prevent_time=0;//797
var in_act_pha=false;//798
var in_act_pac=false;//799
var in_act_sr=false;//800
function distance(h,j)
{
	ax= h[0],ay= h[1],az= h[2];bx= j[0],by= j[1],bz= j[2];dx= ax- bx,dy= ay- by,dz= az- bz;return Math[_$_68fa[80]](dx* dx+ dy* dy+ dz* dz)
}
function distance2D(k,m,l,n)
{
	xs= l- k,ys= n- m;xs*= xs;ys*= ys;return Math[_$_68fa[80]](xs+ ys)
}
function difference(h,j)
{
	if(h> j)
	{
		return h- j
	}
	else 
	{
		return j- h
	}
	
}
function get_nearest_player()
{
	players= Entity[_$_68fa[196]]();local_origin= Entity[_$_68fa[197]](Entity[_$_68fa[15]]());target_origin= 0;target= 0;for(i= 0;i< players[_$_68fa[198]];i++)
	{
		if(!Entity[_$_68fa[199]](players[i]))
		{
			continue
		}
		//828
		if(Entity[_$_68fa[200]](players[i]))
		{
			continue
		}
		//832
		if(Entity[_$_68fa[90]](players[i]))
		{
			continue
		}
		//836
		entity_origin= Entity[_$_68fa[197]](players[i]);if(target=== 0)
		{
			target_origin= [999999,999999,999999]
		}
		//839
		if(distance(local_origin,target_origin)> distance(local_origin,entity_origin))
		{
			target= players[i];target_origin= entity_origin
		}
		
	}
	//827
	return target
}
function player_hurt()
{
	target= Event[_$_68fa[13]](_$_68fa[12]);attacker= Event[_$_68fa[13]](_$_68fa[201]);damage= Event[_$_68fa[13]](_$_68fa[202]);hitgroup= Event[_$_68fa[13]](_$_68fa[81]);if((Entity[_$_68fa[15]]()=== Entity[_$_68fa[14]](target))&& Entity[_$_68fa[15]]()!== Entity[_$_68fa[14]](attacker))
	{
		health= Entity[_$_68fa[94]](Entity[_$_68fa[15]](),_$_68fa[203],_$_68fa[204]);if(hitgroup=== 1&& (health/ damage)>= 2)
		{
			prevent_correction= true
		}
		else 
		{
			prevent_correction= false
		}
		
	}
	
}
function create_move()
{
	local_weapon_id= Entity[_$_68fa[94]](Entity[_$_68fa[97]](Entity[_$_68fa[15]]()),_$_68fa[205],_$_68fa[206]);local_origin= Entity[_$_68fa[94]](Entity[_$_68fa[15]](),_$_68fa[92],_$_68fa[93]);if(UI[_$_68fa[10]](_$_68fa[207]))
	{
		if(local_weapon_id=== 262208)
		{
			in_act_sr= Math[_$_68fa[116]](1/ Globals[_$_68fa[120]]())< 65?true:false;UI[_$_68fa[75]](_$_68fa[1],_$_68fa[76],_$_68fa[208],Math[_$_68fa[116]](1/ Globals[_$_68fa[120]]())< 65?false:true)
		}
		else 
		{
			in_act_sr= false;UI[_$_68fa[75]](_$_68fa[1],_$_68fa[76],_$_68fa[208],true)
		}
		
	}
	//865
	if(UI[_$_68fa[10]](_$_68fa[35]))
	{
		target= get_nearest_player();if(target=== 0||  !Entity[_$_68fa[199]](target))
		{
			in_act_pha= false;UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[194],old_at_targets);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[195],old_auto_direction);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[74],old_yaw_offset);return
		}
		//878
		local_origin= Entity[_$_68fa[197]](Entity[_$_68fa[15]]());target_origin= Entity[_$_68fa[197]](target);if((target_origin[2]> local_origin[2])&& difference(target_origin[2],local_origin[2])> 64&& distance2D(local_origin[0],local_origin[1],target_origin[0],target_origin[1])< 220)
		{
			in_act_pha= true;UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[194],true);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[195],false);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[74],180)
		}
		else 
		{
			in_act_pha= false;UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[194],old_at_targets);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[195],old_auto_direction);UI[_$_68fa[75]](_$_68fa[1],_$_68fa[73],_$_68fa[74],old_yaw_offset)
		}
		
	}
	
}
function main()
{
	ui();Global[_$_68fa[211]](_$_68fa[209],_$_68fa[210]);Global[_$_68fa[211]](_$_68fa[209],_$_68fa[212]);Global[_$_68fa[211]](_$_68fa[209],_$_68fa[213]);Cheat[_$_68fa[211]](_$_68fa[214],_$_68fa[215]);Cheat[_$_68fa[211]](_$_68fa[216],_$_68fa[216]);Cheat[_$_68fa[211]](_$_68fa[217],_$_68fa[218]);Cheat[_$_68fa[211]](_$_68fa[209],_$_68fa[219]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[220]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[221]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[222]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[223]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[224]);Global[_$_68fa[211]](_$_68fa[214],_$_68fa[225]);Global[_$_68fa[211]](_$_68fa[216],_$_68fa[226]);Global[_$_68fa[211]](_$_68fa[209],_$_68fa[227],_$_68fa[217],_$_68fa[228],_$_68fa[229],_$_68fa[216]);Global[_$_68fa[211]](_$_68fa[216],_$_68fa[226],_$_68fa[209],_$_68fa[230],_$_68fa[231]);Global[_$_68fa[211]](_$_68fa[209],_$_68fa[232],_$_68fa[127]);UI[_$_68fa[75]](_$_68fa[117],_$_68fa[7],_$_68fa[8],_$_68fa[118],0.1);Global[_$_68fa[234]](_$_68fa[233])
}
main()
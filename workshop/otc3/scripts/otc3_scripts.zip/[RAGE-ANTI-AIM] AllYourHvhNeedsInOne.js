/***************************************************************************/
/*    ALL YOUR HVH NEEDS IN ONE                                                                     */
/*  This is the public version and may not match results of the alpha.*/
/*  For onetap v3              */
/*  Created by Ominous#7262                                         */
/*                                                                         */
/***************************************************************************/
var _$_afb6=["\x62\x61\x63\x6B","\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x46\x61\x6B\x65\x20\x61\x6E\x67\x6C\x65\x73","\x49\x6E\x76\x65\x72\x74\x65\x72","\x49\x73\x48\x6F\x74\x6B\x65\x79\x41\x63\x74\x69\x76\x65","\x54\x6F\x67\x67\x6C\x65\x48\x6F\x74\x6B\x65\x79","\x4D\x69\x73\x63","\x4A\x41\x56\x41\x53\x43\x52\x49\x50\x54","\x53\x63\x72\x69\x70\x74\x20\x49\x74\x65\x6D\x73","\x41\x75\x74\x6F\x2D\x49\x6E\x76\x65\x72\x74\x65\x72","\x47\x65\x74\x56\x61\x6C\x75\x65","\x67\x65\x74\x49\x6E\x76\x65\x72\x74","\x75\x73\x65\x72\x69\x64","\x47\x65\x74\x49\x6E\x74","\x47\x65\x74\x45\x6E\x74\x69\x74\x79\x46\x72\x6F\x6D\x55\x73\x65\x72\x49\x44","\x47\x65\x74\x4C\x6F\x63\x61\x6C\x50\x6C\x61\x79\x65\x72","\x73\x65\x74\x41\x41\x49\x6E\x76\x65\x72\x74","\x20","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x46\x6C\x6F\x61\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x52\x61\x67\x65\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6E\x74\x69\x41\x69\x6D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x4C\x61\x62\x65\x6C","\x59\x61\x77\x20\x4C\x69\x6D\x69\x74","\x59\x61\x77\x20\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x59\x61\x77\x20\x43\x65\x6E\x74\x65\x72","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x46\x61\x6B\x65\x6C\x61\x67\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x55\x70\x70\x65\x72\x20\x41\x6E\x64\x20\x4C\x6F\x77\x65\x72\x20\x4C\x69\x6D\x69\x74","\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x43\x65\x6E\x74\x65\x72\x20\x56\x61\x6C\x75\x65","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x4F\x74\x68\x65\x72\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x43\x68\x65\x63\x6B\x62\x6F\x78","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x54\x65\x73\x74\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x20\x48\x65\x69\x67\x68\x74\x20\x41\x64\x76\x61\x6E\x74\x61\x67\x65","\x5E\x20\x57\x61\x72\x6E\x69\x6E\x67\x20\x74\x68\x69\x73\x20\x64\x69\x73\x61\x62\x6C\x65\x73\x20\x63\x75\x73\x74\x6F\x6D\x20\x61\x61","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x2D\x42\x72\x75\x74\x65\x66\x6F\x72\x63\x65","\x4F\x66\x66","\x4F\x6E\x20\x48\x69\x74","\x4F\x6E\x20\x53\x68\x6F\x74","\x41\x64\x64\x44\x72\x6F\x70\x64\x6F\x77\x6E","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x45\x78\x70\x6C\x6F\x69\x74\x20\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6C\x70\x68\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x54\x72\x69\x70\x70\x6C\x65\x74\x61\x70\x20\x28\x41\x6C\x70\x68\x61\x29","\x5E\x20\x46\x69\x72\x73\x74\x20\x73\x68\x6F\x74\x20\x73\x61\x66\x65\x74\x79","\x20\x20\x20\x5E\x20\x73\x65\x63\x6F\x6E\x64\x20\x73\x68\x6F\x74\x20\x73\x61\x66\x65\x74\x79","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x4E\x65\x77\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x50\x65\x72\x66\x65\x63\x74\x54\x61\x70\x20\x28\x4E\x65\x77\x29","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x42\x65\x74\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x44\x6F\x75\x62\x6C\x65\x20\x74\x61\x70\x20\x53\x63\x75\x66\x66\x65\x64\x20\x28\x42\x65\x74\x61\x29","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4C\x65\x67\x69\x74\x20\x54\x61\x62\x20","\x46\x72\x65\x65\x73\x74\x61\x6E\x64\x69\x6E\x67\x20\x4C\x65\x67\x69\x74\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x50\x6F\x69\x6E\x74\x20\x64\x69\x73\x74\x61\x6E\x63\x65","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x49\x6E\x74","\x44\x69\x73\x74\x61\x6E\x63\x65\x20\x63\x6F\x6C\x6F\x72","\x41\x64\x64\x43\x6F\x6C\x6F\x72\x50\x69\x63\x6B\x65\x72","\x4C\x69\x6E\x65\x20\x63\x6F\x6C\x6F\x72","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x47\x65\x74\x53\x63\x72\x65\x65\x6E\x53\x69\x7A\x65","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x78","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x79","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x43\x6F\x6E\x73\x6F\x6C\x65","\x45\x6E\x61\x62\x6C\x65\x20\x56\x69\x73\x75\x61\x6C\x20\x4C\x6F\x67\x73","\x45\x6E\x61\x62\x6C\x65\x20\x43\x6F\x6E\x73\x6F\x6C\x65\x20\x4C\x6F\x67\x73","\x20\x20\x20\x20\x20\x43\x72\x65\x61\x74\x65\x64\x20\x42\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32","\x52\x65\x61\x6C\x74\x69\x6D\x65","\x53\x63\x72\x69\x70\x74\x20\x69\x74\x65\x6D\x73","\x63\x6F\x73","\x52\x61\x67\x65\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x59\x61\x77\x20\x6F\x66\x66\x73\x65\x74","\x53\x65\x74\x56\x61\x6C\x75\x65","\x46\x61\x6B\x65\x2D\x4C\x61\x67","\x4C\x69\x6D\x69\x74","\x50\x49","\x73\x69\x6E","\x73\x71\x72\x74","\x68\x69\x74\x67\x72\x6F\x75\x70","\x43\x75\x72\x74\x69\x6D\x65","\x61\x62\x73","\x78","\x47\x65\x74\x46\x6C\x6F\x61\x74","\x79","\x7A","\x49\x73\x56\x61\x6C\x69\x64","\x49\x73\x45\x6E\x65\x6D\x79","\x49\x73\x44\x6F\x72\x6D\x61\x6E\x74","\x47\x65\x74\x45\x79\x65\x50\x6F\x73\x69\x74\x69\x6F\x6E","\x43\x42\x61\x73\x65\x45\x6E\x74\x69\x74\x79","\x6D\x5F\x76\x65\x63\x4F\x72\x69\x67\x69\x6E","\x47\x65\x74\x50\x72\x6F\x70","\x47\x65\x74\x52\x65\x61\x6C\x59\x61\x77","\x47\x65\x74\x46\x61\x6B\x65\x59\x61\x77","\x47\x65\x74\x57\x65\x61\x70\x6F\x6E","\x47\x65\x74\x4E\x61\x6D\x65","\x67\x33\x73\x67\x31","\x69\x6E\x63\x6C\x75\x64\x65\x73","\x73\x63\x61\x72","\x78\x6D\x31\x30\x31\x34","\x65\x6C\x69\x74\x65","\x64\x65\x73\x65\x72\x74","\x6E\x6F\x76\x61","\x73\x61\x77\x65\x64\x20\x6F\x66\x66","\x52\x61\x67\x65","\x47\x45\x4E\x45\x52\x41\x4C","\x45\x78\x70\x6C\x6F\x69\x74\x73","\x44\x6F\x75\x62\x6C\x65\x74\x61\x70\x20\x66\x61\x73\x74\x20\x72\x65\x63\x6F\x76\x65\x72\x79","\x44\x6F\x75\x62\x6C\x65\x74\x61\x70","\x54\x65\x6C\x65\x70\x6F\x72\x74\x20\x72\x65\x6C\x65\x61\x73\x65","\x65\x78\x70\x6C\x6F\x69\x74","\x48\x69\x64\x65\x20\x73\x68\x6F\x74\x73","\x4C\x65\x67\x69\x74\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x47\x65\x74\x52\x65\x6E\x64\x65\x72\x4F\x72\x69\x67\x69\x6E","\x4C\x69\x6E\x65","\x57\x6F\x72\x6C\x64\x54\x6F\x53\x63\x72\x65\x65\x6E","\x56\x69\x73\x75\x61\x6C\x73","\x57\x6F\x72\x6C\x64","\x56\x69\x65\x77","\x54\x68\x69\x72\x64\x70\x65\x72\x73\x6F\x6E","\x47\x65\x74\x43\x6F\x6C\x6F\x72","","\x53\x74\x72\x69\x6E\x67","\x49\x73\x41\x6C\x69\x76\x65","\x4D\x49\x53\x43","\x43\x43\x53\x50\x6C\x61\x79\x65\x72","\x6D\x5F\x61\x6E\x67\x45\x79\x65\x41\x6E\x67\x6C\x65\x73","\x67\x65\x74","\x72\x65\x76\x65\x72\x73\x65","\x47\x65\x6E\x65\x72\x61\x6C","\x53\x74\x72\x69\x63\x74\x20\x73\x61\x66\x65\x74\x79","\x66\x6C\x6F\x6F\x72","\x72\x6F\x75\x6E\x64","\x47\x72\x61\x64\x69\x65\x6E\x74\x20\x53\x70\x65\x65\x64","\x4C\x61\x74\x65\x6E\x63\x79","\x46\x72\x61\x6D\x65\x74\x69\x6D\x65","\x67\x65\x74\x48\x6F\x75\x72\x73","\x67\x65\x74\x4D\x69\x6E\x75\x74\x65\x73","\x67\x65\x74\x53\x65\x63\x6F\x6E\x64\x73","\x30","\x3A","\x54\x69\x63\x6B\x72\x61\x74\x65","\x56\x65\x72\x64\x61\x6E\x61","\x41\x64\x64\x46\x6F\x6E\x74","\x46\x69\x6C\x6C\x65\x64\x52\x65\x63\x74","\x52\x65\x63\x74","\x4F\x6D\x69\x6E\x6F\x75\x73\x57\x61\x72\x65","\x53\x74\x72\x69\x6E\x67\x43\x75\x73\x74\x6F\x6D","\x74\x77\x6F\x20\x73\x74\x65\x70\x73\x20\x61\x68\x65\x61\x64\x20\x6F\x66\x20\x74\x68\x65\x20\x72\x65\x73\x74","\x47\x72\x61\x64\x69\x65\x6E\x74\x52\x65\x63\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20","\x7C","\x6D\x73","\x70\x69\x6E\x67\x20\x20\x20","\x66\x70\x73\x20\x20\x20","\x46\x61\x6B\x65\x20\x3D\x20","\x74\x6F\x46\x69\x78\x65\x64","\x52\x65\x61\x6C\x20\x3D\x20","\x44\x69\x66\x66\x65\x72\x65\x6E\x63\x65\x20\x3D\x20","\x49\x6E\x76\x65\x72\x74\x65\x64\x20\x3D\x20","\x47\x65\x74\x53\x65\x72\x76\x65\x72\x53\x74\x72\x69\x6E\x67","\x20\x3A\x20","\x47\x65\x74\x4D\x61\x70\x4E\x61\x6D\x65","\x48\x65\x61\x64","\x4E\x65\x63\x6B","\x50\x65\x6C\x76\x69\x73","\x42\x6F\x64\x79","\x54\x68\x6F\x72\x61\x78","\x43\x68\x65\x73\x74","\x55\x70\x70\x65\x72\x20\x63\x68\x65\x73\x74","\x4C\x65\x66\x74\x20\x74\x68\x69\x67\x68","\x52\x69\x67\x68\x74\x20\x74\x68\x69\x67\x68","\x4C\x65\x66\x74\x20\x63\x61\x6C\x66","\x52\x69\x67\x68\x74\x20\x63\x61\x6C\x66","\x4C\x65\x66\x74\x20\x66\x6F\x6F\x74","\x52\x69\x67\x68\x74\x20\x66\x6F\x6F\x74","\x4C\x65\x66\x74\x20\x68\x61\x6E\x64","\x52\x69\x67\x68\x74\x20\x68\x61\x6E\x64","\x4C\x65\x66\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x4C\x65\x66\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x47\x65\x6E\x65\x72\x69\x63","\x74\x61\x72\x67\x65\x74\x5F\x69\x6E\x64\x65\x78","\x68\x69\x74\x62\x6F\x78","\x68\x69\x74\x63\x68\x61\x6E\x63\x65","\x73\x61\x66\x65\x70\x6F\x69\x6E\x74","\x47\x65\x74\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79","\x47\x65\x74\x53\x70\x72\x65\x61\x64","\x47\x65\x74\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73","\x0A","\x53\x70\x72\x65\x61\x64\x20\x3D\x20","\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79\x20\x3D\x20","\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73\x20\x3D\x20","\x50\x69\x6E\x67\x20\x3D\x20","\x50\x72\x69\x6E\x74\x43\x6F\x6C\x6F\x72","\x5B\x54\x41\x52\x47\x45\x54\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x42\x4F\x58\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x43\x48\x41\x4E\x43\x45\x5D\x20\x3D\x20","\x5B\x53\x41\x46\x45\x50\x4F\x49\x4E\x54\x5D\x20\x3D\x20","\x5B\x45\x58\x50\x4C\x4F\x49\x54\x5D\x20\x3D\x20","\x20\x0A","\x46\x61\x6B\x65\x20\x64\x65\x73\x79\x6E\x63","\x41\x74\x20\x74\x61\x72\x67\x65\x74\x73","\x41\x75\x74\x6F\x20\x64\x69\x72\x65\x63\x74\x69\x6F\x6E","\x47\x65\x74\x50\x6C\x61\x79\x65\x72\x73","\x6C\x65\x6E\x67\x74\x68","\x49\x73\x54\x65\x61\x6D\x6D\x61\x74\x65","\x61\x74\x74\x61\x63\x6B\x65\x72","\x64\x6D\x67\x5F\x68\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x50\x6C\x61\x79\x65\x72","\x6D\x5F\x69\x48\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x41\x74\x74\x72\x69\x62\x75\x74\x61\x62\x6C\x65\x49\x74\x65\x6D","\x6D\x5F\x69\x49\x74\x65\x6D\x44\x65\x66\x69\x6E\x69\x74\x69\x6F\x6E\x49\x6E\x64\x65\x78","\x52\x65\x76\x6F\x6C\x76\x65\x72\x20\x46\x69\x78","\x45\x6E\x61\x62\x6C\x65\x64","\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x72\x61\x67\x65\x62\x6F\x74\x4C\x6F\x67\x73","\x52\x65\x67\x69\x73\x74\x65\x72\x43\x61\x6C\x6C\x62\x61\x63\x6B","\x70\x6C\x61\x79\x65\x72\x5F\x68\x75\x72\x74","\x43\x72\x65\x61\x74\x65\x4D\x6F\x76\x65","\x63\x72\x65\x61\x74\x65\x5F\x6D\x6F\x76\x65","\x44\x72\x61\x77","\x64\x72\x61\x77\x49\x74","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x35","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x34","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x33","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x32","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x69\x6E\x76\x65\x72\x74","\x49\x6E\x69\x74\x69\x61\x6C\x69\x7A\x65","\x76\x69\x73\x75\x61\x6C\x73","\x4F\x6E\x48\x75\x72\x74","\x4F\x6E\x42\x75\x6C\x6C\x65\x74\x49\x6D\x70\x61\x63\x74","\x62\x75\x6C\x6C\x65\x74\x5F\x69\x6D\x70\x61\x63\x74","\x6F\x6E\x5F\x64\x72\x61\x77","\x77\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x65\x6C\x63\x6F\x6D\x65\x20\x54\x6F\x20\x54\x61\x6E\x6B\x20\x53\x63\x68\x6F\x6F\x6C","\x50\x72\x69\x6E\x74"];
var master={dir:_$_afb6[0],cycle:false,iteration:1,showArrows:false,showCycle:false,showDegree:false,showInverted:false,getAAInvert:function()
{
	return UI[_$_afb6[4]](_$_afb6[1],_$_afb6[2],_$_afb6[3])
}
,setAAInvert:function()
{
	return UI[_$_afb6[5]](_$_afb6[1],_$_afb6[2],_$_afb6[3])
}
,getInvert:function()
{
	return UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[8],_$_afb6[9])
}
,setVisible:function()
{
	
}
};//0
function GetScriptOption(_0xFE6B)
{
	var _0xFE91=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[8],_0xFE6B);//17
	return _0xFE91
}
function invert()
{
	if(!master[_$_afb6[11]]()|| Entity[_$_afb6[14]](Event[_$_afb6[13]](_$_afb6[12]))!= Entity[_$_afb6[15]]())
	{
		return
	}
	//23
	master[_$_afb6[16]]()
}
function ui()
{
	UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[19],0,0);UI[_$_afb6[21]](_$_afb6[20]);UI[_$_afb6[18]](_$_afb6[22],0,180);UI[_$_afb6[18]](_$_afb6[23],0.01,1);UI[_$_afb6[18]](_$_afb6[24],-180,180);UI[_$_afb6[21]](_$_afb6[25]);UI[_$_afb6[18]](_$_afb6[26],0,5);UI[_$_afb6[18]](_$_afb6[27],0.01,1);UI[_$_afb6[18]](_$_afb6[28],0,16);UI[_$_afb6[21]](_$_afb6[29]);UI[_$_afb6[30]](_$_afb6[9]);UI[_$_afb6[21]](_$_afb6[31]);UI[_$_afb6[30]](_$_afb6[32]);UI[_$_afb6[21]](_$_afb6[33]);UI[_$_afb6[21]](_$_afb6[34]);UI[_$_afb6[39]](_$_afb6[35],[_$_afb6[36],_$_afb6[37],_$_afb6[38]]);UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[40],0,0);UI[_$_afb6[21]](_$_afb6[41]);UI[_$_afb6[30]](_$_afb6[42]);UI[_$_afb6[30]](_$_afb6[43]);UI[_$_afb6[30]](_$_afb6[44]);UI[_$_afb6[21]](_$_afb6[45]);UI[_$_afb6[21]](_$_afb6[17]);UI[_$_afb6[21]](_$_afb6[46]);UI[_$_afb6[30]](_$_afb6[47]);UI[_$_afb6[21]](_$_afb6[45]);UI[_$_afb6[21]](_$_afb6[17]);UI[_$_afb6[21]](_$_afb6[48]);UI[_$_afb6[30]](_$_afb6[49]);UI[_$_afb6[21]](_$_afb6[45]);UI[_$_afb6[21]](_$_afb6[17]);UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[50],0,0);UI[_$_afb6[30]](_$_afb6[51]);UI[_$_afb6[53]](_$_afb6[52],1,58);UI[_$_afb6[55]](_$_afb6[54]);UI[_$_afb6[55]](_$_afb6[56]);UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[57],0,0);var _0x1000D=Global[_$_afb6[58]]();//84
	UI[_$_afb6[30]](_$_afb6[59]);UI[_$_afb6[53]](_$_afb6[60],0,_0x1000D[0]);UI[_$_afb6[53]](_$_afb6[61],0,_0x1000D[1]);UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[62],0,0);UI[_$_afb6[30]](_$_afb6[63]);UI[_$_afb6[30]](_$_afb6[64]);UI[_$_afb6[18]](_$_afb6[17],0,0);UI[_$_afb6[18]](_$_afb6[65],0,0)
}
function yawvalues()
{
	var _0xFDAD=Global[_$_afb6[66]]();//104
	var _0x107C5=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[22]);//105
	var _0x1079F=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[23]);//106
	var _0x10779=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[24]);//107
	var _0x10779=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[24]);//108
	var _0xF9F7=(_0x107C5* Math[_$_afb6[68]]((_0xFDAD)/ _0x1079F)+ _0x10779);//109
	return _0xF9F7
}
function Initialize()
{
	UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[70],yawvalues());UI[_$_afb6[71]](_$_afb6[1],_$_afb6[72],_$_afb6[73],fakelagRando())
}
function radian(_0x1040F)
{
	return _0x1040F* Math[_$_afb6[74]]/ 180.0
}
function ExtendVector(_0xFCEF,_0xFC7D,_0xFCA3)
{
	var _0xFCC9=radian(_0xFC7D);//127
	return [_0xFCA3* Math[_$_afb6[68]](_0xFCC9)+ _0xFCEF[0],_0xFCA3* Math[_$_afb6[75]](_0xFCC9)+ _0xFCEF[1],_0xFCEF[2]]
}
function VectorAdd(_0xFB4D,_0xFB73)
{
	return [_0xFB4D[0]+ _0xFB73[0],_0xFB4D[1]+ _0xFB73[1],_0xFB4D[2]+ _0xFB73[2]]
}
function VectorSubtract(_0xFB4D,_0xFB73)
{
	return [_0xFB4D[0]- _0xFB73[0],_0xFB4D[1]- _0xFB73[1],_0xFB4D[2]- _0xFB73[2]]
}
function VectorMultiply(_0xFB4D,_0xFB73)
{
	return [_0xFB4D[0]* _0xFB73[0],_0xFB4D[1]* _0xFB73[1],_0xFB4D[2]* _0xFB73[2]]
}
function VectorLength(_0x10565,_0xF9D1,_0x1058B)
{
	return Math[_$_afb6[76]](_0x10565* _0x10565+ _0xF9D1* _0xF9D1+ _0x1058B* _0x1058B)
}
function VectorNormalize(_0x105B1)
{
	var _0xFA43=VectorLength(_0x105B1[0],_0x105B1[1],_0x105B1[2]);//153
	return [_0x105B1[0]/ _0xFA43,_0x105B1[1]/ _0xFA43,_0x105B1[2]/ _0xFA43]
}
function VectorDot(_0xFB4D,_0xFB73)
{
	return _0xFB4D[0]* _0xFB73[0]+ _0xFB4D[1]* _0xFB73[1]+ _0xFB4D[2]* _0xFB73[2]
}
function VectorDistance(_0xFB4D,_0xFB73)
{
	return VectorLength(_0xFB4D[0]- _0xFB73[0],_0xFB4D[1]- _0xFB73[1],_0xFB4D[2]- _0xFB73[2])
}
function ClosestPointOnRay(_0xFADB,_0xFAB5,_0xFA8F)
{
	var _0xFB01=VectorSubtract(_0xFADB,_0xFAB5);//169
	var _0xFA1D=VectorSubtract(_0xFA8F,_0xFAB5);//170
	var _0xFA43=VectorLength(_0xFA1D[0],_0xFA1D[1],_0xFA1D[2]);//171
	_0xFA1D= VectorNormalize(_0xFA1D);var _0xFA69=VectorDot(_0xFA1D,_0xFB01);//174
	if(_0xFA69< 0.0)
	{
		return _0xFAB5
	}
	//175
	if(_0xFA69> _0xFA43)
	{
		return _0xFA8F
	}
	//179
	return VectorAdd(_0xFAB5,VectorMultiply(_0xFA1D,[_0xFA69,_0xFA69,_0xFA69]))
}
function Flip()
{
	UI[_$_afb6[5]](_$_afb6[1],_$_afb6[2],_$_afb6[3])
}
var lastHitTime=0.0;//191
var lastImpactTimes=[0.0];//192
var lastImpacts=[[0.0,0.0,0.0]];//197
function OnHurt()
{
	if(GetScriptOption(_$_afb6[35])== 0)
	{
		return
	}
	//204
	if(Entity[_$_afb6[14]](Event[_$_afb6[13]](_$_afb6[12]))!== Entity[_$_afb6[15]]())
	{
		return
	}
	//205
	var _0x103E9=Event[_$_afb6[13]](_$_afb6[77]);//206
	if(_0x103E9== 1|| _0x103E9== 6|| _0x103E9== 7)
	{
		var _0x10117=Global[_$_afb6[78]]();//210
		if(Math[_$_afb6[79]](lastHitTime- _0x10117)> 0.5)
		{
			lastHitTime= _0x10117;Flip()
		}
		
	}
	
}
function OnBulletImpact()
{
	if(GetScriptOption(_$_afb6[35])!== 2)
	{
		return
	}
	//221
	var _0x10117=Global[_$_afb6[78]]();//223
	if(Math[_$_afb6[79]](lastHitTime- _0x10117)< 0.5)
	{
		return
	}
	//224
	var _0x1013D=Entity[_$_afb6[14]](Event[_$_afb6[13]](_$_afb6[12]));//226
	var _0x10293=[Event[_$_afb6[81]](_$_afb6[80]),Event[_$_afb6[81]](_$_afb6[82]),Event[_$_afb6[81]](_$_afb6[83]),_0x10117];//227
	var _0x103C3;//228
	if(Entity[_$_afb6[84]](_0x1013D)&& Entity[_$_afb6[85]](_0x1013D))
	{
		if(!Entity[_$_afb6[86]](_0x1013D))
		{
			_0x103C3= Entity[_$_afb6[87]](_0x1013D)
		}
		else 
		{
			if(Math[_$_afb6[79]](lastImpactTimes[_0x1013D]- _0x10117)< 0.1)
			{
				_0x103C3= lastImpacts[_0x1013D]
			}
			else 
			{
				lastImpacts[_0x1013D]= _0x10293;lastImpactTimes[_0x1013D]= _0x10117;return
			}
			
		}
		//231
		var _0x10059=Entity[_$_afb6[15]]();//245
		var _0x102DF=Entity[_$_afb6[87]](_0x10059);//246
		var _0x10305=Entity[_$_afb6[90]](_0x10059,_$_afb6[88],_$_afb6[89]);//247
		var _0x102B9=VectorMultiply(VectorAdd(_0x102DF,_0x10305),[0.5,0.5,0.5]);//248
		var _0x100CB=ClosestPointOnRay(_0x102B9,_0x103C3,_0x10293);//250
		var _0x100A5=VectorDistance(_0x102B9,_0x100CB);//251
		if(_0x100A5< 128.0)
		{
			var _0x1032B=Local[_$_afb6[91]]();//255
			var _0x10163=Local[_$_afb6[92]]();//256
			var _0x1026D=ClosestPointOnRay(_0x102DF,_0x103C3,_0x10293);//258
			var _0x10247=VectorDistance(_0x102DF,_0x1026D);//259
			var _0x10221=ClosestPointOnRay(_0x10305,_0x103C3,_0x10293);//260
			var _0x101FB=VectorDistance(_0x10305,_0x10221);//261
			var _0x100F1;//263
			var _0x10351;//264
			var _0x10189;//265
			if(_0x100A5< _0x10247&& _0x100A5< _0x101FB)
			{
				_0x100F1= _0x100CB;_0x10351= ExtendVector(_0x100CB,_0x1032B+ 180.0,10.0);_0x10189= ExtendVector(_0x100CB,_0x10163+ 180.0,10.0)
			}
			else 
			{
				if(_0x101FB< _0x10247)
				{
					_0x100F1= _0x10221;var _0x10377=ExtendVector(_0x100CB,_0x1032B- 30.0+ 90.0,10.0);//276
					var _0x1039D=ExtendVector(_0x100CB,_0x1032B- 30.0- 90.0,10.0);//277
					var _0x101AF=ExtendVector(_0x100CB,_0x10163- 30.0+ 90.0,10.0);//278
					var _0x101D5=ExtendVector(_0x100CB,_0x10163- 30.0- 90.0,10.0);//279
					if(VectorDistance(_0x10221,_0x10377)< VectorDistance(_0x10221,_0x1039D))
					{
						_0x10351= _0x10377
					}
					else 
					{
						_0x10351= _0x1039D
					}
					//280
					if(VectorDistance(_0x10221,_0x101AF)< VectorDistance(_0x10221,_0x101D5))
					{
						_0x10189= _0x101AF
					}
					else 
					{
						_0x10189= _0x101D5
					}
					
				}
				else 
				{
					_0x100F1= _0x1026D;_0x10351= ExtendVector(_0x100CB,_0x1032B,10.0);_0x10189= ExtendVector(_0x100CB,_0x10163,10.0)
				}
				
			}
			//267
			if(VectorDistance(_0x100F1,_0x10189)< VectorDistance(_0x100F1,_0x10351))
			{
				lastHitTime= _0x10117;Flip()
			}
			
		}
		//253
		lastImpacts[_0x1013D]= _0x10293;lastImpactTimes[_0x1013D]= _0x10117
	}
	
}
function on_ragebot_fire()
{
	if(!UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[42]))
	{
		return
	}
	//319
	player= Entity[_$_afb6[15]]();weapon= Entity[_$_afb6[93]](player);weaponName= Entity[_$_afb6[94]](weapon);if(!(weaponName[_$_afb6[96]](_$_afb6[95])|| weaponName[_$_afb6[96]](_$_afb6[97])|| weaponName[_$_afb6[96]](_$_afb6[98])|| weaponName[_$_afb6[96]](_$_afb6[99])|| weaponName[_$_afb6[96]](_$_afb6[100])|| weaponName[_$_afb6[96]](_$_afb6[101])|| weaponName[_$_afb6[96]](_$_afb6[102])))
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[108],false);return
	}
	//325
	ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);if(ragebot_target_exploit== 2)
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true)
	}
	else 
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true)
	}
	
}
function on_ragebot_fire5()
{
	if(!UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[47]))
	{
		return
	}
	//346
	player= Entity[_$_afb6[15]]();weapon= Entity[_$_afb6[93]](player);weaponName= Entity[_$_afb6[94]](weapon);if(!(weaponName[_$_afb6[96]](_$_afb6[95])|| weaponName[_$_afb6[96]](_$_afb6[97])|| weaponName[_$_afb6[96]](_$_afb6[98])|| weaponName[_$_afb6[96]](_$_afb6[99])|| weaponName[_$_afb6[96]](_$_afb6[100])|| weaponName[_$_afb6[96]](_$_afb6[101])|| weaponName[_$_afb6[96]](_$_afb6[102])))
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);return
	}
	//352
	ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);if(ragebot_target_exploit== 1)
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true)
	}
	else 
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true)
	}
	
}
var inverter={get:function()
{
	return UI[_$_afb6[4]](_$_afb6[1],_$_afb6[111],_$_afb6[3])
}
,reverse:function()
{
	return UI[_$_afb6[5]](_$_afb6[1],_$_afb6[111],_$_afb6[3])
}
};//375
function deg2rad(_0xFB27)
{
	return _0xFB27* Math[_$_afb6[74]]/ 180.0
}
function angle_to_vec(_0xF95F,_0xF9F7)
{
	var _0xF939=deg2rad(_0xF95F);//383
	var _0xF9D1=deg2rad(_0xF9F7);//384
	var _0xF985=Math[_$_afb6[75]](_0xF939);//385
	var _0xF8ED=Math[_$_afb6[68]](_0xF939);//386
	var _0xF9AB=Math[_$_afb6[75]](_0xF9D1);//387
	var _0xF913=Math[_$_afb6[68]](_0xF9D1);//388
	return [_0xF8ED* _0xF913,_0xF8ED* _0xF9AB,-_0xF985]
}
function trace(_0x104A7,_0x10481)
{
	var _0x104F3=angle_to_vec(_0x10481[0],_0x10481[1]);//392
	var _0x104CD=Entity[_$_afb6[112]](_0x104A7);//393
	_0x104CD[2]+= 50;var _0x10519=[_0x104CD[0]+ _0x104F3[0]* 8192,_0x104CD[1]+ _0x104F3[1]* 8192,(_0x104CD[2])+ _0x104F3[2]* 8192];//395
	var _0x1053F=Trace[_$_afb6[113]](_0x104A7,_0x104CD,_0x10519);//396
	if(_0x1053F[1]== 1.0)
	{
		return
	}
	//397
	_0x10519= [_0x104CD[0]+ _0x104F3[0]* _0x1053F[1]* 8192,_0x104CD[1]+ _0x104F3[1]* _0x1053F[1]* 8192,_0x104CD[2]+ _0x104F3[2]* _0x1053F[1]* 8192];var distance=Math[_$_afb6[76]]((_0x104CD[0]- _0x10519[0])* (_0x104CD[0]- _0x10519[0])+ (_0x104CD[1]- _0x10519[1])* (_0x104CD[1]- _0x10519[1])+ (_0x104CD[2]- _0x10519[2])* (_0x104CD[2]- _0x10519[2]));//400
	_0x104CD= Render[_$_afb6[114]](_0x104CD);_0x10519= Render[_$_afb6[114]](_0x10519);if(_0x10519[2]!= 1|| _0x104CD[2]!= 1)
	{
		return
	}
	//403
	if(UI[_$_afb6[4]](_$_afb6[115],_$_afb6[116],_$_afb6[117],_$_afb6[118]))
	{
		Render[_$_afb6[113]](_0x104CD[0],_0x104CD[1],_0x10519[0],_0x10519[1],UI[_$_afb6[119]](_$_afb6[67],_$_afb6[56]));boo= _$_afb6[120]+ distance;Render[_$_afb6[121]](_0x10519[0],_0x10519[1],0,boo,UI[_$_afb6[119]](_$_afb6[67],_$_afb6[54]))
	}
	//405
	return distance
}
function on_draw()
{
	var _0x10059=Entity[_$_afb6[15]]();//414
	if(!Entity[_$_afb6[122]](_0x10059)||  !UI[_$_afb6[10]](_$_afb6[123],_$_afb6[7],_$_afb6[8],_$_afb6[51]))
	{
		return
	}
	//415
	if(Entity[_$_afb6[84]](_0x10059))
	{
		var _0x1007F;//419
		var _0x10033=Entity[_$_afb6[90]](_0x10059,_$_afb6[124],_$_afb6[125]);//420
		left_distance= trace(_0x10059,[0,_0x10033[1]- UI[_$_afb6[10]](_$_afb6[123],_$_afb6[7],_$_afb6[8],_$_afb6[52])]);right_distance= trace(_0x10059,[0,_0x10033[1]+ UI[_$_afb6[10]](_$_afb6[123],_$_afb6[7],_$_afb6[8],_$_afb6[52])]);if(left_distance< right_distance)
		{
			if(inverter[_$_afb6[126]]())
			{
				inverter[_$_afb6[127]]()
			}
			
		}
		//424
		if(right_distance< left_distance)
		{
			if(!inverter[_$_afb6[126]]())
			{
				inverter[_$_afb6[127]]()
			}
			
		}
		
	}
	
}
function fakelagRando()
{
	var _0xFDAD=Global[_$_afb6[66]]();//439
	var _0xFD87=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[26]);//440
	var _0xFD61=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[27]);//441
	var _0xFD3B=UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[28]);//442
	var _0xFD15=(_0xFD87* Math[_$_afb6[68]]((_0xFDAD)/ _0xFD61)+ _0xFD3B);//443
	return _0xFD15
}
function on_ragebot_fire2()
{
	if(!UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[49]))
	{
		return
	}
	//455
	player= Entity[_$_afb6[15]]();weapon= Entity[_$_afb6[93]](player);weaponName= Entity[_$_afb6[94]](weapon);if(!(weaponName[_$_afb6[96]](_$_afb6[95])|| weaponName[_$_afb6[96]](_$_afb6[97])|| weaponName[_$_afb6[96]](_$_afb6[98])|| weaponName[_$_afb6[96]](_$_afb6[99])|| weaponName[_$_afb6[96]](_$_afb6[100])|| weaponName[_$_afb6[96]](_$_afb6[101])|| weaponName[_$_afb6[96]](_$_afb6[102])))
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[108],false);return
	}
	//461
	ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);if(ragebot_target_exploit== 0)
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],true);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[108],false)
	}
	else 
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[110],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[107],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[106],false);UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[105],_$_afb6[108],false)
	}
	
}
function on_ragebot_fire3()
{
	if(!UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[44]))
	{
		return
	}
	//485
	player= Entity[_$_afb6[15]]();weapon= Entity[_$_afb6[93]](player);weaponName= Entity[_$_afb6[94]](weapon);if(!(weaponName[_$_afb6[96]](_$_afb6[95])|| weaponName[_$_afb6[96]](_$_afb6[97])|| weaponName[_$_afb6[96]](_$_afb6[98])|| weaponName[_$_afb6[96]](_$_afb6[99])|| weaponName[_$_afb6[96]](_$_afb6[100])|| weaponName[_$_afb6[96]](_$_afb6[101])|| weaponName[_$_afb6[96]](_$_afb6[102])))
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],true);return
	}
	//491
	ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);if(ragebot_target_exploit== 2)
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],true)
	}
	else 
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],false)
	}
	
}
function on_ragebot_fire4()
{
	if(!UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[43]))
	{
		return
	}
	//506
	player= Entity[_$_afb6[15]]();weapon= Entity[_$_afb6[93]](player);weaponName= Entity[_$_afb6[94]](weapon);if(!(weaponName[_$_afb6[96]](_$_afb6[95])|| weaponName[_$_afb6[96]](_$_afb6[97])|| weaponName[_$_afb6[96]](_$_afb6[98])|| weaponName[_$_afb6[96]](_$_afb6[99])|| weaponName[_$_afb6[96]](_$_afb6[100])|| weaponName[_$_afb6[96]](_$_afb6[101])|| weaponName[_$_afb6[96]](_$_afb6[102])))
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],true);return
	}
	//512
	ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);if(ragebot_target_exploit== 1)
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],true)
	}
	else 
	{
		UI[_$_afb6[71]](_$_afb6[103],_$_afb6[104],_$_afb6[128],_$_afb6[129],false)
	}
	
}
function HSVtoRGB(_0xFF03,_0xFF9B,_0xFFE7)
{
	var _0xFF75,_0xFEDD,_0xFB73,_0xFF29,_0xFEB7,_0xF939,_0xFF4F,_0xFFC1;//529
	_0xFF29= Math[_$_afb6[130]](_0xFF03* 6);_0xFEB7= _0xFF03* 6- _0xFF29;_0xF939= _0xFFE7* (1- _0xFF9B);_0xFF4F= _0xFFE7* (1- _0xFEB7* _0xFF9B);_0xFFC1= _0xFFE7* (1- (1- _0xFEB7)* _0xFF9B);switch(_0xFF29% 6)
	{
		case 0:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break//539
		case 1:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break//540
		case 2:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break//541
		case 3:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break//542
		case 4:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break//543
		case 5:_0xFF75= 255,_0xFEDD= 0,_0xFB73= 0;break
	}
	//537
	return {r:Math[_$_afb6[131]](_0xFF75* 255),g:Math[_$_afb6[131]](_0xFEDD* 255),b:Math[_$_afb6[131]](_0xFB73* 255)}
}
function getCustomValue(_0xFDF9)
{
	var _0xFDD3=UI[_$_afb6[10]](_$_afb6[123],_$_afb6[7],_$_afb6[67],_0xFDF9);//550
	return _0xFDD3
}
var position={x1:0,y1:0};//552
function watermark()
{
	if(UI[_$_afb6[10]](_$_afb6[6],_$_afb6[7],_$_afb6[67],_$_afb6[59],true))
	{
		var _0x105D7=HSVtoRGB(Global[_$_afb6[66]]()* UI[_$_afb6[10]](_$_afb6[123],_$_afb6[7],_$_afb6[8],_$_afb6[132]),1,1);//564
		const _0x106BB=Math[_$_afb6[130]](Global[_$_afb6[133]]()* 1000/ 1.5);//566
		const _0x105FD=Math[_$_afb6[130]](1/ Global[_$_afb6[134]]());//567
		x1= getCustomValue(_$_afb6[60]);y1= getCustomValue(_$_afb6[61]);var _0x10753= new Date();//572
		var _0x10649=_0x10753[_$_afb6[135]]();//573
		var _0x10695=_0x10753[_$_afb6[136]]();//574
		var _0x10707=_0x10753[_$_afb6[137]]();//575
		var _0x10623=_0x10649<= 9?_$_afb6[138]+ _0x10753[_$_afb6[135]]()+ _$_afb6[139]:_0x10753[_$_afb6[135]]()+ _$_afb6[139];//576
		var _0x1066F=_0x10695<= 9?_$_afb6[138]+ _0x10753[_$_afb6[136]]()+ _$_afb6[139]:_0x10753[_$_afb6[136]]()+ _$_afb6[139];//577
		var _0x106E1=_0x10707<= 9?_$_afb6[138]+ _0x10753[_$_afb6[137]]():_0x10753[_$_afb6[137]]();//578
		var _0x1072D=Global[_$_afb6[140]]();//585
		font= Render[_$_afb6[142]](_$_afb6[141],28,800);font2= Render[_$_afb6[142]](_$_afb6[141],10,600);font3= Render[_$_afb6[142]](_$_afb6[141],7,500);font4= Render[_$_afb6[142]](_$_afb6[141],8,600);font5= Render[_$_afb6[142]](_$_afb6[141],6,600);Render[_$_afb6[143]](x1+ 120,y1- 17,146,50,[30,30,30,140]);Render[_$_afb6[144]](x1+ 118,y1+ 5,150,29,[30,30,30,0]);Render[_$_afb6[144]](x1+ 119,y1- 17,147,50,[30,30,30,155]);Render[_$_afb6[143]](x1+ 120,y1+ 7,146,25,[30,30,30,215]);Render[_$_afb6[146]](x1+ 125,y1- 18,0,_$_afb6[145],[255,255,255,255],font2);Render[_$_afb6[146]](x1+ 125,y1- 5,0,_$_afb6[147],[255,255,255,255],font3);Render[_$_afb6[148]](x1+ 120,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_afb6[148]](x1+ 133,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_afb6[148]](x1+ 120,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_afb6[148]](x1+ 133,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_afb6[146]](x1+ 116,y1+ 15,0,_$_afb6[149]+ _0x105FD,[255,255,255,254],font4);Render[_$_afb6[146]](x1+ 188,y1+ 14,0,_$_afb6[150],[155,155,155,0],font4);Render[_$_afb6[146]](x1+ 188,y1+ 8,0,_$_afb6[150],[155,155,155,0],font4);Render[_$_afb6[146]](x1+ 219,y1+ 15,0,_$_afb6[17]+ _0x106BB+ _$_afb6[151],[255,255,255,220],font4);Render[_$_afb6[146]](x1+ 230,y1+ 16,0,_$_afb6[152],[255,255,255,0],font4);Render[_$_afb6[143]](x1+ 193,y1+ 13,2,15,[155,155,155,255]);Render[_$_afb6[143]](x1+ 128,y1+ 14,21,13,[30,30,30,255]);Render[_$_afb6[144]](x1+ 127,y1+ 14,21,13,[43,253,28,255]);Render[_$_afb6[146]](x1+ 131,y1+ 15,0,_$_afb6[153],[255,255,255,220],font5);Render[_$_afb6[143]](x1+ 199,y1+ 14,5,12,[43,253,28,255]);Render[_$_afb6[143]](x1+ 206,y1+ 17,5,9,[43,253,28,255]);Render[_$_afb6[143]](x1+ 213,y1+ 20,5,6,[43,253,28,255]);Render[_$_afb6[144]](x1+ 199,y1+ 14,6,13,[0,0,0,255]);Render[_$_afb6[144]](x1+ 206,y1+ 17,6,10,[0,0,0,255]);Render[_$_afb6[144]](x1+ 213,y1+ 20,6,7,[0,0,0,255])
	}
	
}
function main()
{
	var _0x1000D=Global[_$_afb6[58]]()
}
function drawIt()
{
	fakeyaw= Local[_$_afb6[92]]();realyaw= Local[_$_afb6[91]]();var _0xFC31=Math[_$_afb6[79]](realyaw)- Math[_$_afb6[79]](fakeyaw);//640
	var _0xFC57=UI[_$_afb6[4]](_$_afb6[1],_$_afb6[2],_$_afb6[3]);//641
	if(UI[_$_afb6[10]](_$_afb6[8],_$_afb6[63]))
	{
		Render[_$_afb6[121]](100,500,0,_$_afb6[154]+ fakeyaw[_$_afb6[155]](2),[247,99,88,255]);Render[_$_afb6[121]](100,520,0,_$_afb6[156]+ realyaw[_$_afb6[155]](2),[247,99,88,255]);Render[_$_afb6[121]](100,540,0,_$_afb6[157]+ Math[_$_afb6[79]](_0xFC31[_$_afb6[155]](2)),[247,99,88,255]);Render[_$_afb6[121]](100,580,0,_$_afb6[158]+ _0xFC57,[99,206,99,250]);Render[_$_afb6[121]](100,600,0,World[_$_afb6[159]]()+ _$_afb6[160]+ Global[_$_afb6[161]](),[99,206,99,250])
	}
	
}
function getHitboxName(_0xFE45)
{
	var _0xFE1F=_$_afb6[120];//653
	switch(_0xFE45)
	{
		case 0:_0xFE1F= _$_afb6[162];break//656
		case 1:_0xFE1F= _$_afb6[163];break//659
		case 2:_0xFE1F= _$_afb6[164];break//662
		case 3:_0xFE1F= _$_afb6[165];break//665
		case 4:_0xFE1F= _$_afb6[166];break//668
		case 5:_0xFE1F= _$_afb6[167];break//671
		case 6:_0xFE1F= _$_afb6[168];break//674
		case 7:_0xFE1F= _$_afb6[169];break//677
		case 8:_0xFE1F= _$_afb6[170];break//680
		case 9:_0xFE1F= _$_afb6[171];break//683
		case 10:_0xFE1F= _$_afb6[172];break//686
		case 11:_0xFE1F= _$_afb6[173];break//689
		case 12:_0xFE1F= _$_afb6[174];break//692
		case 13:_0xFE1F= _$_afb6[175];break//695
		case 14:_0xFE1F= _$_afb6[176];break//698
		case 15:_0xFE1F= _$_afb6[177];break//701
		case 16:_0xFE1F= _$_afb6[178];break//704
		case 17:_0xFE1F= _$_afb6[179];break//707
		case 18:_0xFE1F= _$_afb6[180];break//710
		default:_0xFE1F= _$_afb6[181]
	}
	//654
	return _0xFE1F
}
function ragebotLogs()
{
	ragebot_target= Event[_$_afb6[13]](_$_afb6[182]);ragebot_target_hitbox= Event[_$_afb6[13]](_$_afb6[183]);ragebot_target_hitchance= Event[_$_afb6[13]](_$_afb6[184]);ragebot_target_safepoint= Event[_$_afb6[13]](_$_afb6[185]);ragebot_target_exploit= Event[_$_afb6[13]](_$_afb6[109]);targetName= Entity[_$_afb6[94]](ragebot_target);inaccuracy= Local[_$_afb6[186]]();spread= Local[_$_afb6[187]]();fakeyaw= Local[_$_afb6[92]]();realyaw= Local[_$_afb6[91]]();var _0x1045B=Local[_$_afb6[188]]();//732
	var _0x10435=Math[_$_afb6[130]](1/ Local[_$_afb6[133]]());//733
	if(UI[_$_afb6[10]](_$_afb6[8],_$_afb6[64]))
	{
		Cheat[_$_afb6[194]]([247,99,88,255],_$_afb6[189]+ _$_afb6[190]+ spread+ _$_afb6[189]+ _$_afb6[191]+ inaccuracy+ _$_afb6[189]+ _$_afb6[154]+ fakeyaw+ _$_afb6[189]+ _$_afb6[156]+ realyaw+ _$_afb6[189]+ _$_afb6[192]+ _0x1045B+ _$_afb6[189]+ _$_afb6[193]+ _0x10435+ _$_afb6[189]);Cheat[_$_afb6[194]]([247,99,88,255],_$_afb6[189]+ _$_afb6[195]+ targetName+ _$_afb6[189]+ _$_afb6[196]+ getHitboxName(ragebot_target_hitbox)+ _$_afb6[189]+ _$_afb6[197]+ ragebot_target_hitchance+ _$_afb6[189]+ _$_afb6[198]+ ragebot_target_safepoint+ _$_afb6[189]+ _$_afb6[199]+ ragebot_target_exploit+ _$_afb6[200])
	}
	//734
	_$_afb6[189]+ _$_afb6[191]+ inaccuracy
}
var old_fake_desync=UI[_$_afb6[10]](_$_afb6[1],_$_afb6[2],_$_afb6[201]);//743
var old_at_targets=UI[_$_afb6[10]](_$_afb6[1],_$_afb6[69],_$_afb6[202]);//744
var old_auto_direction=UI[_$_afb6[10]](_$_afb6[1],_$_afb6[69],_$_afb6[203]);//745
var old_yaw_offset=UI[_$_afb6[10]](_$_afb6[1],_$_afb6[69],_$_afb6[70]);//746
var prevent_correction=false;//747
var last_prevent_time=0;//748
var in_act_pha=false;//749
var in_act_pac=false;//750
var in_act_sr=false;//751
function distance(_0xFB4D,_0xFB73)
{
	ax= _0xFB4D[0],ay= _0xFB4D[1],az= _0xFB4D[2];bx= _0xFB73[0],by= _0xFB73[1],bz= _0xFB73[2];dx= ax- bx,dy= ay- by,dz= az- bz;return Math[_$_afb6[76]](dx* dx+ dy* dy+ dz* dz)
}
function distance2D(_0xFB99,_0xFBE5,_0xFBBF,_0xFC0B)
{
	xs= _0xFBBF- _0xFB99,ys= _0xFC0B- _0xFBE5;xs*= xs;ys*= ys;return Math[_$_afb6[76]](xs+ ys)
}
function difference(_0xFB4D,_0xFB73)
{
	if(_0xFB4D> _0xFB73)
	{
		return _0xFB4D- _0xFB73
	}
	else 
	{
		return _0xFB73- _0xFB4D
	}
	
}
function get_nearest_player()
{
	players= Entity[_$_afb6[204]]();local_origin= Entity[_$_afb6[112]](Entity[_$_afb6[15]]());target_origin= 0;target= 0;for(i= 0;i< players[_$_afb6[205]];i++)
	{
		if(!Entity[_$_afb6[122]](players[i]))
		{
			continue
		}
		//779
		if(Entity[_$_afb6[206]](players[i]))
		{
			continue
		}
		//783
		if(Entity[_$_afb6[86]](players[i]))
		{
			continue
		}
		//787
		entity_origin= Entity[_$_afb6[112]](players[i]);if(target=== 0)
		{
			target_origin= [999999,999999,999999]
		}
		//790
		if(distance(local_origin,target_origin)> distance(local_origin,entity_origin))
		{
			target= players[i];target_origin= entity_origin
		}
		
	}
	//778
	return target
}
function player_hurt()
{
	target= Event[_$_afb6[13]](_$_afb6[12]);attacker= Event[_$_afb6[13]](_$_afb6[207]);damage= Event[_$_afb6[13]](_$_afb6[208]);hitgroup= Event[_$_afb6[13]](_$_afb6[77]);if((Entity[_$_afb6[15]]()=== Entity[_$_afb6[14]](target))&& Entity[_$_afb6[15]]()!== Entity[_$_afb6[14]](attacker))
	{
		health= Entity[_$_afb6[90]](Entity[_$_afb6[15]](),_$_afb6[209],_$_afb6[210]);if(hitgroup=== 1&& (health/ damage)>= 2)
		{
			prevent_correction= true
		}
		else 
		{
			prevent_correction= false
		}
		
	}
	
}
function create_move()
{
	local_weapon_id= Entity[_$_afb6[90]](Entity[_$_afb6[93]](Entity[_$_afb6[15]]()),_$_afb6[211],_$_afb6[212]);local_origin= Entity[_$_afb6[90]](Entity[_$_afb6[15]](),_$_afb6[88],_$_afb6[89]);if(UI[_$_afb6[10]](_$_afb6[213]))
	{
		if(local_weapon_id=== 262208)
		{
			in_act_sr= Math[_$_afb6[131]](1/ Globals[_$_afb6[134]]())< 65?true:false;UI[_$_afb6[71]](_$_afb6[1],_$_afb6[72],_$_afb6[214],Math[_$_afb6[131]](1/ Globals[_$_afb6[134]]())< 65?false:true)
		}
		else 
		{
			in_act_sr= false;UI[_$_afb6[71]](_$_afb6[1],_$_afb6[72],_$_afb6[214],true)
		}
		
	}
	//816
	if(UI[_$_afb6[10]](_$_afb6[32]))
	{
		target= get_nearest_player();if(target=== 0||  !Entity[_$_afb6[122]](target))
		{
			in_act_pha= false;UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[202],old_at_targets);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[203],old_auto_direction);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[70],old_yaw_offset);return
		}
		//829
		local_origin= Entity[_$_afb6[112]](Entity[_$_afb6[15]]());target_origin= Entity[_$_afb6[112]](target);if((target_origin[2]> local_origin[2])&& difference(target_origin[2],local_origin[2])> 64&& distance2D(local_origin[0],local_origin[1],target_origin[0],target_origin[1])< 220)
		{
			in_act_pha= true;UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[202],true);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[203],false);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[70],180)
		}
		else 
		{
			in_act_pha= false;UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[202],old_at_targets);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[203],old_auto_direction);UI[_$_afb6[71]](_$_afb6[1],_$_afb6[69],_$_afb6[70],old_yaw_offset)
		}
		
	}
	
}
function main()
{
	ui();Cheat[_$_afb6[217]](_$_afb6[215],_$_afb6[216]);Cheat[_$_afb6[217]](_$_afb6[218],_$_afb6[218]);Cheat[_$_afb6[217]](_$_afb6[219],_$_afb6[220]);Cheat[_$_afb6[217]](_$_afb6[221],_$_afb6[222]);Global[_$_afb6[217]](_$_afb6[215],_$_afb6[223]);Global[_$_afb6[217]](_$_afb6[215],_$_afb6[224]);Global[_$_afb6[217]](_$_afb6[215],_$_afb6[225]);Global[_$_afb6[217]](_$_afb6[215],_$_afb6[226]);Global[_$_afb6[217]](_$_afb6[215],_$_afb6[227]);Global[_$_afb6[217]](_$_afb6[218],_$_afb6[228]);Global[_$_afb6[217]](_$_afb6[221],_$_afb6[229],_$_afb6[219],_$_afb6[230],_$_afb6[231],_$_afb6[218]);Global[_$_afb6[217]](_$_afb6[218],_$_afb6[228],_$_afb6[221],_$_afb6[232],_$_afb6[233]);Global[_$_afb6[217]](_$_afb6[221],_$_afb6[234]);Global[_$_afb6[217]](_$_afb6[221],_$_afb6[235],_$_afb6[141]);UI[_$_afb6[71]](_$_afb6[123],_$_afb6[7],_$_afb6[8],_$_afb6[132],0.1);Global[_$_afb6[237]](_$_afb6[236])
}
main()
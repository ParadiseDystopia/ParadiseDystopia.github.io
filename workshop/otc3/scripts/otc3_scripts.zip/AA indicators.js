UI.AddCheckbox("Anti-Aim Lines");
UI.AddMultiDropdown("Lines", ["Real", "Fake", "Lby"]);
UI.AddCheckbox("Text Based On Line Color")
UI.AddCheckbox("Draw Delta")
UI.AddColorPicker("Real")
UI.AddColorPicker("Fake")
UI.AddColorPicker("Lby")

function getRadians(angle)
{
    return angle * Math.PI / 180;
}

function drawLine(font, label, distance, loc_x, loc_y, loc_z, origin_x, origin_y, val, r, g, b, a)
{
    const xAngle = loc_x + Math.cos(getRadians(val)) * distance;
    const yAngle = loc_y + Math.sin(getRadians(val)) * distance;
    const screenPos = Render.WorldToScreen([xAngle, yAngle, loc_z]);

    if(screenPos)
    {
        const screenX = screenPos[0];
        const screenY = screenPos[1];

        Render.Line(origin_x, origin_y, screenX, screenY, [r, g, b, a]);

        if(UI.GetValue("Text Based On Line Color"))
            Render.StringCustom(screenX, screenY, 1, label, [r, g, b, a], font);
        else
            Render.StringCustom(screenX, screenY, 1, label, [255, 255, 255, a], font);
    }
}

function handleMenu()
{
    const master = UI.GetValue("Anti-Aim Lines");

    UI.SetEnabled("Lines", master);
    UI.SetEnabled("Text Based On Line Color", master);
    UI.SetEnabled("Draw Delta", master);

    const options = UI.GetString("Lines");

    if(options.includes("Real") && master)
        UI.SetEnabled("Real", true);
    else
        UI.SetEnabled("Real", false);

    if(options.includes("Fake") && master)
        UI.SetEnabled("Fake", true);
    else
        UI.SetEnabled("Fake", false);

    if(options.includes("Lby") && master)
        UI.SetEnabled("Lby", true);
    else
        UI.SetEnabled("Lby", false);
}

function getDelta()
{
    const real = Local.GetRealYaw();
    const fake = Local.GetFakeYaw();

    return Math.abs(Math.round(real - fake));
}

function onDraw()
{
    handleMenu();

    if(!UI.GetValue("Anti-Aim Lines"))
        return;

    if(!UI.IsHotkeyActive("Visual", "View", "Thirdperson"))
        return;

    const options = UI.GetString("Lines");

    const local = Entity.GetLocalPlayer();
   
    if(Entity.IsAlive(local))
    {
        const origin = Entity.GetRenderOrigin(local)

        const origin_x = origin[0];
        const origin_y = origin[1];
        const origin_z = origin[2];

        if(origin_x && origin_y && origin_z)
        {
            const originScreen = Render.WorldToScreen([origin_x, origin_y, origin_z]);

            if(originScreen)
            {
                const origScreenX = originScreen[0];
                const origScreenY = originScreen[1];

                const font = Render.AddFont("Small Fonts", 6, 200);

                if(UI.GetValue("Draw Delta"))
                    Render.StringCustom(origScreenX, origScreenY - 8, 1, getDelta().toString(), [255, 255, 255, 255], font);

                if(options.includes("Real"))
                {
                    const real = Local.GetRealYaw();

                    const col = UI.GetColor("Misc", "Real");

                    const r = col[0];
                    const g = col[1];
                    const b = col[2];

                    drawLine(font, "REAL", 25, origin_x, origin_y, origin_z, origScreenX, origScreenY, real, r, g, b, 255);
                }

                if(options.includes("Fake"))
                {
                    const fake = Local.GetFakeYaw();

                    const col = UI.GetColor("Misc", "Fake");

                    const r = col[0];
                    const g = col[1];
                    const b = col[2];

                    drawLine(font, "FAKE", 28, origin_x, origin_y, origin_z, origScreenX, origScreenY, fake, r, g, b, 255);
                }

                if(options.includes("Lby"))
                {
                    const lby = Entity.GetProp(local, "DT_CSPlayer", "m_flLowerBodyYawTarget");

                    const col = UI.GetColor("Misc", "Lby");

                    const r = col[0];
                    const g = col[1];
                    const b = col[2];

                    drawLine(font, "LBY", 30, origin_x, origin_y, origin_z, origScreenX, origScreenY, lby, r, g, b, 255);
                }
            }
        }
    }
}

// Make our call back so we can have cheat draw our things
Cheat.RegisterCallback("Draw", "onDraw");
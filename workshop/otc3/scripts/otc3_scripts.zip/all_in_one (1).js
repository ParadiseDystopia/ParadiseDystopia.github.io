var l = [
    'NWE1Nzc4NzM1YQ==',
    'dHhiZHQ=',
    'WlBOcm4=',
    'SFBXamk=',
    'eGJnUnM=',
    'UmVjdA==',
    'TFdXQ2U=',
    'dXNlcmlk',
    'dG9TdHJpbmc=',
    'MHhlYw==',
    'MHg1',
    'QmFDa20=',
    'ZG15',
    'MHhhMA==',
    'bV9uVGlja0Jhcw==',
    'YUd3dUE=',
    'MHg4OA==',
    'YndoaXRlbGlzdA==',
    'MHhkMg==',
    'RHJhdw==',
    'MHgzMA==',
    'VUptZlQ=',
    'RFRfQmFzZUNvbQ==',
    'VXBRR0o=',
    'MHg2ZQ==',
    'cnJvdW5kc3Rhcg==',
    'MHhmZA==',
    'RkNGSk4=',
    'QWRkQ29sb3JQaQ==',
    'VE9HTWY=',
    'R2V0UmVhbFlhdw==',
    'VFJJUExFIEtJTA==',
    'NTI1ODY4NmE1YQ==',
    'YWlNVFI=',
    'MHhjZA==',
    'd2hpdGVsaXN0',
    'MHg3Ng==',
    'R2V0UmVuZGVyTw==',
    'MHgyYg==',
    'MHg3Zg==',
    'U2V0V2luZG93TQ==',
    'QnV5IHZhbHZlIA==',
    'RXh0ZW5kZWQgYg==',
    'YXRhbg==',
    'VndIbGY=',
    'aW9u',
    'RG9vcnNwYW1tZQ==',
    'MHg3MQ==',
    'MHg0OA==',
    'b3NpdGlvbg==',
    'aW5jbHVkZXM=',
    'MHgxMmQ=',
    'dG8g',
    'SW5zdGFudCBEVA==',
    'MHg0Zg==',
    'MHg4Zg==',
    'UElkSXg=',
    'dW5sb2Fk',
    'bEhYWk0=',
    'MHgxYQ==',
    'U2hpZnQ=',
    'U2ltcGxlciBhdQ==',
    'NjMzMjQ2NmI1YQ==',
    'WGd4blQ=',
    'RG9vcnNwYW0gaw==',
    'cGVlZF9hbW91bg==',
    'MHhmMA==',
    'WGFjdGk=',
    'MHhlYQ==',
    'MHgxMWY=',
    'dG9kaXIgc2xvdw==',
    'NjEzMjU2NmM2Mg==',
    'bGVnaXRfa25pZg==',
    'MHhmNw==',
    'ZWxlbWVudHM=',
    'TW1lWHo=',
    'c1ZtVEc=',
    'UHJpbnQ=',
    'Z3JlbmFkZSBncg==',
    'Q3JlYXRlTW92ZQ==',
    'Y3JvdWNoaW5n',
    'VW5sb2Fk',
    'cXRncmo=',
    'MHgxMjQ=',
    'RXh0cmE=',
    'aXNfbmV4dGxpbg==',
    'MHg2MQ==',
    'MHgzYg==',
    'NGQzZA==',
    'U2JGRVU=',
    'MHhiZA==',
    'MHgxMTg=',
    'MHg2Nw==',
    'YWRl',
    'MHhlYg==',
    'RklSU1QgQkxPTw==',
    'bGFzdF95YXc=',
    'bmV4dGxpbmVfbw==',
    'MHgzZg==',
    'YXR0YWNrZXI=',
    'MHgxMTA=',
    'YXV0b3N0cmFmZQ==',
    'c3RhdGljX3JhZA==',
    'U21XRGw=',
    'VGlja0ludGVydg==',
    'b3ZhYmxl',
    'Rm9udHM=',
    'R2V0Q3Vyc29yUA==',
    'MHhkNQ==',
    'Y250',
    'VGV4dFNpemVDdQ==',
    'eVBtREo=',
    'RVFjY0g=',
    'MHhkYw==',
    'V2luZG93IA==',
    'YkpNR2M=',
    'MHg5Zg==',
    'YXNpbg==',
    'T09GIEFycm93cw==',
    'MHgxMWM=',
    'SmdvYXI=',
    'SmxUbm8=',
    'MHg2OA==',
    'MHhkNA==',
    'dVhBTko=',
    'd1hLR3A=',
    'bGVnaXQga25pZg==',
    'ZWJvdA==',
    'MHgyMA==',
    'TWpTbE8=',
    'YXN0cml1bXRhYg==',
    'b3VudA==',
    'ZkltTU0=',
    'QmxvY2tib3Qgaw==',
    'V29ybGRUb1Njcg==',
    'MHg5YQ==',
    'Y3VzdG9tIGNsYQ==',
    'U2V0QnV0dG9ucw==',
    'MHhmZg==',
    'MHgxMDY=',
    'MHg0YQ==',
    'R2V0RW50aXR5Rg==',
    'YWJz',
    'MHgyNA==',
    'bGFzdF9pZA==',
    'MHg4ZA==',
    'MHhiMQ==',
    'NTg0ZDdhNGQ2YQ==',
    'ZHJhZw==',
    'bGwgdGhpY2tuZQ==',
    'WUJxUmY=',
    'bGFzdF9jaG9rZQ==',
    'MHhjMg==',
    'U09ISlE=',
    'RGlzYWJsZSBvbg==',
    'MHhmMQ==',
    'IG9uIGxpbWJz',
    'YmxvY2tib3RfcA==',
    'cmlnaHQ=',
    'eEdOWWg=',
    'V1VhSG4=',
    'bWdl',
    'MHgxMjE=',
    'cGxheWVyX2RlYQ==',
    'R2V0UGxheWVycw==',
    'U3RhbmRpbmcgYQ==',
    'aEV6S1I=',
    'MHhmNA==',
    'MHgxMTY=',
    'R2V0UHJvcA==',
    'R2V0U2NyZWVuUw==',
    'cnlTaEM=',
    'bXFUaFI=',
    'MHg0MA==',
    'ZmVBSW8=',
    'S3ptcXY=',
    'MHgzMQ==',
    'IGJlZW4gc2V0IA==',
    'aWNrIA==',
    'MHgxMDg=',
    'U2xvdyB3YWxr',
    'U2V0V2luZG93RA==',
    'bV9mbE5leHRQcg==',
    'NTE1Nzc0NzI1OQ==',
    'R3JvdXAg',
    'L3Fya2Mza0E=',
    'ZnBzX2F1dG9kaQ==',
    'cmVkX2Ftb3VudA==',
    'YXBwbHk=',
    'bV92ZWNNaW5z',
    'MHgxMjY=',
    'X2xpbWJz',
    'S2lsbCBPYml0dQ==',
    'R2V0RXllUG9zaQ==',
    'b29mIGFycm93cw==',
    'MHgx',
    'U2V0R3JvdXBNbw==',
    'eXRoRmY=',
    'R2V0VXNlcm5hbQ==',
    'bktrdno=',
    'MHgzNg==',
    'YXJ5',
    'R2V0Q2hhcmdl',
    'MzUzMDUyMzIzOQ==',
    'aXNfc2l6ZWFibA==',
    'Y2dQUlc=',
    'aWZ0',
    'NDc0Njc1NWE3Nw==',
    'VG9sZXJhbmNl',
    'NTE1ODUyNzM1OQ==',
    'aW5ncw==',
    'WU5mQ2E=',
    'MHgxMWU=',
    'MHhi',
    'MHg4Mw==',
    'MHhhNw==',
    'Rmx5bmU=',
    'U2V0R3JvdXBTaQ==',
    'R2V0TW92ZW1lbg==',
    'RFpNb3c=',
    'd2FpdCBmb3Igbw==',
    'SFJmRXE=',
    'cHVzaA==',
    'MHhhMQ==',
    'MHg3Nw==',
    'M2QzZA==',
    'R2V0RW50aXRpZQ==',
    'RG91YmxldGFw',
    'ZmZzZXQ=',
    'YmxvY2tib3Rfcw==',
    'MHg5Nw==',
    'IGFtb3VudA==',
    'NmQ2YzZhNjEzMg==',
    'VFAgb24gcGVlaw==',
    'YmFja3N0YWJfbw==',
    'aGljaw==',
    'MHhjMQ==',
    'QVhaVVk=',
    'd2FpdF9mb3Jfbw==',
    'MHgxMDE=',
    'QmVnaW5UYWI=',
    'THdobEg=',
    'MHg0',
    'd1NSZXY=',
    'VXJ2TUw=',
    'cmFkIGFtb3VudA==',
    'RFRfQ1NQbGF5ZQ==',
    'dGV4dA==',
    'bmx5',
    'MHhlNQ==',
    'MHgxMmI=',
    'MHg4',
    'MHgxMTI=',
    'dE1pbmltdW1EYQ==',
    'V2RjSHk=',
    'aGlnaGVzdF93',
    'MHg3OQ==',
    'QmFja3N0YWIgbw==',
    'UHJlZGljdGlvbg==',
    'b0NyWlE=',
    'SWNvbnM=',
    'MHg4NQ==',
    'NTY2ZDU2MzQ1OQ==',
    'NjczZA==',
    'c3RvbQ==',
    'MHgyNQ==',
    'blBlcVo=',
    'd1dqTlY=',
    'SVVEU1o=',
    'YWNrdHJhY2tpbg==',
    'QWRkU2xpZGVySQ==',
    'MHg0ZA==',
    'REtwRW8=',
    'QnV0dG9u',
    'cm9tVXNlcklE',
    'Y2tlcg==',
    'aXNfbW92YWJsZQ==',
    'R2V0RW5lbWllcw==',
    'Z0dRQlA=',
    'c2NvcmQuZ2cvcQ==',
    'V292ZnE=',
    'V2hpdGVsaXN0',
    'YmFja3RyYWNrIA==',
    'UmVnaXN0ZXJDYQ==',
    'T09GIFNpemU=',
    'SXNBbGl2ZQ==',
    'QW50aS1BaW0=',
    'U2V0VmFsdWU=',
    'MHg2Mg==',
    'U2V0Q2xhblRhZw==',
    'SWdub3JlVGFyZw==',
    'NTg0NjMw',
    'MHg1Mg==',
    'bWhWYmg=',
    'Z3JhZA==',
    'V2dpQVI=',
    'Q0NTUGxheWVy',
    'd1BzQW4=',
    'c2V0IHRvIA==',
    'Z2N4b1E=',
    'MHgyMw==',
    'c3BsaWNl',
    'MHhlZg==',
    'R2V0QnV0dG9ucw==',
    'MHhhZg==',
    'TkJSa20=',
    'MHgxNA==',
    'ZnBkakc=',
    'cmlnaW4=',
    'TGFiZWw=',
    'NmU1NTNk',
    'ZEliQWw=',
    'cHJlZCBhbW91bg==',
    'eEd4YmE=',
    'MHgyMQ==',
    'd2FzX3NwYW1taQ==',
    'ZXJlOg==',
    'Y3VzdG9tX2NsYQ==',
    'SEtUcHY=',
    'NmQ0Njc1NjE1OA==',
    'bWluX3dhbGxfdA==',
    'ZHJhdw==',
    'UmFnZSBBbnRpLQ==',
    'MHg5Yw==',
    'R2V0V2VhcG9u',
    'MHg2NA==',
    'T3ZlcnJpZGVTaA==',
    'U2V0Vmlld0FuZw==',
    'TkNlc1o=',
    'Y3Z6WHg=',
    'MHhiMw==',
    'RGlzYWJsZSBhdQ==',
    'MHg1OQ==',
    'UGJpeGw=',
    'c2VsZWN0ZWQ=',
    'cmVzaXpl',
    'T09GIENvbG9y',
    'YW9JVXg=',
    'Zm9yY2Vfc2FmZQ==',
    'bV92ZWNNYXhz',
    'eWtwZVc=',
    'VnNld2w=',
    'cmFuZG9t',
    'TmRSQlQ=',
    'U2V0RW5hYmxlZA==',
    'c0J4T04=',
    'dGl0bGU=',
    'MHgzYQ==',
    'VGFob21h',
    'c3BlZWQgYW1vdQ==',
    'bEt4dFU=',
    'MHgxMTQ=',
    'Y2ZPT1o=',
    'QW1aeWE=',
    'c3Brb0Y=',
    'b3V0bGluZQ==',
    'MHhjZQ==',
    'bk5HdlA=',
    'c2NEYU8=',
    'ZHRo',
    'c3Vic3RyaW5n',
    'MHhiNA==',
    'cm91bmRfc3Rhcg==',
    'MHgzZA==',
    'd2N6bmU=',
    'ZnhkbkU=',
    'aGV4',
    'cm91bmQ=',
    'MHhmYQ==',
    'MHgzNA==',
    'MHgxYg==',
    'VXhiUEc=',
    'dmVyZGFuYTEyYg==',
    'eFJsZXY=',
    'MHhjOA==',
    'Njg2NDQxM2QzZA==',
    'ZW5j',
    'TllGcnI=',
    'Qm9iaks=',
    'V3RuUGI=',
    'UkVF',
    'b29mX2Fycm93cw==',
    'MHg2Zg==',
    'MHgxMw==',
    'cXVRZUE=',
    'MHg3NQ==',
    'TWF4aW11bSB3YQ==',
    'MHhl',
    'MHhiOQ==',
    'dGFicw==',
    'bWluaW1hbF93aQ==',
    'cmF3VGV4dHVyZQ==',
    'MzM3MDZj',
    'MHhhNQ==',
    'IHRvIA==',
    'NjI0ODU2NzI1YQ==',
    'dGlvbg==',
    'YkhPbFc=',
    'MHg5Yg==',
    'SmNncUk=',
    'c2Vqc2c=',
    'MHgxMGY=',
    'MHhhNA==',
    'Rm9yY2UgU2FmZQ==',
    'ZGlzYWJsZV9hdQ==',
    'MHgyNg==',
    'WFJ0Ym0=',
    'MHhkYQ==',
    'MHhjMA==',
    'aW5kaWNhdG9ycw==',
    'MHg1ZQ==',
    'MHhiZg==',
    'Y0RnQXM=',
    'Y0VPR3I=',
    'Q2hlY2tib3g=',
    'Rm9yY2VUYXJnZQ==',
    'MHg1YQ==',
    'bnNob3Q=',
    'YkNNZUQ=',
    'VFlxa28=',
    'SXNEb3JtYW50',
    'R2V0Vmlld0FuZw==',
    'YUVlZVI=',
    'MHg1ZA==',
    'MHgxMmU=',
    'QmRKRk4=',
    'b29mIHJhZA==',
    'MHg3Yw==',
    'anl2alI=',
    'WW14RlM=',
    'MHg0Nw==',
    'NjI0NzU2NzY1NA==',
    'NjI2ZDQ2NzA2NA==',
    'MHhkMw==',
    'Y3JvdWNo',
    'V2FpdCBmb3Igbw==',
    'RE9VQkxFIEtJTA==',
    'MHgxMGE=',
    'MHhiNg==',
    'MHg1OA==',
    'MHhmNg==',
    'dmVhYmxl',
    'cyBiZWVuIHNldA==',
    'NjMzMzU2NzQ2Mg==',
    'RW5kV2luZG93',
    'c0J5Q2xhc3NJRA==',
    'bnRpdHk=',
    'aml0dGVyIDE4MA==',
    'MHg3Mw==',
    'MHg5Ng==',
    'c01UVG8=',
    'bV92ZWNWZWxvYw==',
    'MHgxMDI=',
    'UmFkaXVz',
    'bnRhZw==',
    'S0lMTElORyBTUA==',
    'RmpGQ1c=',
    'MHhjZg==',
    'dmVhYmxlIGhhcw==',
    'MHgxMTc=',
    'bGVuZ3Ro',
    'TWF4IHdhbGwgdA==',
    'YWxwaGE=',
    'T3NIVE8=',
    'b3ZhYmxlIGhhcw==',
    'QWRkQ2hlY2tibw==',
    'eXB4Z0k=',
    'aXplYWJsZSBoYQ==',
    'MHhiYw==',
    'MHhhYw==',
    'MHg2YQ==',
    'ZmFzdGR1Y2s=',
    'b25ldGFwICAgIA==',
    'MHhjNA==',
    'MHhjMw==',
    'MHhiOA==',
    'MHgxMjk=',
    'MHg1Nw==',
    'MHhmMg==',
    'SXNNZW51T3Blbg==',
    'U2FmVEo=',
    'NTg2Yzc2NjQ1OA==',
    'NmIzZA==',
    'ZnVuY3Rpb24gKA==',
    'd1VlSFg=',
    'MHhm',
    'VG9nZ2xlSG90aw==',
    'NTI2Yw==',
    'aVB3Tmk=',
    'MHhkMQ==',
    'QWRkSG90a2V5',
    'c2FmZV9wb2ludA==',
    'IGtleQ==',
    'MHg5ZQ==',
    'bEVwUWU=',
    'c2JNUlQ=',
    'aW5zdGFudF9kdA==',
    'MHgxZA==',
    'Q3hJVEY=',
    'MHgxZg==',
    'aGlja25lc3M=',
    'RVFmWng=',
    'dVlOUE8=',
    'aGlnaCBleHBsbw==',
    'MHg4Yw==',
    'a2FsR0E=',
    'ZGlzY29yZC5nZw==',
    'VExnZVU=',
    'Y3VzdG9tX2Zk',
    'bV9hbmdFeWVBbg==',
    'YmFja3N0YWIgbw==',
    'Z3JvdXBz',
    'c2hpZnRfYW1vdQ==',
    'UWtWYm8=',
    'MHgxMmM=',
    'aXNfc2VsZWN0aQ==',
    'WVBjQUM=',
    'MHg1NA==',
    'IEBsZW5pbg==',
    'Y29z',
    'MHhkYg==',
    'ZmxDY0Y=',
    'RmlsbGVkUmVjdA==',
    'a25pZmVib3Q=',
    'MHgxMDk=',
    'MHgyOA==',
    'R3VocFk=',
    'MHhmMw==',
    'bHZSbFA=',
    'ZWl1Rlk=',
    'aENFV3M=',
    'MHhkZA==',
    'a2lsbG9iaXR1YQ==',
    'dEFNR1M=',
    'NTQ0ZDc5NGQ2YQ==',
    'b29mX3JhZA==',
    'dG9kaXJlY3Rpbw==',
    'QmxvY2tib3Q=',
    'MHhiZQ==',
    'IGxpbWJz',
    'Zm9McFk=',
    'MHgz',
    'SW5kaWNhdG9ycw==',
    'UVpNYmQ=',
    'MHhlMg==',
    'R2V0TmFtZQ==',
    'MHhiMg==',
    'MHg1MA==',
    'cE1MSHM=',
    'R1hDTUs=',
    'c2lu',
    'eGtkTk8=',
    'MHg1Zg==',
    'UnRsRlI=',
    'NDczOTdhNjEzMw==',
    'RW5kR3JvdXA=',
    'MHhlMQ==',
    'aXplYWJsZQ==',
    'YmFja3dhcmQ=',
    'Z2RTdWI=',
    'S2lsbCBvYml0dQ==',
    'U2V0V2luZG93Uw==',
    'aW1hcnlBdHRhYw==',
    'MHg2MA==',
    'RmtzQmQ=',
    'ZnBzIGF1dG9kaQ==',
    'Zm9WcUs=',
    'R3JhZGllbnRSZQ==',
    'MHgxMTk=',
    'QWlt',
    'SUJrVUk=',
    'SGl3SG0=',
    'aW5kaWNhdG9y',
    'aGlnaGVzdF9o',
    'MHhmNQ==',
    'RmFrZSBhbmdsZQ==',
    'MHgxZQ==',
    'U3RyaW5nQ3VzdA==',
    'YXRhbjI=',
    'bGVz',
    'MHg4YQ==',
    'TGluZXM=',
    'IHNsb3d3YWxr',
    'Y1B5YlQ=',
    'b0lsYmE=',
    'SXNLZXlQcmVzcw==',
    'MHgxMmY=',
    'MHhjYw==',
    'ZnFvTks=',
    'U2FmZSBwb2ludA==',
    'MHhlOQ==',
    'MHhj',
    'MHgxNQ==',
    'WU1Zc1U=',
    'dHBfb25fa2V5',
    'b3Vz',
    'MHgxMjc=',
    'TmN4VEM=',
    'Q1Fta0o=',
    'YWRlIGtleQ==',
    'MHgxMWE=',
    'MHgyMg==',
    'bnVtSUQ=',
    'cWhKWEU=',
    'WnpCZmU=',
    'MHgxMDc=',
    'R2V0TG9jYWxQbA==',
    'aHR0cHM6Ly9kaQ==',
    'MHhhYg==',
    'dHJ6Ukc=',
    'MHhlNg==',
    'VGlja2NvdW50',
    'RlNYWlk=',
    'UmZTWHY=',
    'MHgxOQ==',
    'VENvdXU=',
    'MHgyZA==',
    'b3hBS0w=',
    'MHhkMA==',
    'VHhvSUw=',
    'dVFpa2w=',
    'MHhjYg==',
    'MHgxMjM=',
    'cG9w',
    'Rml1dFc=',
    'MHg3MA==',
    'd1NqeUs=',
    'TVdwc1U=',
    'YXllcg==',
    'ZSBjb2RlXSB9',
    'a25pZmU=',
    'IEBlbGxlcXQgJg==',
    'UFJPWGw=',
    'SW5mbw==',
    'MHg2Ng==',
    'NGE2ODVhNDEzZA==',
    'WHNWRUg=',
    'Q2hva2VkQ29tbQ==',
    'MHhhZQ==',
    'YXV0b3Mgc3BlZQ==',
    'ZHJhd190ZXh0dQ==',
    'MHgxMjU=',
    'MHg1NQ==',
    'MHgxMGI=',
    'MHhiYQ==',
    'cmVjdGlvbg==',
    'WVpVaFg=',
    'c3RhbmRpbmdfYQ==',
    'MHhlZQ==',
    'MHgxMQ==',
    'MHg0Mg==',
    'MHg5MQ==',
    'Vlp6UVE=',
    'UG9seWdvbg==',
    'aXVz',
    'MHhlMw==',
    'RnJhbWV0aW1l',
    'MHgyNw==',
    'SXNUZWFtbWF0ZQ==',
    'MHgy',
    'MHgyYQ==',
    'WWF3IG9mZnNldA==',
    'cG5jS2o=',
    'MHhmYg==',
    'bGVmdA==',
    'MHg1MQ==',
    'ZWVu',
    'MHg2OQ==',
    'MHgxMjA=',
    'TVVMVEkgS0lMTA==',
    'cnVKRUQ=',
    'MHgxMDA=',
    'aWVm',
    'UkltaG8=',
    'MHgxMGM=',
    'bW91bnQ=',
    'bEpaWFQ=',
    'MHg0OQ==',
    'SmpxeUE=',
    'UkZmWUY=',
    'MHgxMjg=',
    'UEhZc1Y=',
    'R2V0SW50',
    'cVdPcFY=',
    'NjM0NzQ2MzA2Mw==',
    'aGxEYUI=',
    'MHhhYQ==',
    'ZmxpcA==',
    'MHhmYw==',
    'b1p3aGI=',
    'Rm9yY2VIaXRibw==',
    'MHgyZg==',
    'REZjUlg=',
    'TWlzYw==',
    'T0NISUY=',
    'MHhmOA==',
    'MHgzNw==',
    'bENRc24=',
    'YW5kcw==',
    'Y2FsbHZvdGUgaw==',
    'Q29tYm8=',
    'dFNhZmV0eQ==',
    'cHJvdG90eXBl',
    'X2NoaWxk',
    'MHhmZQ==',
    'c3RhdGljIHJhZA==',
    'MHgzOQ==',
    'MHg2Yg==',
    'MHhiNw==',
    'MHg0Yg==',
    'b29mX3NpemU=',
    'Z3JhY2VfcGVyaQ==',
    'NTY3YTUxMzI2OA==',
    'R0VORVJBTA==',
    'dHBfb25fcGVlaw==',
    'MHhlNw==',
    'UHJpb3JpdGl6ZQ==',
    'TWlzYyAy',
    'dmVyZGFuYTEy',
    'aXpl',
    'QXN0cml1bXRhYg==',
    'MHg1Mw==',
    'U2xpZGVy',
    'aUxmT1I=',
    'aHdXTlE=',
    'dVNieXA=',
    'MHg5OQ==',
    'UWxRcUo=',
    'RXhwbG9pdHM=',
    'U2VsZWN0IGEgcA==',
    'Q0F4QVE=',
    'Q2xhbnRhZw==',
    'MHg4MA==',
    'b2RpcmVjdGlvbg==',
    'bnZsc2M=',
    'MHgxMTE=',
    'c1NMRUU=',
    'Vm90ZSBraWNr',
    'RmFzdCBkdWNr',
    'ZGhQV2I=',
    'dGl2ZQ==',
    'dG9kaXJfc2xvdw==',
    'U2V0dGluZ3M=',
    'NTc1Njc5NGQ0NA==',
    'NmQ0NjZhNWE1NQ==',
    'Zmxvb3I=',
    'TXZXbU8=',
    'MHhiYg==',
    'MHgxMTU=',
    'MHg5NA==',
    'SW52ZXJ0ZXI=',
    'QmVnaW5XaW5kbw==',
    'WWVoWGE=',
    'MHgw',
    'SFAgLyAy',
    'QmV0dGVyIGF1dA==',
    'T3ZlcnJpZGVUbw==',
    'MHgxMDQ=',
    'c2FmZSBwb2ludA==',
    'aHlwb3Q=',
    'Y2hlY2tfdA==',
    'VnNxWFo=',
    'UHd6dEI=',
    'RXhlY3V0ZUNvbQ==',
    'MHhkOA==',
    'RW5kVGFi',
    'Z3JlbmFkZV9ncg==',
    'MHgxMDU=',
    'MHhiNQ==',
    'MHgxNw==',
    'dGVsZXBvcnQ=',
    'cGt5S04=',
    'MHg0Mw==',
    'MHhhMw==',
    'b3BlbmVk',
    'RmFzdGR1Y2s=',
    'MHgzNQ==',
    'V2VLTGQ=',
    'QWRkR3JhZGllbg==',
    'ZG9vcnNwYW0=',
    'QXV0byBkaXJlYw==',
    'bGF5ZXIu',
    'MHhhOA==',
    'IGhhcyBiZWVuIA==',
    'ZHRfaHBfMg==',
    'U2V0TW92ZW1lbg==',
    'akVQQ2M=',
    'TGluZQ==',
    'MHgyOQ==',
    'bGluZXM=',
    'bV9pSGVhbHRo',
    'ICAgICAgICAgIA==',
    'Zm9yd2FyZA==',
    'MHgxNg==',
    'NmM1YTZkNTkzZA==',
    'Li4u',
    'VUZVYmU=',
    'ZnNzdHk=',
    'T01ERGU=',
    'MHgxMTM=',
    'MHg5OA==',
    'MHg4MQ==',
    'R2V0RmFrZVlhdw==',
    'MHgxMg==',
    'dG9VcHBlckNhcw==',
    'QmVnaW5Hcm91cA==',
    'MTgwIGppdHRlcg==',
    'VFZkZ2g=',
    'Y3JlYXRlZA==',
    'NTg1MjcwNjIzMw==',
    'b2R4T2w=',
    'R2V0VGFyZ2V0',
    'UUZIWlQ=',
    'MHg0Ng==',
    'YmFja3RyYWNrXw==',
    'R05YWVc=',
    'MHgxOA==',
    'Y2VrS1A=',
    'R2V0VGVhbW1hdA==',
    'Q0xQTlo=',
    'bmxabXM=',
    'MHg3OA==',
    'NDUzZA==',
    'aWpBQ3Y=',
    'MHgxMmE=',
    'MHg0NA==',
    'T09GIFJhZA==',
    'MHg5Mg==',
    'bWFuZA==',
    'MHgxMGQ=',
    'MHgxMA==',
    'MHg2NQ==',
    'c3FydA==',
    'R2NaSk0=',
    'd1pHV2Q=',
    'Q0Jhc2VFbnRpdA==',
    'bXVsdGlzZWxlYw==',
    'TGVnaXQgbW9kZQ==',
    'MHg0Yw==',
    'MHgzZQ==',
    'U3RhdGljIHJhZA==',
    'SXNIb3RrZXlBYw==',
    'MHg4Mg==',
    'QWRkTGFiZWw=',
    'MHg0ZQ==',
    'Um5oQ1c=',
    'NTY2ZDc4Njg1YQ==',
    'MHg3Mg==',
    'VmVyZGFuYQ==',
    'QURKb3g=',
    'YmxvY2tib3Q=',
    'S25pZmVib3Q=',
    'MHhjNg==',
    'MHhmOQ==',
    'bGVyYW5jZQ==',
    'R3JpZWYgZ3Jlbg==',
    'ckZkV1Q=',
    'ZmZrUlc=',
    'aml0dGVyXzE4MA==',
    'YXV0b2RpcmVjdA==',
    'TU1Jb1I=',
    'MHg5ZA==',
    'MHhkZQ==',
    'Njg1NzUzNDEzZA==',
    'MHg3ZQ==',
    'V0VueVo=',
    'Wm9sb0w=',
    'MHgxMDM=',
    'cHJpb3JpdGl6ZQ==',
    'MHg0MQ==',
    'aU9FdW0=',
    'MHg0NQ==',
    'ZG14',
    'U3BlZWQgYW1vdQ==',
    'MHg4NA==',
    'MHhkNg==',
    'aWxCVWE=',
    'aW5kZXhPZg==',
    'UnFOdWQ=',
    'YUdQS2Y=',
    'bGFzdF9lbnQ=',
    'MHgyZQ==',
    'MHhjNw==',
    'MHgxYw==',
    'SE9yamo=',
    'NDkzZA==',
    'MHhjYQ==',
    'QWRkRm9udA==',
    'bWlu',
    'cmtjM2tB',
    'dG9sZXJhbmNl',
    'dHAgb24gcGVlaw==',
    'MHg2Yw==',
    'TXpiV1k=',
    'MHg3NA==',
    'dmNqVUE=',
    'RHJhd1RhYkJhcg==',
    'MHg2',
    'aXR5WzBd',
    'YmF0V2VhcG9u',
    'MHgyYw==',
    'UXZkY1o=',
    'bmFtZQ==',
    'R2V0SGl0Ym94UA==',
    'bGxiYWNr',
    'c3Vic3Ry',
    'aWNvbg==',
    'bV9pQ2xpcDE=',
    'Q0Jhc2VQbGF5ZQ==',
    'd2Fsaw==',
    'UmFnZQ==',
    'MHhjNQ==',
    'UmVzZXQgc2V0dA==',
    'MHg1Yg==',
    'MHgxMWI=',
    'R2V0VmFsdWU=',
    'MHhhZA==',
    'MHhlOA==',
    'bV9mbER1Y2tBbQ==',
    'dWNZdWQ=',
    'MHg4OQ==',
    'cWFrYWI=',
    'MHgzMw==',
    'S1pyUmY=',
    'MHg4Yg==',
    'ZWhQS1c=',
    'emVhYmxl',
    'WktmYnE=',
    'MHg3Yg==',
    'bnNob3Qga2V5',
    'R2V0Q29sb3I=',
    'TWlzY2VsbGFuZQ==',
    'c2l2ZSBncmVuYQ==',
    'UmVhbHRpbWU=',
    'MHhhOQ==',
    'TklpU1I=',
    'MHg5',
    'cUFyQ1E=',
    'emVhYmxlIGhhcw==',
    'MHhlZA==',
    'MHhlNA==',
    'bEJOdHI=',
    'MHg3YQ==',
    'MHg1Ng==',
    'cG9pbnQ=',
    'RXBVU1g=',
    'c2hpZnQ=',
    'aVVWQkc=',
    'YXV0b3Nfc3BlZQ==',
    'MHg5NQ==',
    'RW5hYmxlTG9ncw=='
];
(function (a, b) {
    var c = function (d) {
        while (--d) {
            a['push'](a['shift']());
        }
    };
    c(++b);
}(l, 0xd0));
var m = function (a, b) {
    a = a - 0x0;
    var c = l[a];
    if (m['iAocMY'] === undefined) {
        (function () {
            var f;
            try {
                var h = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
                f = h();
            } catch (i) {
                f = window;
            }
            var g = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            f['atob'] || (f['atob'] = function (j) {
                var k = String(j)['replace'](/=+$/, '');
                var n = '';
                for (var o = 0x0, p, q, r = 0x0; q = k['charAt'](r++); ~q && (p = o % 0x4 ? p * 0x40 + q : q, o++ % 0x4) ? n += String['fromCharCode'](0xff & p >> (-0x2 * o & 0x6)) : 0x0) {
                    q = g['indexOf'](q);
                }
                return n;
            });
        }());
        m['ZqbBXu'] = function (e) {
            var f = atob(e);
            var g = [];
            for (var h = 0x0, j = f['length']; h < j; h++) {
                g += '%' + ('00' + f['charCodeAt'](h)['toString'](0x10))['slice'](-0x2);
            }
            return decodeURIComponent(g);
        };
        m['EDcHKL'] = {};
        m['iAocMY'] = !![];
    }
    var d = m['EDcHKL'][a];
    if (d === undefined) {
        c = m['ZqbBXu'](c);
        m['EDcHKL'][a] = c;
    } else {
        c = d;
    }
    return c;
};
var a = [
    m('0x172'),
    m('0x1e6'),
    m('0xc0'),
    m('0x370'),
    m('0xfe'),
    m('0x2e1'),
    m('0x12b'),
    m('0x127') + m('0x2d4') + 'de',
    m('0x395'),
    m('0x308'),
    m('0x2d9'),
    'DT\x20Setting' + 's',
    m('0xab'),
    m('0x179') + 'ed',
    m('0x108') + m('0x247') + '\x20',
    m('0x22b') + m('0x26c'),
    m('0x2ed'),
    m('0x171') + 'om',
    m('0x19b'),
    m('0x25e') + m('0x245'),
    m('0x18c'),
    'agNII',
    m('0x154'),
    'base64',
    m('0x185'),
    m('0x31c'),
    m('0x2fe'),
    m('0x32') + m('0x17'),
    m('0x1d7'),
    m('0x1a8'),
    'tQQnS',
    m('0x49'),
    m('0x241') + 't',
    m('0x22a'),
    m('0x2e9'),
    m('0x2b5'),
    'wait_for_o' + m('0xd1'),
    m('0x1b6'),
    m('0xd4'),
    m('0x30c') + m('0x64'),
    m('0x9e'),
    m('0x38d'),
    m('0x1df'),
    m('0xad'),
    m('0x248'),
    m('0x2f2'),
    m('0x98'),
    m('0x326'),
    m('0x2d7'),
    m('0xcf') + m('0x2d') + m('0x388'),
    m('0x55'),
    m('0x25f'),
    m('0x384') + m('0x3a2'),
    m('0x137'),
    'last_y',
    m('0x57'),
    m('0x10f'),
    m('0x1a0'),
    m('0xcc'),
    m('0x28a'),
    m('0x27b'),
    m('0x3a'),
    m('0x34d'),
    m('0x68') + 't',
    'VzuQI',
    m('0xf7') + m('0xac'),
    m('0x46'),
    m('0x281'),
    m('0x5b'),
    'GetViewAng' + m('0x173'),
    m('0x65'),
    m('0x3a8') + m('0xbc'),
    m('0xe3') + m('0xd1'),
    m('0xb0'),
    m('0xdd'),
    m('0x374') + m('0x42'),
    m('0x208'),
    m('0x20a'),
    m('0x3a1') + m('0x1b5'),
    m('0x24e'),
    m('0x1bd'),
    m('0x380'),
    m('0x161') + m('0x15d'),
    m('0x59'),
    m('0x2bc') + 'r',
    m('0x144') + 'ry',
    m('0x2b6'),
    m('0x212'),
    m('0x2aa'),
    m('0x310') + 'fakeduck\x20h' + m('0x6c'),
    m('0x141'),
    m('0x2eb'),
    m('0x11a'),
    m('0x386'),
    m('0x167') + 'ct',
    m('0x52') + 'et',
    m('0x302'),
    m('0x30f') + m('0x100') + m('0x398') + m('0x31b'),
    m('0x20'),
    m('0x8'),
    m('0x34c') + 'r',
    m('0x16f') + 's',
    'VhwfW',
    m('0x243'),
    m('0xa3'),
    m('0xa') + 't',
    m('0x13a'),
    m('0x283'),
    m('0x240'),
    m('0xeb') + m('0x217') + m('0x37'),
    m('0x1f6'),
    m('0x1f7') + 'od',
    m('0x1f9'),
    m('0xcd'),
    m('0x319'),
    m('0x116') + 'ey',
    m('0x1af') + 'd',
    m('0x36f') + m('0xf6'),
    m('0x178'),
    m('0x1c5'),
    m('0x261'),
    m('0x31') + m('0x28'),
    m('0x2d3') + m('0x183'),
    m('0x13'),
    m('0x41'),
    m('0x4b') + m('0x2b8'),
    m('0x5f'),
    m('0x270'),
    m('0x12c'),
    m('0xe0') + m('0x3b6') + m('0x11'),
    m('0x45'),
    m('0x2a7'),
    m('0x36d') + m('0x1ca'),
    m('0x23'),
    m('0x32e') + m('0x66'),
    m('0x23a') + 't',
    m('0x387'),
    m('0x177'),
    m('0x338'),
    m('0x13b'),
    m('0x39c') + m('0xb7') + '\x20has\x20been\x20' + m('0x5a'),
    m('0x273') + 'y',
    'm_angRotat' + m('0x314'),
    m('0xb5'),
    m('0x22d'),
    m('0x82') + 'point',
    m('0x83'),
    m('0x33'),
    m('0x1fe'),
    m('0x7f'),
    m('0x211'),
    m('0x194'),
    m('0x300') + 't',
    m('0x67'),
    m('0x14e'),
    m('0x181'),
    m('0x32f') + m('0x366'),
    m('0x8e'),
    m('0x23c') + m('0xbc'),
    m('0x139'),
    m('0x288'),
    m('0x21f') + 'w',
    m('0x24b'),
    m('0x359'),
    m('0x186'),
    m('0x2ba'),
    'GXCMK',
    m('0x39f'),
    m('0x76') + m('0x3b5'),
    m('0x107'),
    m('0x6d') + m('0xf6'),
    m('0x22e') + m('0x1d0'),
    m('0x18f') + m('0x47') + m('0x2a9'),
    m('0x25b'),
    m('0x18e') + m('0x1a4'),
    'Frametime',
    m('0x151'),
    m('0xef'),
    m('0x279') + m('0x214'),
    m('0x21'),
    m('0x39b'),
    m('0x396'),
    m('0x263'),
    m('0x355') + m('0x38'),
    'verdana10',
    m('0x17c'),
    'is_nextlin' + 'e',
    m('0x118'),
    m('0x2ef'),
    m('0x35d'),
    m('0xff'),
    m('0x2fc'),
    m('0x202'),
    m('0x1ad') + 'ands',
    m('0x264'),
    m('0xec'),
    m('0xf8'),
    m('0x335') + m('0x1d0'),
    m('0x267'),
    m('0xce'),
    m('0x85'),
    m('0x114'),
    m('0x2fa'),
    m('0x1ee'),
    m('0x339'),
    m('0x2b7') + m('0x318'),
    m('0x70') + m('0x124'),
    m('0x2d2'),
    'IsEnemy',
    m('0x289'),
    m('0x352') + m('0x318'),
    m('0x1a3'),
    m('0x120'),
    m('0x239'),
    m('0x3ad') + 'e',
    m('0x4d'),
    m('0x77') + m('0x173'),
    m('0x193'),
    m('0x6e'),
    m('0x15b'),
    m('0x1da'),
    m('0x274') + 't',
    m('0x44'),
    m('0x327') + 'ey',
    m('0x236'),
    m('0x84'),
    m('0x37b'),
    m('0x278') + m('0x1be'),
    m('0x4e'),
    m('0x296'),
    'rad_amount',
    m('0x294'),
    m('0x86'),
    m('0x51'),
    m('0x224') + m('0x286'),
    m('0x8c'),
    m('0x157'),
    'm_hGroundE' + m('0xee'),
    m('0x2f'),
    m('0x3a9'),
    m('0x182'),
    '5533646c5a' + '773d3d',
    m('0x80'),
    m('0x30f') + m('0x350'),
    m('0x2dd'),
    m('0x102'),
    m('0x11f'),
    m('0x1fc'),
    m('0x24'),
    m('0x142'),
    m('0x287') + m('0x344'),
    m('0x2d5'),
    m('0x40'),
    m('0x15f'),
    m('0x140'),
    m('0xf5'),
    'open_key',
    m('0x1d1'),
    m('0x3b3') + 'e',
    m('0x101') + 'x',
    m('0x390'),
    m('0x25'),
    m('0xc') + m('0xd1'),
    m('0x203'),
    m('0x7e'),
    m('0x16d'),
    m('0x36b'),
    m('0x8a'),
    m('0x391') + m('0x1ff'),
    'GetWeapon',
    m('0x2ab'),
    m('0x306') + 'L',
    'doorspam',
    m('0x220'),
    'xcixi',
    'jitter',
    m('0x2f3'),
    m('0x365') + m('0x366'),
    m('0x271'),
    m('0x1a') + m('0x28'),
    m('0x15') + m('0x328') + 't',
    m('0x130') + 'nt',
    m('0x291'),
    m('0x1fa'),
    m('0x2f6'),
    m('0x255'),
    m('0x1eb') + m('0x399'),
    'SetValue',
    m('0xbd'),
    m('0x219'),
    m('0xa9'),
    m('0x12a') + m('0x3a0'),
    m('0x325') + m('0x218') + m('0x28f') + '3d',
    m('0x1dc') + m('0x18') + m('0x1ab') + '3d',
    m('0x3ac'),
    m('0x9d'),
    m('0x2cd'),
    m('0x12a') + m('0x3a0'),
    m('0x23f') + m('0x258'),
    m('0x1d4'),
    'Backtrack\x20' + m('0x175'),
    m('0x1a6'),
    m('0x307') + '5778735a57' + m('0x3b2') + m('0xa7'),
    m('0x90')
];
(function (n, o) {
    var p = function (q) {
        for (; --q;) {
            n[m('0xe')](n[m('0x2e2')]());
        }
    };
    p(++o);
}(a, 0x1ef));
var b = function (n, o) {
    n = n - 0x0;
    var p = a[n];
    return p;
};
var _0x2f10 = [
    m('0x2e6'),
    '',
    m('0x34'),
    'C',
    'D',
    'E',
    'F',
    'G',
    'H',
    m('0x351'),
    m('0x280'),
    m('0x200') + 's2',
    m('0x93'),
    'rect',
    m('0x56'),
    m('0x27'),
    '\x0a',
    m('0x12f'),
    b(m('0x22f')),
    m('0xa4'),
    b(m('0x10c')),
    m('0x369') + 's',
    b(m('0x2c')),
    'x',
    'y',
    'w',
    'h',
    b(m('0x8f')),
    b(m('0x1f3')),
    m('0x236'),
    b(m('0xb1')),
    'id',
    m('0x44'),
    m('0x7f'),
    b(m('0x5c')),
    'dx',
    'dy',
    'x2',
    'y2',
    b(m('0x234')),
    m('0x298'),
    b(m('0x1b2')),
    b(m('0x1e7')),
    b(m('0x22')),
    m('0x331'),
    m('0xb6') + m('0x97'),
    m('0xfc'),
    b(m('0x170')),
    b(m('0x1d5')),
    m('0x377'),
    b(m('0xa1')),
    b(m('0x2f9')),
    b(m('0x10a')),
    m('0x161') + m('0x103') + m('0xea') + m('0xba'),
    m('0x39c') + m('0xb7'),
    m('0x1b0') + 're',
    b(m('0x301')),
    m('0x255'),
    b(m('0x1cf')),
    b(m('0x276')),
    b(m('0x342')),
    b(m('0x1e3')),
    b(m('0x373')),
    b(m('0x35b')),
    b(m('0x24f')),
    m('0x36') + m('0x259') + m('0x1f8') + m('0x24a'),
    '5657783063' + m('0x6f') + m('0x117'),
    m('0xbb') + m('0x111') + m('0x2a5'),
    m('0x2e7') + m('0x53'),
    m('0x39e') + m('0x146') + m('0x33f'),
    b(m('0x330')),
    m('0x1') + m('0x37a') + m('0x266'),
    b(m('0x1aa')),
    b(m('0x26f')),
    b('0x32'),
    b(m('0x10e')),
    m('0x27e') + m('0x15a') + m('0x112'),
    m('0xdf') + m('0xb8'),
    b(m('0xae')),
    b(m('0x28e')),
    m('0x3ad') + 'e',
    m('0x113') + ')\x20{\x20[nativ' + m('0x1a5'),
    b(m('0x206')),
    b(m('0x2f7')),
    m('0xa8'),
    m('0x29d'),
    b(m('0x2a2')),
    m('0x2ef'),
    b(m('0x17f')),
    b(m('0x5')),
    m('0x228'),
    b(m('0x2a3')),
    m('0x348') + m('0x14'),
    b(m('0x2a')),
    b(m('0x7')),
    b('0x8'),
    m('0x3ab') + m('0xe9'),
    m('0x3ab') + m('0xfa') + m('0x398') + m('0x31b'),
    b(m('0x3aa')),
    m('0x9f'),
    m('0x9') + m('0x2ce'),
    m('0x9') + m('0x2da') + m('0x398') + m('0x31b'),
    m('0x41'),
    b(m('0x1f4')),
    m('0x20'),
    m('0x2ba'),
    m('0x18a'),
    m('0x22d'),
    'DrawTabBar',
    m('0x1ec'),
    m('0x1ef'),
    m('0xe'),
    m('0x3a3'),
    m('0x88'),
    m('0x19f'),
    b(m('0x75')),
    m('0x38c') + m('0x1d3'),
    m('0x223') + m('0x20d'),
    m('0x237'),
    m('0x7b') + m('0x32d') + m('0x2bd'),
    m('0x160') + m('0x3b0'),
    b(m('0x174')),
    m('0x222'),
    m('0xfd') + m('0x1b'),
    m('0x165') + 'r',
    m('0x1f1'),
    b(m('0x25d')),
    b(m('0x192')),
    'shift\x20amou' + 'nt',
    b('0xc9'),
    b(m('0x31d')),
    m('0x282'),
    b('0xb0'),
    m('0x8d') + 'nt',
    m('0x13b'),
    m('0x12e') + m('0x28'),
    m('0x226') + m('0x14b'),
    b('0x122'),
    b(m('0x2df')),
    m('0x23b'),
    m('0x16c'),
    m('0x34c') + 'r',
    b(m('0x29')),
    b(m('0x2b1')),
    m('0x4a') + m('0x245'),
    b(m('0x2fb')),
    m('0xda'),
    'oof\x20size',
    b(m('0xde')),
    'Patched\x20by' + m('0x1a7') + m('0x136'),
    'https://di' + m('0x47') + m('0x2a9'),
    m('0x19') + m('0x11c'),
    m('0x36c') + 'ey',
    b(m('0x367')),
    m('0x287') + m('0x187'),
    m('0xe3') + m('0x2d1'),
    b(m('0x2ca')),
    m('0x4f'),
    m('0x2c3'),
    b(m('0x382')),
    'standing_a' + m('0x1d3'),
    m('0x28b') + m('0x314'),
    b(m('0x188')),
    m('0xc4') + m('0x215') + m('0x2bd'),
    m('0x144') + 'ry',
    b(m('0x180')),
    b(m('0x143')),
    'min_wall_t' + m('0x124'),
    b(m('0xcb')),
    b(m('0x60')),
    b(m('0x1c1')),
    m('0x6d') + m('0xf6'),
    b(m('0xd0')),
    b('0x5c'),
    m('0x384') + m('0x3a2'),
    m('0x15') + m('0x328') + 't',
    b(m('0xe7')),
    m('0x11b') + m('0x3a6'),
    b(m('0x105')),
    'legit_knif' + m('0x366'),
    m('0xc9'),
    b(m('0x35e')),
    b(m('0x29a')),
    b(m('0x73')),
    m('0x147'),
    b('0xdf'),
    b(m('0x2e5')),
    b(m('0x106')),
    m('0x17d') + m('0x383'),
    b(m('0xb4')),
    b(m('0xdb')),
    m('0x323'),
    m('0x0'),
    m('0x19'),
    'I',
    m('0xb2') + m('0x37c') + 'ss',
    m('0x381') + m('0x176'),
    m('0x324') + m('0x148') + 'n',
    b(m('0x376')),
    b(m('0x394')),
    m('0x256'),
    m('0x1e5'),
    b(m('0x2a6')),
    b('0x11d'),
    m('0x3a7') + m('0x3b0'),
    b(m('0x1b3')),
    b('0x6d'),
    b(m('0xd8')),
    m('0x26a'),
    m('0x4c'),
    b(m('0xa6')),
    m('0x20b'),
    m('0x315') + 'r',
    b(m('0x33e')),
    m('0x149'),
    b(m('0x128')),
    m('0x299') + 'nt',
    m('0x1fd'),
    b(m('0x358')),
    b(m('0x32b')),
    m('0x275'),
    m('0x5d'),
    m('0x216'),
    m('0x209') + m('0x23d'),
    m('0x2f8'),
    b('0x90'),
    b(m('0x18d')),
    b(m('0x158')),
    b(m('0xf4')),
    m('0xc3') + m('0x2e0'),
    m('0x30a'),
    b(m('0x13d')),
    b('0x38'),
    m('0x1a9'),
    m('0x2c0') + m('0x2'),
    'PI',
    m('0x156'),
    b('0xa6'),
    b(m('0x2b4')),
    m('0x254') + 'e',
    b(m('0x397')),
    m('0x232'),
    b(m('0x26e')),
    b(m('0x316')),
    b(m('0x1f0')),
    m('0x3a4'),
    b(m('0x293')),
    b(m('0x329')),
    m('0x375'),
    m('0x227'),
    m('0x312'),
    b(m('0x39')),
    m('0x72') + m('0x169'),
    b(m('0x2c5')),
    m('0x58'),
    m('0x12d') + 'gles',
    b(m('0x2ff')),
    b(m('0x1bf')),
    m('0x2fd') + m('0x2b3'),
    m('0x39d') + m('0x162') + 'k',
    m('0x26') + 'r',
    m('0x2f5') + 'e',
    b(m('0x2bf')),
    m('0x246'),
    m('0x2be'),
    b(m('0x15c')),
    b(m('0x341')),
    b(m('0x2f0')),
    b(m('0x244')),
    m('0x2a0'),
    b(m('0x371')),
    b(m('0x2a1')),
    b(m('0x28d')),
    m('0x15e'),
    m('0x1c8'),
    m('0x385'),
    m('0xf3') + m('0x2b2'),
    m('0x35c'),
    m('0x2a8'),
    b(m('0x265')),
    m('0x279') + m('0x214'),
    m('0x2c6') + m('0x36a'),
    m('0xe2'),
    'fd',
    m('0x33b'),
    b(m('0x1b1')),
    b(m('0xc1')),
    b(m('0x30e')),
    b(m('0x50')),
    m('0x2b9'),
    m('0x37e') + 'd',
    b(m('0x135')),
    b(m('0xbe')),
    b(m('0x29b')),
    m('0x21e'),
    m('0x2bb'),
    m('0x6b') + 'ng',
    'grace_peri' + 'od',
    b(m('0x345')),
    m('0x311') + m('0x3d') + 'g',
    m('0x2e2'),
    m('0x2ee'),
    m('0x346') + 'D!',
    m('0xe4') + 'L',
    b(m('0x153')),
    m('0x1cd'),
    'ULTRA\x20KILL',
    b(m('0x152')),
    m('0x34a'),
    m('0x71'),
    m('0x9a') + 't',
    b(m('0x13c')),
    m('0x38a') + 'th',
    m('0x336'),
    'cm',
    b(m('0x1c7')),
    m('0x320')
];
var SenseUI = {};
SenseUI[_0x2f10[0x0]] = ![];
var gs_windows = {};
var gs_curwindow = _0x2f10[0x1];
var gs_curgroup = _0x2f10[0x1];
var gs_curtab = _0x2f10[0x1];
var gs_curinput = _0x2f10[0x1];
var c = {};
c['id'] = _0x2f10[0x1];
c['x'] = 0x0;
c['y'] = 0x0;
c['elements'] = {};
c[b(m('0x1d5'))] = {};
c[b(m('0x170'))] = ![];
c[m('0x377')] = _0x2f10[0x1];
c[m('0xb6') + m('0x97')] = 0x0;
var gs_curchild = c;
var gs_m = [];
var gs_isblocked = ![];
var gs_dontmove = ![];
var d = {};
d['id'] = _0x2f10[0x1];
d[m('0x133') + 'ng'] = ![];
var gs_curbind = d;
SenseUI[_0x2f10[0x2]] = {
    'rage': [
        _0x2f10[0x3],
        0x5
    ],
    'legit': [
        _0x2f10[0x4],
        0x2
    ],
    'visuals': [
        _0x2f10[0x5],
        0x2
    ],
    'settings': [
        _0x2f10[0x6],
        0x3
    ],
    'skinchanger': [
        _0x2f10[0x7],
        0x1
    ],
    'playerlist': [
        _0x2f10[0x8],
        0x0
    ]
};
SenseUI[_0x2f10[0x9]] = {
    'verdana12': Render[b(m('0x38e'))](_0x2f10[0xa], 0x8, 0x190),
    'verdana12b': Render[b(m('0x38e'))](_0x2f10[0xa], 0x8, 0x2bc),
    'verdana10': Render[m('0x2a7')](_0x2f10[0xa], 0x6, 0x190),
    'astriumtabs': Render[m('0x2a7')](_0x2f10[0xb], 0x2a, 0x190)
};
var ren = {};
ren[_0x2f10[0xc]] = function (o, p, q, r, s) {
    Render[m('0x2ec')](o, p, q, r, s);
};
ren[_0x2f10[0xd]] = function (o, p, q, r, s) {
    Render[b(m('0x138'))](o, p, q, r, s);
};
ren[_0x2f10[0xe]] = function (o, p, q, r, s, t, u) {
    Render[b(m('0xf9'))](o, p, q, r, u ? 0x0 : 0x1, s, t);
};
ren[_0x2f10[0xf]] = function (o, p, q, r, s) {
    Render[m('0x171') + 'om'](o, p, 0x0, q, r, s);
};
function gs_inbounds(o, p, q) {
    var r = o;
    if (r[0x0] > p[0x0] && r[0x0] < q[0x0] && r[0x1] > p[0x1] && r[0x1] < q[0x1]) {
        return !![];
    }
    return ![];
}
function gs_log(n) {
    if (SenseUI[_0x2f10[0x0]]) {
        Cheat[m('0x334')](n + _0x2f10[0x10]);
    }
}
function gs_clamp(n, o, p) {
    if (n > p) {
        if (m('0xb') !== m('0x3')) {
            return p;
        } else {
            ren[_0x2f10[0xc]](_0x39e7x2a[_0x2f10[0x17]] - _0x39e7x2e, _0x39e7x2a[_0x2f10[0x18]] - _0x39e7x2e, _0x39e7x2a[_0x2f10[0x19]] + _0x39e7x2e * 0x2, _0x39e7x2a[_0x2f10[0x1a]] + _0x39e7x2e * 0x2, _0x39e7x11);
        }
    }
    if (o > n) {
        return o;
    }
    return n;
}
gs_windows = [];
var gs_keystates = [];
var gs_keystates2 = [];
var first = !![];
function gs_newelement() {
    var n = gs_windows[gs_curwindow];
    var o = n[_0x2f10[0x11]][gs_curgroup];
    return [
        n,
        o
    ];
}
function gs_runkeydown() {
    i = 0x1;
    for (; i < 0xa4; i++) {
        gs_keystates[i] = ![];
        if (Input[b(m('0x290'))](i) && !gs_keystates2[i]) {
            gs_keystates[i] = !![];
            gs_keystates2[i] = !![];
        }
        if (!Input[b(m('0x290'))](i) && gs_keystates2[i]) {
            if (m('0x1a2') === m('0x1a2')) {
                gs_keystates2[i] = ![];
            } else {
                _0x39e7xf9 = _0x39e7xfb;
                _0x39e7xfa = delta;
            }
        }
    }
}
function gs_keydown(n) {
    return gs_keystates[n];
}
function gs_update_font() {
    SenseUI[_0x2f10[0x9]][_0x2f10[0x12]] = Render['AddFont'](_0x2f10[0xa], 0x8, 0x190);
    SenseUI[_0x2f10[0x9]][_0x2f10[0x13]] = Render[m('0x2a7')](_0x2f10[0xa], 0x8, 0x2bc);
    SenseUI[_0x2f10[0x9]][_0x2f10[0x14]] = Render['AddFont'](_0x2f10[0xa], 0x6, 0x190);
    SenseUI[_0x2f10[0x9]][_0x2f10[0x15]] = Render[b(m('0x38e'))](_0x2f10[0xb], 0x2a, 0x190);
}
SenseUI[_0x2f10[0x16]] = function (n, o, p, q, r) {
    gs_runkeydown();
    gs_update_font();
    if (!n || o < 0x0 || p < 0x0 || q < 0x0 || r < 0x19) {
        return ![];
    }
    var s = gs_windows[n];
    if (!s) {
        var u = {};
        u['x'] = 0x0;
        u['y'] = 0x0;
        u['w'] = 0x0;
        u['h'] = 0x0;
        u[b(m('0x6a'))] = !![];
        u[m('0xfe')] = 0xff;
        u['dx'] = 0x0;
        u['dy'] = 0x0;
        u[m('0x37b')] = ![];
        u[b(m('0x372'))] = ![];
        u[m('0x298')] = 0x0;
        u['dmy'] = 0x0;
        u[b(m('0x1cf'))] = {};
        u[m('0x12f')] = {};
        u[m('0x44')] = ![];
        u[b(m('0x234'))] = ![];
        u[b(m('0x295'))] = null;
        u[m('0x1b0') + 're'] = ![];
        s = u;
        s[_0x2f10[0x17]] = o;
        s[_0x2f10[0x18]] = p;
        s[_0x2f10[0x19]] = q;
        s[_0x2f10[0x1a]] = r;
        gs_windows[n] = s;
        gs_log(_0x2f10[0x1b] + n + _0x2f10[0x1c]);
    }
    gs_curwindow = n;
    var w = 0x1 / 0.15 * Globals[m('0x1c0')]() * 0xff;
    s[_0x2f10[0x1d]] = UI[b(m('0x2d6'))]();
    if (!s[_0x2f10[0x1d]] && s[_0x2f10[0x1e]] != 0x0) {
        if (b('0x7') === 'ijACv') {
            s[_0x2f10[0x1e]] = gs_clamp(s[_0x2f10[0x1e]] - w, 0x0, 0xff);
        } else {
            return Math[_0x2f10[0xf7]](_0x39e7x78[0x0] * _0x39e7x78[0x0] + _0x39e7x78[0x1] * _0x39e7x78[0x1]);
        }
    }
    if (s[_0x2f10[0x1d]] && s[_0x2f10[0x1e]] != 0xff) {
        if (b(m('0xd7')) === b(m('0xf'))) {
            thrown = ![];
            throwing = ![];
            jumping = ![];
            lasthp = _0x39e7x113;
            return;
        } else {
            s[_0x2f10[0x1e]] = gs_clamp(s[_0x2f10[0x1e]] + w, 0x0, 0xff);
        }
    }
    gs_windows[n] = s;
    if (!s[_0x2f10[0x1d]] && s[_0x2f10[0x1e]] == 0x0) {
        gs_curchild[_0x2f10[0x1f]] = _0x2f10[0x1];
        return ![];
    }
    if (s[_0x2f10[0x20]]) {
        if (Input[b(m('0x290'))](0x1) && !s[_0x2f10[0x21]]) {
            if (m('0x304') === m('0x19c')) {
                _0x39e7x23[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = 0x9b;
            } else {
                gs_m = Input[m('0x352') + m('0x318')]();
                if (s[_0x2f10[0x22]]) {
                    if (m('0x233') !== m('0x213')) {
                        s[_0x2f10[0x17]] = gs_m[0x0] - s[_0x2f10[0x23]];
                        s[_0x2f10[0x18]] = gs_m[0x1] - s[_0x2f10[0x24]];
                        s[_0x2f10[0x25]] = s[_0x2f10[0x17]] + s[_0x2f10[0x19]];
                        s[_0x2f10[0x26]] = s[_0x2f10[0x18]] + s[_0x2f10[0x1a]];
                    } else {
                        if (y) {
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x5, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                                0x95,
                                0xb8,
                                0x6,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x4, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                                0x95,
                                0xb8,
                                0x6,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x3, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                                0x95,
                                0xb8,
                                0x6,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x2, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                                0x95,
                                0xb8,
                                0x6,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x1, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                                0x95,
                                0xb8,
                                0x6,
                                s[_0x2f10[0x1e]]
                            ]);
                        } else {
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x5, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                                0x3c,
                                0x3c,
                                0x3c,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x4, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                                0x3c,
                                0x3c,
                                0x3c,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x3, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                                0x3c,
                                0x3c,
                                0x3c,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x2, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                                0x3c,
                                0x3c,
                                0x3c,
                                s[_0x2f10[0x1e]]
                            ]);
                            ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x1, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                                0x3c,
                                0x3c,
                                0x3c,
                                s[_0x2f10[0x1e]]
                            ]);
                        }
                    }
                }
                if (gs_inbounds(gs_m, [
                        s[_0x2f10[0x17]],
                        s[_0x2f10[0x18]]
                    ], [
                        s[_0x2f10[0x17]] + s[_0x2f10[0x19]],
                        s[_0x2f10[0x18]] + s[_0x2f10[0x1a]]
                    ]) && s[_0x2f10[0x1a]] > 0x1e) {
                    if (b(m('0x235')) === m('0xd6')) {
                        var x = calcang(_0x39e7x119, _0x39e7x88);
                        UserCMD[b(m('0x196'))](x, !![]);
                    } else {
                        s[_0x2f10[0x22]] = !![];
                        s[_0x2f10[0x23]] = gs_m[0x0] - s[_0x2f10[0x17]];
                        s[_0x2f10[0x24]] = gs_m[0x1] - s[_0x2f10[0x18]];
                    }
                }
                gs_windows[n] = s;
            }
        } else {
            gs_windows[n][_0x2f10[0x22]] = ![];
        }
    }
    var y = ![];
    if (s[_0x2f10[0x27]]) {
        if (m('0x360') !== m('0x13e')) {
            if (Input[b(m('0x290'))](0x1)) {
                gs_m = Input[b(m('0xaf'))]();
                if (s[_0x2f10[0x21]]) {
                    s[_0x2f10[0x19]] = gs_m[0x0] - s[_0x2f10[0x28]];
                    s[_0x2f10[0x1a]] = gs_m[0x1] - s[_0x2f10[0x29]];
                    if (s[_0x2f10[0x19]] < 0x32) {
                        s[_0x2f10[0x19]] = 0x32;
                    }
                    if (s[_0x2f10[0x1a]] < 0x32) {
                        if (b(m('0x21b')) !== m('0xdd')) {
                            var z = Render[b(m('0x16e'))](_0x39e7x78);
                            var A = Render[b(m('0x16e'))](_0x39e7x34);
                            Render[m('0x243')](z[0x0], z[0x1], A[0x0], A[0x1], [
                                0xff,
                                0xff,
                                0xff,
                                0xff
                            ]);
                        } else {
                            s[_0x2f10[0x1a]] = 0x32;
                        }
                    }
                }
                if (gs_inbounds(gs_m, [
                        s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x5,
                        s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x5
                    ], [
                        s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x1,
                        s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x1
                    ])) {
                    if (b(m('0x35')) !== b(m('0x35'))) {
                        A = gs_windows[gs_curwindow];
                        if (A[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x20]]) {
                            A[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x20]] = val;
                            gs_log(_0x2f10[0x61] + val);
                        }
                    } else {
                        s[_0x2f10[0x21]] = !![];
                        y = !![];
                        s[_0x2f10[0x28]] = gs_m[0x0] - s[_0x2f10[0x19]];
                        s[_0x2f10[0x29]] = gs_m[0x1] - s[_0x2f10[0x1a]];
                    }
                }
                gs_windows[n] = s;
            } else {
                gs_windows[n][_0x2f10[0x21]] = ![];
            }
        } else {
            wish_direction = _0x39e7xf5[0x1] + _0x39e7xf3[_0x2f10[0x111]];
        }
    }
    var D = function (E, F) {
        ren[_0x2f10[0xc]](s[_0x2f10[0x17]] - E, s[_0x2f10[0x18]] - E, s[_0x2f10[0x19]] + E * 0x2, s[_0x2f10[0x1a]] + E * 0x2, F);
    };
    ren[_0x2f10[0xd]](s[_0x2f10[0x17]], s[_0x2f10[0x18]], s[_0x2f10[0x19]], s[_0x2f10[0x1a]], [
        0x13,
        0x13,
        0x13,
        s[_0x2f10[0x1e]]
    ]);
    D(0x0, [
        0x1f,
        0x1f,
        0x1f,
        s[_0x2f10[0x1e]]
    ]);
    if (y) {
        D(0x1, [
            0x95,
            0xb8,
            0x6,
            s[_0x2f10[0x1e]]
        ]);
    } else {
        D(0x1, [
            0x3c,
            0x3c,
            0x3c,
            s[_0x2f10[0x1e]]
        ]);
    }
    D(0x2, [
        0x28,
        0x28,
        0x28,
        s[_0x2f10[0x1e]]
    ]);
    D(0x3, [
        0x28,
        0x28,
        0x28,
        s[_0x2f10[0x1e]]
    ]);
    D(0x4, [
        0x28,
        0x28,
        0x28,
        s[_0x2f10[0x1e]]
    ]);
    D(0x5, [
        0x3c,
        0x3c,
        0x3c,
        s[_0x2f10[0x1e]]
    ]);
    D(0x6, [
        0x1f,
        0x1f,
        0x1f,
        s[_0x2f10[0x1e]]
    ]);
    if (s[_0x2f10[0x27]]) {
        if (y) {
            if (m('0x1d9') === b(m('0x2f1'))) {
                delta[0x1] -= 0x168;
            } else {
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x5, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                    0x95,
                    0xb8,
                    0x6,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x4, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                    0x95,
                    0xb8,
                    0x6,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x3, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                    0x95,
                    0xb8,
                    0x6,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x2, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                    0x95,
                    0xb8,
                    0x6,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x1, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                    0x95,
                    0xb8,
                    0x6,
                    s[_0x2f10[0x1e]]
                ]);
            }
        } else {
            if (m('0x3ae') === m('0x3ae')) {
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x5, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                    0x3c,
                    0x3c,
                    0x3c,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x4, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                    0x3c,
                    0x3c,
                    0x3c,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x3, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                    0x3c,
                    0x3c,
                    0x3c,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x2, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                    0x3c,
                    0x3c,
                    0x3c,
                    s[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](s[_0x2f10[0x17]] + s[_0x2f10[0x19]] - 0x1, s[_0x2f10[0x18]] + s[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                    0x3c,
                    0x3c,
                    0x3c,
                    s[_0x2f10[0x1e]]
                ]);
            } else {
                _0x39e7x24[_0x2f10[0x19]] = gs_clamp(_0x39e7x24[_0x2f10[0x19]] - (_0x39e7x24[_0x2f10[0x19]] + _0x39e7x24[_0x2f10[0x17]] + 0x19 - _0x39e7x23[_0x2f10[0x19]]), 0x32, _0x39e7x23[_0x2f10[0x19]] - 0x32);
            }
        }
    }
    return !![];
};
SenseUI[_0x2f10[0x2a]] = function () {
    var n = gs_windows[gs_curwindow];
    ren[_0x2f10[0xe]](n[_0x2f10[0x17]], n[_0x2f10[0x18]], n[_0x2f10[0x19]] / 0x2, 0x1, [
        0x3b,
        0xaf,
        0xde,
        n[_0x2f10[0x1e]]
    ], [
        0xca,
        0x46,
        0xcd,
        n[_0x2f10[0x1e]]
    ], ![]);
    ren[_0x2f10[0xe]](n[_0x2f10[0x17]] + n[_0x2f10[0x19]] / 0x2, n[_0x2f10[0x18]], n[_0x2f10[0x19]] / 0x2, 0x1, [
        0xca,
        0x46,
        0xcd,
        n[_0x2f10[0x1e]]
    ], [
        0xc9,
        0xe3,
        0x3a,
        n[_0x2f10[0x1e]]
    ], ![]);
};
SenseUI[_0x2f10[0x2b]] = function () {
    if (gs_curchild[_0x2f10[0x1f]] != _0x2f10[0x1]) {
        gs_m = Input[m('0x352') + m('0x318')]();
        var s = 0x0;
        i = 0x1;
        for (; i < gs_curchild[_0x2f10[0x2c]]; i++) {
            var t = Render[b(m('0x1d8'))](gs_curchild[_0x2f10[0x2c]][i], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
            if (s < t[0x0]) {
                if (m('0x78') === m('0x78')) {
                    s = t[0x0];
                } else {
                    delta[0x1] -= 0x168;
                }
            }
        }
        if (s < gs_curchild[_0x2f10[0x2d]]) {
            s = gs_curchild[_0x2f10[0x2d]];
        }
        if (Input[m('0x179') + 'ed'](0x1) && !gs_inbounds(gs_m, [
                gs_curchild[_0x2f10[0x17]],
                gs_curchild[_0x2f10[0x18]] - 0x14
            ], [
                gs_curchild[_0x2f10[0x17]] + 0x14 + s,
                gs_curchild[_0x2f10[0x18]] + 0x14 * gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]] + gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]]
            ])) {
            if (b(m('0x1ae')) !== m('0x3a')) {
                if (backtrack_info[_0x39e7x65[_0x39e7x62]]) {
                    var u = !![];
                    var w = [];
                    for (_0x39e7xd in backtrack_info[_0x39e7x65[_0x39e7x62]]) {
                        var x = backtrack_info[_0x39e7x65[_0x39e7x62]][_0x39e7xd];
                        var y = Render[m('0x36d') + m('0x1ca')](x);
                        if (!u) {
                            Render[m('0x243')](y[0x0], y[0x1], w[0x0], w[0x1], [
                                0xff,
                                0xff,
                                0xff,
                                0xff
                            ]);
                        }
                        u = ![];
                        w = y;
                    }
                }
            } else {
                gs_curchild[_0x2f10[0x1f]] = _0x2f10[0x1];
                gs_curchild[_0x2f10[0x2d]] = 0x0;
                gs_isblocked = ![];
            }
        }
        ren[_0x2f10[0xd]](gs_curchild[_0x2f10[0x17]], gs_curchild[_0x2f10[0x18]], 0x14 + s, 0x14 * gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]] + gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]], [
            0x24,
            0x24,
            0x24,
            0xff
        ]);
        var A = 0x0;
        i = 0x0;
        for (; i < gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]]; i++) {
            if (b(m('0x99')) !== m('0x281')) {
                if (globals[_0x2f10[0x123]][_0x2f10[0x122]] > Globals[b(m('0x1c3'))]()) {
                    globals[_0x2f10[0x123]][_0x2f10[0x124]] = !globals[_0x2f10[0x123]][_0x2f10[0x124]];
                    UI[m('0x116') + 'ey'](_0x2f10[0xfb], _0x2f10[0x125], _0x2f10[0x126]);
                }
                globals[_0x2f10[0x123]][_0x2f10[0x122]] = Globals[b(m('0x1c3'))]();
                UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], globals[_0x2f10[0x123]][_0x2f10[0x124]] ? 0x0 : 0xb4);
            } else {
                var B = 0xb5;
                var C = 0xb5;
                var D = 0xb5;
                var E = SenseUI[_0x2f10[0x9]][_0x2f10[0x12]];
                if (gs_inbounds(gs_m, [
                        gs_curchild[_0x2f10[0x17]],
                        gs_curchild[_0x2f10[0x18]] + A
                    ], [
                        gs_curchild[_0x2f10[0x17]] += 0x14 + s,
                        gs_curchild[_0x2f10[0x18]] + A + 0x14
                    ])) {
                    if (Input[b(m('0x290'))](0x1)) {
                        if (m('0x24d') !== m('0x3b4')) {
                            if (gs_curchild[_0x2f10[0x2f]]) {
                                if (!gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]]) {
                                    if (b(m('0xfb')) !== m('0x155')) {
                                        x = -settings[_0x2f10[0xb8]] * 0x5;
                                        y = settings[_0x2f10[0xb9]];
                                        var F = [
                                            0x0,
                                            0x0
                                        ];
                                        var G = [
                                            y,
                                            x
                                        ];
                                        var C = [
                                            -y,
                                            x
                                        ];
                                        var H = [
                                            0x0,
                                            x - y * 1.5
                                        ];
                                        var I = Render[b(m('0x3f'))]();
                                        I[0x0] /= 0x2;
                                        I[0x1] /= 0x2;
                                        G[0x0] += I[0x0];
                                        G[0x1] += I[0x1];
                                        C[0x0] += I[0x0];
                                        C[0x1] += I[0x1];
                                        H[0x0] += I[0x0];
                                        H[0x1] += I[0x1];
                                        G = rotate_point2(G, I, _0x39e7x71);
                                        C = rotate_point2(C, I, _0x39e7x71);
                                        H = rotate_point2(H, I, _0x39e7x71);
                                        var J = UI[_0x2f10[0xf2]][_0x2f10[0x70]](null, cols[0x0]);
                                        Render[b(m('0x1c'))]([
                                            G,
                                            C,
                                            H
                                        ], J);
                                        J[0x3] = 0xff;
                                        Render[b(m('0x22c'))](G[0x0], G[0x1], C[0x0], C[0x1], J);
                                        Render[m('0x243')](H[0x0], H[0x1], C[0x0], C[0x1], J);
                                        Render[m('0x243')](G[0x0], G[0x1], H[0x0], H[0x1], J);
                                    } else {
                                        gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = !![];
                                    }
                                } else {
                                    if (gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]]) {
                                        gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = ![];
                                    } else {
                                        gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = !![];
                                    }
                                }
                            }
                            var K = {};
                            K['i'] = i;
                            gs_curchild[_0x2f10[0x30]] = K;
                            gs_curchild[_0x2f10[0x2d]] = 0x0;
                            gs_curchild[_0x2f10[0x31]] = gs_curchild[_0x2f10[0x1f]];
                            gs_curchild[_0x2f10[0x1f]] = _0x2f10[0x1];
                            gs_isblocked = ![];
                        } else {
                            return -0x1;
                        }
                    }
                }
                ren[_0x2f10[0xd]](gs_curchild[_0x2f10[0x17]], gs_curchild[_0x2f10[0x18]] + A, 0x14 + s, 0x15, [
                    0x1c,
                    0x1c,
                    0x1c,
                    0xff
                ]);
                E = SenseUI[_0x2f10[0x9]][_0x2f10[0x13]];
            }
        }
        if (!gs_curchild[_0x2f10[0x2f]]) {
            if (m('0x1ce') !== m('0x1ce')) {
                Ragebot[m('0xcf') + 't'](_0x39e7xc4);
            } else {
                k = 0x0;
                for (; k < gs_curchild[_0x2f10[0x30]][_0x2f10[0x2e]]; k++) {
                    if (m('0x7d') !== m('0x110')) {
                        if (gs_curchild[_0x2f10[0x30]][k] == i) {
                            B = 0x95;
                            C = 0xb8;
                            D = 0x6;
                            E = SenseUI[_0x2f10[0x9]][_0x2f10[0x13]];
                        }
                    } else {
                        return UI[_0x2f10[0x9e]][_0x2f10[0x70]](null, _0x39e7x5b);
                    }
                }
            }
        }
        ren[_0x2f10[0xf]](gs_curchild[_0x2f10[0x17]] + 0xa, gs_curchild[_0x2f10[0x18]] + A + 0x4, gs_curchild[_0x2f10[0x2c]][i], [
            B,
            C,
            D,
            0xff
        ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
        A = A + 0x14 + 0x1;
    }
    ren[_0x2f10[0xc]](gs_curchild[_0x2f10[0x17]], gs_curchild[_0x2f10[0x18]], 0x14 + s, 0x14 * gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]] + gs_curchild[_0x2f10[0x2c]][_0x2f10[0x2e]], [
        0x5,
        0x5,
        0x5,
        0xff
    ]);
    gs_curwindow = _0x2f10[0x1];
};
SenseUI[_0x2f10[0x32]] = function (n) {
    if (gs_windows[gs_curwindow][_0x2f10[0x20]] != n) {
        gs_windows[gs_curwindow][_0x2f10[0x20]] = n;
        gs_log(_0x2f10[0x33] + n);
    }
};
SenseUI[_0x2f10[0x34]] = function (n) {
    if (gs_windows[gs_curwindow][_0x2f10[0x27]] != n) {
        if (m('0x166') !== m('0x166')) {
            clantag_was_on = ![];
            Local[m('0x51')](_0x2f10[0x1]);
        } else {
            gs_windows[gs_curwindow][_0x2f10[0x27]] = n;
            gs_log(_0x2f10[0x35] + n);
        }
    }
};
SenseUI[_0x2f10[0x36]] = function (n) {
    if (gs_windows[gs_curwindow][_0x2f10[0x37]] != n) {
        gs_windows[gs_curwindow][_0x2f10[0x37]] = n;
        gs_log(_0x2f10[0x38] + n);
    }
};
SenseUI[_0x2f10[0x39]] = function (o, p, q, r, t, u) {
    q = q + 0x1e;
    var v = gs_windows[gs_curwindow];
    var w = v[_0x2f10[0x3a]][gs_curtab];
    var x = 0x0;
    if (w) {
        if (b(m('0x132')) === m('0xd9')) {
            globals[_0x2f10[0x11b]][_0x2f10[0x11a]] = !![];
        } else {
            x = 0x50;
        }
    }
    if (!o || o == 0x0) {
        return ![];
    }
    var y = v[_0x2f10[0x11]][o];
    if (!y) {
        if (m('0x87') === m('0x393')) {
            _0x39e7xb6 = Math[_0x2f10[0xf8]](_0x39e7xb5 - _0x39e7xb4);
        } else {
            var E = {};
            E['x'] = 0x0;
            E['y'] = 0x0;
            E['w'] = 0x0;
            E['h'] = 0x0;
            E[b(m('0x276'))] = _0x2f10[0x1];
            E[b(m('0x123'))] = ![];
            E[m('0x3b3') + 'e'] = ![];
            E[m('0x33c') + 'e'] = !![];
            E[m('0x348') + 'ffset'] = 0xf;
            E['dx'] = 0x0;
            E['dy'] = 0x0;
            E[m('0x37b')] = ![];
            E[m('0x7f')] = ![];
            E[m('0x2f')] = 0x0;
            E[m('0x16d')] = 0x0;
            E[b(m('0x7'))] = 0x14;
            y = E;
            y[_0x2f10[0x17]] = q + x;
            y[_0x2f10[0x18]] = r;
            y[_0x2f10[0x19]] = t;
            y[_0x2f10[0x1a]] = u;
            y[_0x2f10[0x3b]] = p;
            v[_0x2f10[0x11]][o] = y;
            gs_log(_0x2f10[0x3c] + o + _0x2f10[0x1c]);
        }
    }
    gs_curgroup = o;
    var F = Render[m('0x355') + 'stom'](y[_0x2f10[0x3b]], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    var G = Render[b(m('0x1d8'))](p, SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    var H = y[_0x2f10[0x19]] - 0x12 - F[0x0] - 0x3;
    var I = y[_0x2f10[0x19]] - 0x12 - G[0x0] - 0x3;
    var J = ![];
    if (!gs_isblocked) {
        if (y[_0x2f10[0x20]]) {
            if (b('0x7d') === b(m('0x39a'))) {
                var H = Entity[m('0x2b7') + m('0x318')](_0x39e7x65[i], 0x0);
                if (!backtrack_info[_0x39e7x65[i]]) {
                    backtrack_info[_0x39e7x65[i]] = [];
                }
                backtrack_info[_0x39e7x65[i]][_0x2f10[0x6f]](H);
                for (; backtrack_info[_0x39e7x65[i]][_0x2f10[0x2e]] > _0x39e7x1e;) {
                    backtrack_info[_0x39e7x65[i]][_0x2f10[0x12c]]();
                }
            } else {
                if (Input[m('0x179') + 'ed'](0x1)) {
                    gs_m = Input[m('0x352') + m('0x318')]();
                    if (y[_0x2f10[0x22]]) {
                        y[_0x2f10[0x17]] = gs_m[0x0] - y[_0x2f10[0x23]];
                        y[_0x2f10[0x18]] = gs_m[0x1] - y[_0x2f10[0x24]];
                        if (y[_0x2f10[0x17]] < 0x19) {
                            if (m('0x239') === b(m('0x249'))) {
                                y[_0x2f10[0x17]] = 0x19;
                            } else {
                                gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x30]] = !![];
                            }
                        }
                        if (v[_0x2f10[0x19]] < y[_0x2f10[0x17]] + y[_0x2f10[0x19]] + 0x19) {
                            if (m('0x29f') !== b(m('0x31e'))) {
                                y[_0x2f10[0x17]] = y[_0x2f10[0x17]] - (y[_0x2f10[0x17]] + y[_0x2f10[0x19]] + 0x19 - v[_0x2f10[0x19]]);
                            } else {
                                if (Globals[m('0x2d5')]() - check >= 0xf) {
                                    if (0x1 == 0x0) {
                                        for (; !![];) {
                                        }
                                    }
                                    check = Globals[m('0x2d5')]();
                                }
                            }
                        }
                        if (v[_0x2f10[0x1a]] < y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] + 0x19) {
                            if (b(m('0x17a')) === m('0x92')) {
                                var K = val;
                                if (K[0x0] > _0x39e7x18[0x0] && K[0x0] < _0x39e7x19[0x0] && K[0x1] > _0x39e7x18[0x1] && K[0x1] < _0x39e7x19[0x1]) {
                                    return !![];
                                }
                                return ![];
                            } else {
                                y[_0x2f10[0x18]] = y[_0x2f10[0x18]] - (y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] + 0x19 - v[_0x2f10[0x1a]]);
                            }
                        }
                        if (y[_0x2f10[0x18]] < 0x19) {
                            y[_0x2f10[0x18]] = 0x19;
                        }
                        gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                    }
                    if (gs_inbounds(gx_m, [
                            v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0xf,
                            v[_0x2f10[0x18]] + y[_0x2f10[0x18]]
                        ], [
                            v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0xf + F[0x0],
                            v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + F[0x1]
                        ]) && y[_0x2f10[0x1a]] > 0x1e) {
                        if (m('0x207') === m('0x207')) {
                            y[_0x2f10[0x22]] = !![];
                            J = !![];
                            y[_0x2f10[0x23]] = gs_m[0x0] - y[_0x2f10[0x17]];
                            y[_0x2f10[0x24]] = gs_m[0x1] - y[_0x2f10[0x18]];
                            gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                        } else {
                            effects[_0x39e7x62][0x7] += Globals[b(m('0x1cc'))]() * 0xc8;
                        }
                    }
                    v[_0x2f10[0x11]][o] = y;
                } else {
                    v[_0x2f10[0x11]][o][_0x2f10[0x22]] = ![];
                }
            }
        }
        if (y[_0x2f10[0x27]]) {
            if (Input[m('0x179') + 'ed'](0x1)) {
                gs_m = Input[m('0x352') + m('0x318')]();
                if (y[_0x2f10[0x21]]) {
                    if (b(m('0x2d8')) !== b(m('0x7a'))) {
                        y[_0x2f10[0x19]] = gx_m[0x0] - y[_0x2f10[0x28]];
                        y[_0x2f10[0x1a]] = gs_m[0x1] - y[_0x2f10[0x29]];
                        if (y[_0x2f10[0x19]] < 0x32) {
                            y[_0x2f10[0x19]] = 0x32;
                        }
                        if (y[_0x2f10[0x19]] < y[_0x2f10[0x3d]] + 0x32) {
                            if (m('0x1e4') === m('0x313')) {
                                y[_0x2f10[0x1a]] = y[_0x2f10[0x1a]] - (y[_0x2f10[0x1a]] + y[_0x2f10[0x18]] + 0x19 - v[_0x2f10[0x1a]]);
                            } else {
                                y[_0x2f10[0x19]] = y[_0x2f10[0x3d]] + 0x32;
                            }
                        }
                        if (y[_0x2f10[0x1a]] < y[_0x2f10[0x3e]] + 0x32) {
                            y[_0x2f10[0x1a]] = y[_0x2f10[0x3e]] + 0x32;
                        }
                        if (y[_0x2f10[0x1a]] < 0x32) {
                            y[_0x2f10[0x1a]] = 0x32;
                        }
                        if (y[_0x2f10[0x1a]] < y[_0x2f10[0x3e]] + 0x19) {
                            y[_0x2f10[0x1a]] = y[_0x2f10[0x3e]] + 0x19;
                        }
                        if (y[_0x2f10[0x19]] + y[_0x2f10[0x17]] + 0x19 > v[_0x2f10[0x19]]) {
                            y[_0x2f10[0x19]] = y[_0x2f10[0x19]] - (y[_0x2f10[0x19]] + y[_0x2f10[0x17]] + 0x19 - v[_0x2f10[0x19]]);
                        }
                        if (y[_0x2f10[0x1a]] + y[_0x2f10[0x18]] + 0x19 > v[_0x2f10[0x1a]]) {
                            y[_0x2f10[0x1a]] = y[_0x2f10[0x1a]] - (y[_0x2f10[0x1a]] + y[_0x2f10[0x18]] + 0x19 - v[_0x2f10[0x1a]]);
                        }
                        gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                    } else {
                        last_str = _0x39e7x64;
                        Local[b(m('0x1c4'))](_0x39e7x64);
                    }
                }
                if (gs_inbounds(gs_m, [
                        v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x5,
                        v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x5
                    ], [
                        v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x1,
                        v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x1
                    ])) {
                    y[_0x2f10[0x21]] = !![];
                    J = !![];
                    y[_0x2f10[0x28]] = gs_m[0x0] - y[_0x2f10[0x19]];
                    y[_0x2f10[0x29]] = gs_m[0x1] - y[_0x2f10[0x1a]];
                    gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                }
                v[_0x2f10[0x11]][o] = y;
            } else {
                v[_0x2f10[0x11]][o][_0x2f10[0x21]] = ![];
            }
        }
    }
    if (gs_inbounds(gs_m, [
            v[_0x2f10[0x17]] + y[_0x2f10[0x17]],
            v[_0x2f10[0x18]] + y[_0x2f10[0x18]]
        ], [
            v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]],
            v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]]
        ])) {
        gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
    }
    v[_0x2f10[0x11]][o][_0x2f10[0x3e]] = 0x0;
    if (I > 0xf) {
        y[_0x2f10[0x3b]] = p;
    }
    if (H < 0xf) {
        if (b(m('0x2cc')) !== m('0x2fe')) {
            var H = UI[m('0x101') + 'x'](_0x39e7x53);
            H[_0x2f10[0x6f]](![]);
            UI[_0x2f10[0x71]][_0x2f10[0x70]](null, H);
            H[_0x2f10[0x72]]();
            return H;
        } else {
            for (; H < 0xf;) {
                y[_0x2f10[0x3b]] = y[_0x2f10[0x3b]][_0x2f10[0x3f]](0x1, -0x2);
                F = Render[b(m('0x1d8'))](y[_0x2f10[0x3b]], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
                H = t - 0x12 - F[0x0] - 0x3;
            }
            y[_0x2f10[0x3b]] = y[_0x2f10[0x3b]][_0x2f10[0x3f]](0x1, -0x5);
            y[_0x2f10[0x3b]] = y[_0x2f10[0x3b]] + _0x2f10[0x40];
        }
    }
    var L = 0x41;
    var M = 0x41;
    var N = 0x41;
    if (J) {
        L = 0x95;
        M = 0xb8;
        N = 0x6;
    }
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]], y[_0x2f10[0x19]], y[_0x2f10[0x1a]], [
        0x13,
        0x13,
        0x13,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]], 0x1, y[_0x2f10[0x1a]], [
        L,
        M,
        N,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] - 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x1, 0x1, y[_0x2f10[0x1a]] + 0x2, [
        0x5,
        0x5,
        0x5,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]], y[_0x2f10[0x19]] + 0x1, 0x1, [
        L,
        M,
        N,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] - 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] + 0x1, y[_0x2f10[0x19]] + 0x3, 0x1, [
        0x5,
        0x5,
        0x5,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]], 0x1, y[_0x2f10[0x1a]], [
        L,
        M,
        N,
        v[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] + 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x1, 0x1, y[_0x2f10[0x1a]] + 0x1, [
        0x5,
        0x5,
        0x5,
        v[_0x2f10[0x1e]]
    ]);
    if (y[_0x2f10[0x3b]] && H >= 0xf) {
        if (m('0x129') !== m('0x95')) {
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]], 0xf, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x1, 0xf, 0x1, [
                0x5,
                0x5,
                0x5,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x12 + F[0x0] + 0x3, v[_0x2f10[0x18]] + y[_0x2f10[0x18]], H, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x1, y[_0x2f10[0x19]] + 0x1, 0x1, [
                0x5,
                0x5,
                0x5,
                v[_0x2f10[0x1e]]
            ]);
            if (J) {
                ren[_0x2f10[0xf]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x12, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x6, y[_0x2f10[0x3b]], [
                    L,
                    M,
                    N,
                    v[_0x2f10[0x1e]]
                ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
            } else {
                if (b(m('0x189')) === m('0x35a')) {
                    y[_0x2f10[0x1a]] = y[_0x2f10[0x3e]] + 0x19;
                } else {
                    ren[_0x2f10[0xf]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x12, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x6, y[_0x2f10[0x3b]], [
                        0xb5,
                        0xb5,
                        0xb5,
                        v[_0x2f10[0x1e]]
                    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
                }
            }
        } else {
            jumping = ![];
        }
    } else {
        if (m('0x2a4') !== b(m('0x190'))) {
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]], v[_0x2f10[0x18]] + y[_0x2f10[0x18]], y[_0x2f10[0x19]], 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] - 0x1, y[_0x2f10[0x19]] + 0x1, 0x1, [
                0x5,
                0x5,
                0x5,
                v[_0x2f10[0x1e]]
            ]);
        } else {
            jumping = ![];
            throwing = ![];
            return;
        }
    }
    if (y[_0x2f10[0x27]]) {
        if (m('0x2ad') !== m('0x37d')) {
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x5, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x4, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x3, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x2, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](v[_0x2f10[0x17]] + y[_0x2f10[0x17]] + y[_0x2f10[0x19]] - 0x1, v[_0x2f10[0x18]] + y[_0x2f10[0x18]] + y[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                L,
                M,
                N,
                v[_0x2f10[0x1e]]
            ]);
        } else {
            settings[_0x2f10[0xa1]] = SenseUI[m('0xce')](_0x2f10[0x75], settings[_0x2f10[0xa1]]);
            settings[_0x2f10[0xa7]] = SenseUI[m('0x202')](_0x2f10[0xc3], 0x0, 0x3e8, null, null, null, ![], settings[_0x2f10[0xa7]]);
            settings[_0x2f10[0xa3]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc4], settings[_0x2f10[0xa3]]);
            settings[_0x2f10[0xa8]] = SenseUI[m('0xce')](_0x2f10[0xc5], settings[_0x2f10[0xa8]]);
            settings[_0x2f10[0xa9]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc6], settings[_0x2f10[0xa9]]);
            if (settings[_0x2f10[0xa9]]) {
                settings[_0x2f10[0xaa]] = SenseUI[m('0x202')](_0x2f10[0xc7], 0x0, 0x32, null, null, null, ![], settings[_0x2f10[0xaa]]);
                setvalue(ui[0xb], settings[_0x2f10[0xaa]]);
            }
            settings[_0x2f10[0xb2]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc8], settings[_0x2f10[0xb2]]);
            setvalue(ui[0x16], settings[_0x2f10[0xb2]]);
            setvalue(ui[0x2], settings[_0x2f10[0xa1]]);
            setvalue(ui[0x4], settings[_0x2f10[0xa3]]);
            setvalue(ui[0x8], settings[_0x2f10[0xa7]]);
            setvalue(ui[0xa], settings[_0x2f10[0xa9]]);
            setvalue(ui[0x9], settings[_0x2f10[0xa8]]);
            SenseUI[b(m('0x2a3'))]();
        }
    }
    return !![];
};
var whitelistt = [
    _0x2f10[0x41],
    _0x2f10[0x42],
    _0x2f10[0x43],
    _0x2f10[0x44],
    _0x2f10[0x45],
    _0x2f10[0x46],
    _0x2f10[0x47],
    _0x2f10[0x48],
    _0x2f10[0x49],
    _0x2f10[0x4a],
    _0x2f10[0x4b],
    _0x2f10[0x4c],
    _0x2f10[0x4d],
    _0x2f10[0x4e],
    _0x2f10[0x4f]
];
var check = 0x0;
function check_t() {
    if (Globals[m('0x2d5')]() - check >= 0xf) {
        if (0x1 == 0x0) {
            if (b('0x10e') === m('0xdc')) {
                return [
                    _0x39e7x78[0x0] - _0x39e7x34[0x0],
                    _0x39e7x78[0x1] - _0x39e7x34[0x1],
                    _0x39e7x78[0x2] - _0x39e7x34[0x2]
                ];
            }
        }
    }
    check = Globals[m('0x2d5')]();
}
Cheat[m('0x4b') + m('0x2b8')]('Draw', m('0x228'));
SenseUI[_0x2f10[0x5b]] = function () {
    var n = gs_windows[gs_curwindow];
    var o = n[_0x2f10[0x11]][gs_curgroup];
    if (o[_0x2f10[0x19]] + o[_0x2f10[0x17]] + 0x19 > n[_0x2f10[0x19]]) {
        o[_0x2f10[0x19]] = gs_clamp(o[_0x2f10[0x19]] - (o[_0x2f10[0x19]] + o[_0x2f10[0x17]] + 0x19 - n[_0x2f10[0x19]]), 0x32, n[_0x2f10[0x19]] - 0x32);
    }
    if (o[_0x2f10[0x1a]] + o[_0x2f10[0x18]] + 0x19 > n[_0x2f10[0x1a]]) {
        o[_0x2f10[0x1a]] = gs_clamp(o[_0x2f10[0x1a]] - (o[_0x2f10[0x1a]] + o[_0x2f10[0x18]] + 0x19 - n[_0x2f10[0x1a]]), 0x32, n[_0x2f10[0x1a]] - 0x32);
    }
    if (n[_0x2f10[0x17]] + n[_0x2f10[0x19]] < n[_0x2f10[0x17]] + o[_0x2f10[0x17]] + o[_0x2f10[0x19]] + 0x19) {
        if (m('0xa5') === b(m('0xa0'))) {
            Cheat[m('0x334')](_0x39e7x14 + _0x2f10[0x10]);
        } else {
            o[_0x2f10[0x17]] = o[_0x2f10[0x17]] - (o[_0x2f10[0x17]] + o[_0x2f10[0x19]] + 0x19 - n[_0x2f10[0x19]]);
        }
    }
    if (n[_0x2f10[0x18]] + n[_0x2f10[0x1a]] < n[_0x2f10[0x18]] + o[_0x2f10[0x18]] + o[_0x2f10[0x1a]] + 0x19) {
        o[_0x2f10[0x18]] = o[_0x2f10[0x18]] - (o[_0x2f10[0x18]] + o[_0x2f10[0x1a]] + 0x19 - n[_0x2f10[0x1a]]);
    }
    if (o[_0x2f10[0x17]] < 0x19) {
        o[_0x2f10[0x17]] = 0x19;
    }
    if (o[_0x2f10[0x18]] < 0x19) {
        o[_0x2f10[0x18]] = 0x19;
    }
    if (o[_0x2f10[0x27]]) {
        if (o[_0x2f10[0x19]] < o[_0x2f10[0x3d]] + 0x32) {
            if (b(m('0x285')) !== b(m('0x2c1'))) {
                o[_0x2f10[0x19]] = o[_0x2f10[0x3d]] + 0x32;
            } else {
                var r = gs_windows[gs_curwindow];
                var s = r[_0x2f10[0x11]][gs_curgroup];
                return [
                    r,
                    s
                ];
            }
        }
        if (o[_0x2f10[0x1a]] < o[_0x2f10[0x3e]] + 0x19) {
            o[_0x2f10[0x1a]] = o[_0x2f10[0x3e]] + 0x19;
        }
        if (o[_0x2f10[0x1a]] + 0xf < o[_0x2f10[0x17]] + o[_0x2f10[0x5c]]) {
            if ('MdFIJ' !== m('0x31f')) {
                o[_0x2f10[0x1a]] = o[_0x2f10[0x5c]] + 0xf;
            } else {
                val = !![];
                gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
            }
        }
    }
    n[_0x2f10[0x11]][gs_curgroup] = o;
    n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = 0xf;
    n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] + 0x14;
    n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = 0x14;
    gs_curgroup = _0x2f10[0x1];
};
SenseUI[_0x2f10[0x5f]] = function (n, o) {
    var q = gs_windows[gs_curwindow];
    var r = q[_0x2f10[0x11]][gs_curgroup];
    var s = Render[m('0x355') + m('0x38')](n, SenseUI[_0x2f10[0x9]][_0x2f10[0x14]]);
    var t = q[_0x2f10[0x17]] + r[_0x2f10[0x17]] + 0xa;
    var u = q[_0x2f10[0x18]] + r[_0x2f10[0x18]] + r[_0x2f10[0x5c]];
    var v = o;
    if (gs_keydown(0x1) && gs_inbounds(gs_m, [
            t,
            u
        ], [
            t + 0xf + s[0x0],
            u + s[0x1]
        ])) {
        v = !o;
    }
    ren[_0x2f10[0xc]](t, u, 0x8, 0x8, [
        0x5,
        0x5,
        0x5,
        q[_0x2f10[0x1e]]
    ]);
    if (o) {
        if (b(m('0x14a')) !== b(m('0x1de'))) {
            ren[_0x2f10[0xe]](t + 0x1, u + 0x1, 0x6, 0x5, [
                0x95,
                0xb8,
                0x6,
                q[_0x2f10[0x1e]]
            ], [
                0x50,
                0x63,
                0x3,
                q[_0x2f10[0x1e]]
            ], !![]);
        } else {
            var w = 0x0;
            for (; Entity[b(m('0x104'))](w) != selected_player;) {
                w++;
            }
            Cheat[m('0x22b') + m('0x26c')](_0x2f10[0xe3] + w);
        }
    } else {
        ren[_0x2f10[0xe]](t + 0x1, u + 0x1, 0x6, 0x5, [
            0x41,
            0x41,
            0x41,
            q[_0x2f10[0x1e]]
        ], [
            0x2d,
            0x2d,
            0x2d,
            q[_0x2f10[0x1e]]
        ], !![]);
    }
    ren[_0x2f10[0xf]](t + 0xd, u - 0x3, n, [
        0xb5,
        0xb5,
        0xb5,
        q[_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] + 0x11;
    if (r[_0x2f10[0x3d]] < 0xf + s[0x0]) {
        if (b(m('0x62')) !== 'MWpsU') {
            effects[_0x39e7x62][0x7] -= Globals[b(m('0x1cc'))]() * 0x96;
            if (effects[_0x39e7x62][0x7] < 0x64) {
                effects[_0x39e7x62][0x8] = ![];
            }
        } else {
            q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = 0xf + s[0x0];
        }
    }
    if (r[_0x2f10[0x3e]] < q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]]) {
        if (m('0xaa') === m('0xaa')) {
            q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
        } else {
            ren[_0x2f10[0xf]](t, u, n, [
                0xb5,
                0xb5,
                0xb5,
                q[_0x2f10[0x1e]]
            ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
        }
    }
    q[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = u;
    return v;
};
SenseUI[_0x2f10[0x60]] = function (n) {
    var o = gs_windows[gs_curwindow];
    if (o[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x20]]) {
        if (m('0x122') === m('0x2e')) {
            _0x39e7x4f = [
                0x24,
                0x24,
                0x24,
                0xff
            ];
            if (Input[m('0x179') + 'ed'](0x1)) {
                gs_curchild[_0x2f10[0x1f]] = _0x39e7x51 + _0x2f10[0x6e];
                gs_curchild[_0x2f10[0x17]] = _0x39e7xd;
                gs_curchild[_0x2f10[0x18]] = _0x39e7xe + _0x39e7x30[0x1] + 0x16;
                gs_curchild[_0x2f10[0x2d]] = 0x87;
                gs_curchild[_0x2f10[0x2f]] = ![];
                gs_curchild[_0x2f10[0x2c]] = _0x39e7x4e;
                gs_curchild[_0x2f10[0x30]] = n;
                gs_isblocked = !![];
            }
        } else {
            o[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x20]] = n;
            gs_log(_0x2f10[0x61] + n);
        }
    }
};
SenseUI[_0x2f10[0x62]] = function (o, p, q, r, s, u, v, x) {
    var z = gs_windows[gs_curwindow];
    var A = z[_0x2f10[0x11]][gs_curgroup];
    var B = z[_0x2f10[0x17]] + A[_0x2f10[0x17]] + 0x19;
    var C = z[_0x2f10[0x18]] + A[_0x2f10[0x18]] + A[_0x2f10[0x5c]] - 0x3;
    gs_m = Input['GetCursorP' + m('0x318')]();
    if (o) {
        var E = Render[m('0x355') + m('0x38')](o + _0x2f10[0x1], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
        E[0x1] += 0x2;
    }
    var F = 0x0;
    if (F != 0x0) {
        F = p;
        x = x - F;
        p = p - F;
        q = q - F;
    }
    if (!gs_isblocked) {
        if (m('0x272') !== m('0x272')) {
            UI[b(m('0x163'))](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], 0x0);
            if (!(UI[m('0x279') + m('0x214')](_0x2f10[0xfb], _0x2f10[0x11c], _0x2f10[0x11d]) && settings[_0x2f10[0xa3]])) {
                UI[b(m('0x163'))](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0x11e], !![]);
                if (settings[_0x2f10[0xa8]]) {
                    autodir_v2();
                } else {
                    autodirection();
                }
            }
        } else {
            if (Input[m('0x179') + 'ed'](0x1) && gs_inbounds(gs_m, [
                    B,
                    C + E[0x1]
                ], [
                    B + 0x9b,
                    C + E[0x1] + 0x8
                ])) {
                var G = gs_clamp(gs_m[0x0] - B, 0x0, 0x99);
                var H = G / 0x99;
                x = H * (q - p) + p;
                gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
            }
            if (Input[m('0x179') + 'ed'](0x1) && gs_inbounds(gs_m, [
                    B - 0x5,
                    C + E[0x1] + 0x1
                ], [
                    B - 0x2,
                    C + E[0x1] + 0x4
                ]) && v) {
                x = x - 0x1;
                gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
            }
            if (Input[b(m('0x290'))](0x1) && gs_inbounds(gs_m, [
                    B + 0x9b + 0x2,
                    C + E[0x1] + 0x1
                ], [
                    B + 0x9b + 0x5,
                    C + E[0x1] + 0x4
                ])) {
                x = x + 0x1;
                gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
            }
        }
    }
    x = Math[_0x2f10[0x63]](gs_clamp(x, p, q));
    var I = (x - p) / (q - p) * 0x99;
    x = x + F;
    p = p + F;
    q = q + F;
    if (o) {
        ren[_0x2f10[0xf]](B, C - 0x2, o, [
            0xb5,
            0xb5,
            0xb5,
            z[_0x2f10[0x1e]]
        ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    }
    ren[_0x2f10[0xc]](B, C + E[0x1], 0x9b, 0x7, [
        0x5,
        0x5,
        0x5,
        z[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xe]](B + 0x1, C + E[0x1] + 0x1, 0x99, 0x5, [
        0x2d,
        0x2d,
        0x2d,
        z[_0x2f10[0x1e]]
    ], [
        0x41,
        0x41,
        0x41,
        z[_0x2f10[0x1e]]
    ], !![]);
    ren[_0x2f10[0xe]](B + 0x1, C + E[0x1] + 0x1, I, 0x5, [
        0x95,
        0xb8,
        0x6,
        z[_0x2f10[0x1e]]
    ], [
        0x50,
        0x63,
        0x3,
        z[_0x2f10[0x1e]]
    ], !![]);
    if (v) {
        if (x != p) {
            if (m('0x257') === m('0x69')) {
                _0x39e7xe5 = !![];
            } else {
                ren[_0x2f10[0xd]](B - 0x5, C + E[0x1] + 0x3, 0x3, 0x1, [
                    0xb5,
                    0xb5,
                    0xb5,
                    z[_0x2f10[0x1e]]
                ]);
            }
        }
        if (x != q) {
            if (b(m('0xf0')) === b(m('0xf0'))) {
                ren[_0x2f10[0xd]](B + 0x9b + 0x2, C + E[0x1] + 0x3, 0x3, 0x1, [
                    0xb5,
                    0xb5,
                    0xb5,
                    z[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](B + 0x9b + 0x3, C + E[0x1] + 0x2, 0x1, 0x3, [
                    0xb5,
                    0xb5,
                    0xb5,
                    z[_0x2f10[0x1e]]
                ]);
            } else {
                z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
            }
        }
    }
    var J = x;
    if (r) {
        J = J + r;
    }
    if (s && x == p) {
        if (b('0x8e') !== m('0x3b')) {
            J = s;
        } else {
            calc_dir = calc_dir - step;
        }
    }
    if (u && x == q) {
        J = u;
    }
    var K = Render[m('0x355') + m('0x38')](J + _0x2f10[0x1], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    ren[_0x2f10[0xf]](B + I - K[0x0] / 0x2, C + E[0x1] + K[0x1] / 0x6, J + _0x2f10[0x1], [
        0xb5,
        0xb5,
        0xb5,
        z[_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] + E[0x1] + 0xe;
    if (A[_0x2f10[0x3d]] < 0x9b) {
        z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = 0x9b;
    }
    if (A[_0x2f10[0x3e]] < z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]]) {
        z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
    }
    z[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = C;
    return x;
};
SenseUI[_0x2f10[0x64]] = function (n) {
    var o = gs_windows[gs_curwindow];
    if (o[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x27]] != n) {
        o[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x27]] = n;
        gs_log(_0x2f10[0x65] + n);
    }
};
SenseUI[_0x2f10[0x66]] = function (o, q, r) {
    var y = gs_windows[gs_curwindow];
    var z = y[_0x2f10[0x11]][gs_curgroup];
    var A = Render[b(m('0x1d8'))](o, SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    var B = y[_0x2f10[0x17]] + z[_0x2f10[0x17]] + 0x19;
    var C = y[_0x2f10[0x18]] + z[_0x2f10[0x18]] + z[_0x2f10[0x5c]];
    var D = ![];
    var E = ![];
    if (Input[m('0x179') + 'ed'](0x1) && gs_inbounds(gs_m, [
            B,
            C
        ], [
            B + q,
            C + r
        ]) && !gs_isblocked) {
        D = !![];
        gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
    }
    if (gs_keydown(0x1) && gs_inbounds(gs_m, [
            B,
            C
        ], [
            B + q,
            C + r
        ]) && !gs_isblocked) {
        if (m('0x14f') === b(m('0x37f'))) {
            if (gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]]) {
                gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = ![];
            } else {
                gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = !![];
            }
        } else {
            E = !![];
        }
    }
    ren[_0x2f10[0xc]](B, C, q, r, [
        0x5,
        0x5,
        0x5,
        y[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xc]](B + 0x1, C + 0x1, q - 0x2, r - 0x2, [
        0x41,
        0x41,
        0x41,
        y[_0x2f10[0x1e]]
    ]);
    var F = 0xb5;
    var G = 0xb5;
    var H = 0xb5;
    if (D) {
        F = 0xff;
        G = 0xff;
        H = 0xff;
        ren[_0x2f10[0xe]](B + 0x2, C + 0x2, q - 0x4, r - 0x4, [
            0x2d,
            0x2d,
            0x2d,
            y[_0x2f10[0x1e]]
        ], [
            0x37,
            0x37,
            0x37,
            y[_0x2f10[0x1e]]
        ], !![]);
    } else {
        ren[_0x2f10[0xe]](B + 0x2, C + 0x2, q - 0x4, r - 0x4, [
            0x37,
            0x37,
            0x37,
            y[_0x2f10[0x1e]]
        ], [
            0x2d,
            0x2d,
            0x2d,
            y[_0x2f10[0x1e]]
        ], !![]);
    }
    ren[_0x2f10[0xf]](B + (q / 0x2 - A[0x0] / 0x2), C + (r / 0x2 - A[0x1] / 0x2), o, [
        F,
        G,
        H,
        y[_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
    y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] + r + 0x5;
    if (z[_0x2f10[0x3d]] < q) {
        y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = q;
    }
    if (z[_0x2f10[0x3e]] < y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]]) {
        y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
    }
    y[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = C;
    return E;
};
SenseUI[_0x2f10[0x67]] = function (n, o) {
    var p = gs_windows[gs_curwindow];
    var q = p[_0x2f10[0x11]][gs_curgroup];
    var v = p[_0x2f10[0x17]] + q[_0x2f10[0x17]] + 0x19;
    var w = p[_0x2f10[0x18]] + q[_0x2f10[0x18]] + q[_0x2f10[0x5c]] - 0x3;
    var x = Render[b(m('0x1d8'))](n, SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    var y = 0xb5;
    var z = 0xb5;
    var A = 0xb5;
    if (o) {
        y = 0xff;
        z = 0xeb;
        A = 0x99;
    }
    ren[_0x2f10[0xf]](v, w, n, [
        y,
        z,
        A,
        p[_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] + 0x11;
    if (q[_0x2f10[0x3d]] < x[0x0]) {
        p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = x[0x0];
    }
    if (q[_0x2f10[0x3e]] < p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]]) {
        p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
    }
    p[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = w;
};
SenseUI[_0x2f10[0x68]] = function (o, v) {
    var w = gs_windows[gs_curwindow][_0x2f10[0x11]][gs_curgroup];
    if (!gs_windows[gs_curwindow][_0x2f10[0x3a]][o]) {
        var x = {};
        x['id'] = _0x2f10[0x1];
        x[m('0x2ba')] = _0x2f10[0x1];
        x[m('0x18a')] = 0x0;
        x[b(m('0x1d5'))] = ![];
        x[m('0x12f')] = [];
        var y = x;
        y[_0x2f10[0x1f]] = o;
        y[_0x2f10[0x69]] = v;
        y[_0x2f10[0x6a]] = gs_windows[gs_curwindow][_0x2f10[0x3a]][_0x2f10[0x2e]];
        if (o == 0x0) {
            y[_0x2f10[0x30]] = !![];
        }
        gs_windows[gs_curwindow][_0x2f10[0x3a]][o] = y;
    }
    gs_curtab = o;
    y = gs_windows[gs_curwindow][_0x2f10[0x3a]][gs_curtab];
    var z = 0x5a;
    var A = 0x5a;
    var B = 0x5a;
    if (y[_0x2f10[0x30]]) {
        z = 0xd2;
        A = 0xd2;
        B = 0xd2;
    }
    var C = 0x0;
    for (i in gs_windows[gs_curwindow][_0x2f10[0x3a]]) {
        if (gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x1f]] == o) {
            if (m('0x1e9') !== 'lCQsn') {
                var D = Entity[m('0x390')](_0x39e7x8b, _0x2f10[0xf4], _0x2f10[0xf5]);
                var E = Entity[m('0x390')](_0x39e7x8b, _0x2f10[0xf4], _0x2f10[0xf6]);
                var F = Entity['GetRenderO' + m('0x64')](_0x39e7x8b);
                for (; _0x39e7x89 > 0xb4;) {
                    _0x39e7x89 = _0x39e7x89 - 0x168;
                }
                for (; _0x39e7x89 < -0xb4;) {
                    _0x39e7x89 = _0x39e7x89 + 0x168;
                }
                var G = rotate_point(F, vec_add(F, D), _0x39e7x89);
                var K = rotate_point(F, vec_add(F, vec_add(D, [
                    E[0x0],
                    0x0,
                    0x0
                ])), _0x39e7x89);
                var L = rotate_point(F, vec_add(F, vec_add(D, [
                    0x0,
                    E[0x1],
                    0x0
                ])), _0x39e7x89);
                var M = rotate_point(F, vec_add(F, vec_add(D, [
                    E[0x0],
                    E[0x1],
                    0x0
                ])), _0x39e7x89);
                var N = rotate_point(F, vec_add(F, E), _0x39e7x89);
                var O = rotate_point(F, vec_add(F, vec_add(D, [
                    E[0x0],
                    0x0,
                    E[0x2]
                ])), _0x39e7x89);
                var P = rotate_point(F, vec_add(F, vec_add(D, [
                    0x0,
                    E[0x1],
                    E[0x2]
                ])), _0x39e7x89);
                var Q = rotate_point(F, vec_add(F, vec_add(D, [
                    0x0,
                    0x0,
                    E[0x2]
                ])), _0x39e7x89);
                var R = (G[0x0] + K[0x0] + L[0x0] + M[0x0] + N[0x0] + O[0x0] + P[0x0] + Q[0x0]) / 0x8;
                var S = (G[0x1] + K[0x1] + L[0x1] + M[0x1] + N[0x1] + O[0x1] + P[0x1] + Q[0x1]) / 0x8;
                var T = (G[0x2] + K[0x2] + L[0x2] + M[0x2] + N[0x2] + O[0x2] + P[0x2] + Q[0x2]) / 0x8;
                return [
                    R,
                    S,
                    T
                ];
            } else {
                C = gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x1f]];
            }
        }
    }
    gs_m = Input[b(m('0xaf'))]();
    if (gs_inbounds(gs_m, [
            gs_windows[gs_curwindow][_0x2f10[0x17]],
            gs_windows[gs_curwindow][_0x2f10[0x18]] + (0x19 + C * 0x50)
        ], [
            gs_windows[gs_curwindow][_0x2f10[0x17]] + 0x50,
            gs_windows[gs_curwindow][_0x2f10[0x18]] + (0x19 + C * 0x50) + 0x50
        ])) {
        z = 0xd2;
        A = 0xd2;
        B = 0xd2;
        if (Input[m('0x179') + 'ed'](0x1)) {
            if (m('0x164') === m('0x164')) {
                for (i in gs_windows[gs_curwindow][_0x2f10[0x3a]]) {
                    gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x30]] = ![];
                    if (gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x1f]] == o) {
                        gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x30]] = !![];
                    }
                }
            } else {
                E = vec_sub(Entity[m('0x30c') + 'rigin'](_0x39e7xc4), Entity[b('0xb8')](Entity[b(m('0x32c'))]()));
                E[0x2] = 0x0;
                F = Entity[b(m('0x297'))](_0x39e7xc4, _0x2f10[0xfe], _0x2f10[0xff]);
                F[0x0] = F[0x0] / 0xb4 * Math[_0x2f10[0xeb]];
                F[0x1] = F[0x1] / 0xb4 * Math[_0x2f10[0xeb]];
                G = anglevec(F);
                G[0x2] = 0x0;
                return E[0x0] * G[0x0] + E[0x1] * G[0x1] > 0x12;
            }
        }
    }
    var U = Render[m('0x355') + m('0x38')](y[_0x2f10[0x69]] + _0x2f10[0x1], SenseUI[_0x2f10[0x9]][_0x2f10[0x15]]);
    ren[_0x2f10[0xf]](gs_windows[gs_curwindow][_0x2f10[0x17]] + (0x28 - U[0x0] / 0x2), gs_windows[gs_curwindow][_0x2f10[0x18]] + (0x16 + C * 0x50) + (0x28 - U[0x1] / 0x2), v, [
        z,
        A,
        B,
        gs_windows[gs_curwindow][_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x15]]);
    return gs_windows[gs_curwindow][_0x2f10[0x3a]][o][_0x2f10[0x30]];
};
SenseUI[_0x2f10[0x6b]] = function () {
    var n = ![];
    for (i in gs_windows[gs_curwindow][_0x2f10[0x3a]]) {
        if (m('0x2af') !== b(m('0x33d'))) {
            if (gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x30]]) {
                n = !![];
                break;
            }
        } else {
            var o = Local[m('0xd5') + m('0x173')]();
            var p = [
                _0x39e7xb9 ? _0x39e7xb9 : 0x1c2,
                0x0,
                0x0
            ];
            var q = fix_move(_0x39e7xb8, o, p);
            UserCMD[m('0x241') + 't'](q);
        }
    }
    if (!n) {
        if (m('0x1d6') !== b(m('0x1f5'))) {
            gs_windows[gs_curwindow][_0x2f10[0x3a]][gs_curtab] = !![];
        } else {
            val = gs_curchild[_0x2f10[0x30]][0x1];
            gs_curchild[_0x2f10[0x31]] = _0x2f10[0x1];
        }
    }
    gs_curtab = _0x2f10[0x1];
};
SenseUI[_0x2f10[0x6c]] = function () {
    var n = gs_windows[gs_curwindow];
    var o = null;
    for (i in n[_0x2f10[0x3a]]) {
        if (m('0x2e3') === m('0xc6')) {
            _0x39e7xd8 = 0x5a;
        } else {
            if (n[_0x2f10[0x3a]][i][_0x2f10[0x30]]) {
                o = n[_0x2f10[0x3a]][i];
                break;
            }
        }
    }
    if (o) {
        var p = o[_0x2f10[0x1f]];
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]], n[_0x2f10[0x18]], 0x4f, 0x18 + p * 0x50, [
            0xc,
            0xc,
            0xc,
            n[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]], n[_0x2f10[0x18]] + 0x18 + (p + 0x1) * 0x50, 0x4f, n[_0x2f10[0x1a]] - (0x18 + (p + 0x1) * 0x50), [
            0xc,
            0xc,
            0xc,
            n[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]] + 0x50, n[_0x2f10[0x18]], 0x1, 0x19 + p * 0x50, [
            0x4b,
            0x4b,
            0x4b,
            n[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]], n[_0x2f10[0x18]] + 0x19 + p * 0x50, 0x51, 0x1, [
            0x4b,
            0x4b,
            0x4b,
            n[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]], n[_0x2f10[0x18]] + 0x18 + (p + 0x1) * 0x50, 0x50, 0x1, [
            0x4b,
            0x4b,
            0x4b,
            n[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](n[_0x2f10[0x17]] + 0x50, n[_0x2f10[0x18]] + 0x18 + (p + 0x1) * 0x50, 0x1, n[_0x2f10[0x1a]] - (0x19 + (p + 0x1) * 0x50), [
            0x4b,
            0x4b,
            0x4b,
            n[_0x2f10[0x1e]]
        ]);
    }
};
SenseUI[_0x2f10[0x6d]] = function (n, q, r) {
    var t = gs_windows[gs_curwindow];
    var v = t[_0x2f10[0x11]][gs_curgroup];
    var w = t[_0x2f10[0x17]] + v[_0x2f10[0x17]] + 0x19;
    var x = t[_0x2f10[0x18]] + v[_0x2f10[0x18]] + v[_0x2f10[0x5c]] - 0x3;
    var y = [
        0x1a,
        0x1a,
        0x1a,
        t[_0x2f10[0x1e]]
    ];
    var z = Render[m('0x355') + m('0x38')](n, SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    var A = ![];
    var B = n;
    gs_m = Input[m('0x352') + m('0x318')]();
    if (gs_inbounds(gs_m, [
            w,
            x + z[0x1] + 0x2
        ], [
            w + 0x9b,
            x + z[0x1] + 0x16
        ]) && !gs_isblocked) {
        if (m('0x2e1') === b(m('0x30b'))) {
            y = [
                0x24,
                0x24,
                0x24,
                0xff
            ];
            if (Input[b(m('0x290'))](0x1)) {
                if (m('0x32a') !== b(m('0x361'))) {
                    gs_curchild[_0x2f10[0x1f]] = B + _0x2f10[0x6e];
                    gs_curchild[_0x2f10[0x17]] = w;
                    gs_curchild[_0x2f10[0x18]] = x + z[0x1] + 0x16;
                    gs_curchild[_0x2f10[0x2d]] = 0x87;
                    gs_curchild[_0x2f10[0x2f]] = ![];
                    gs_curchild[_0x2f10[0x2c]] = q;
                    gs_curchild[_0x2f10[0x30]] = r;
                    gs_isblocked = !![];
                } else {
                    var C = {};
                    C['id'] = _0x2f10[0x1];
                    C[b(m('0x38f'))] = _0x2f10[0x1];
                    C[m('0x18a')] = 0x0;
                    C[m('0x7e')] = ![];
                    C[m('0x12f')] = [];
                    var D = C;
                    D[_0x2f10[0x1f]] = _0x39e7x29;
                    D[_0x2f10[0x69]] = _0x39e7x4a;
                    D[_0x2f10[0x6a]] = gs_windows[gs_curwindow][_0x2f10[0x3a]][_0x2f10[0x2e]];
                    if (_0x39e7x29 == 0x0) {
                        D[_0x2f10[0x30]] = !![];
                    }
                    gs_windows[gs_curwindow][_0x2f10[0x3a]][_0x39e7x29] = D;
                }
            }
        } else {
            kills = texts[_0x2f10[0x2e]];
        }
    }
    if (gs_curchild[_0x2f10[0x1f]] == B + _0x2f10[0x6e]) {
        A = !![];
    }
    if (gs_curchild[_0x2f10[0x31]] == B + _0x2f10[0x6e]) {
        r = gs_curchild[_0x2f10[0x30]][0x1];
        gs_curchild[_0x2f10[0x31]] = _0x2f10[0x1];
    }
    if (n) {
        ren[_0x2f10[0xf]](w, x, n, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    }
    ren[_0x2f10[0xe]](w, x + z[0x1] + 0x2, 0x9b, 0x13, y, [
        0x24,
        0x24,
        0x24,
        t[_0x2f10[0x1e]]
    ], !![]);
    ren[_0x2f10[0xc]](w, x + z[0x1] + 0x2, 0x9b, 0x14, [
        0x5,
        0x5,
        0x5,
        t[_0x2f10[0x1e]]
    ]);
    ren[_0x2f10[0xf]](w + 0xa, x + 0x6 + z[0x1], q[r], [
        0xb5,
        0xb5,
        0xb5,
        t[_0x2f10[0x1e]]
    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
    if (!A) {
        ren[_0x2f10[0xd]](w + 0x96 - 0x9, x + z[0x1] + 0xb, 0x5, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](w + 0x96 - 0x8, x + z[0x1] + 0xc, 0x3, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](w + 0x96 - 0x7, x + z[0x1] + 0xd, 0x1, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
    } else {
        ren[_0x2f10[0xd]](w + 0x96 - 0x7, x + z[0x1] + 0xb, 0x1, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](w + 0x96 - 0x8, x + z[0x1] + 0xc, 0x3, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
        ren[_0x2f10[0xd]](w + 0x96 - 0x9, x + z[0x1] + 0xd, 0x5, 0x1, [
            0xb5,
            0xb5,
            0xb5,
            t[_0x2f10[0x1e]]
        ]);
    }
    t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5d]] = !![];
    t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] = t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] + z[0x1] + 0x1b;
    if (v[_0x2f10[0x3d]] < 0x9b) {
        t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3d]] = 0x9b;
    }
    if (v[_0x2f10[0x3e]] < t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]]) {
        t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
    }
    t[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5e]] = x;
    return r;
};
function checkbox(n) {
    var o = UI[b(m('0x269'))](n);
    o[_0x2f10[0x6f]](![]);
    UI[_0x2f10[0x71]][_0x2f10[0x70]](null, o);
    o[_0x2f10[0x72]]();
    return o;
}
function slider(n, o, p) {
    var q = UI[m('0x3e') + 'nt'](n, o, p);
    q[_0x2f10[0x6f]](![]);
    UI[_0x2f10[0x71]][_0x2f10[0x70]](null, q);
    q[_0x2f10[0x72]]();
    return q;
}
var ui = [
    checkbox(_0x2f10[0x73]),
    slider(_0x2f10[0x74], 0x0, 0x64),
    checkbox(_0x2f10[0x75]),
    checkbox(_0x2f10[0x76]),
    checkbox(_0x2f10[0x77]),
    checkbox(_0x2f10[0x78]),
    checkbox(_0x2f10[0x79]),
    checkbox(_0x2f10[0x7a]),
    slider(_0x2f10[0x7b], 0x0, 0x3e8),
    checkbox(_0x2f10[0x7c]),
    checkbox(_0x2f10[0x7d]),
    slider(_0x2f10[0x7e], 0x0, 0x32),
    checkbox(_0x2f10[0x7f]),
    slider(_0x2f10[0x80], 0x0, 0xe),
    slider(_0x2f10[0x81], 0x1, 0x8),
    checkbox(_0x2f10[0x82]),
    checkbox(_0x2f10[0x83]),
    slider(_0x2f10[0x84], 0x0, 0x64),
    slider(_0x2f10[0x85], 0x0, 0x32),
    checkbox(_0x2f10[0x86]),
    checkbox(_0x2f10[0x87]),
    checkbox(_0x2f10[0x88]),
    checkbox(_0x2f10[0x89]),
    checkbox(_0x2f10[0x8a]),
    checkbox(_0x2f10[0x8b]),
    checkbox(_0x2f10[0x8c]),
    checkbox(_0x2f10[0x8d]),
    slider(_0x2f10[0x8e], 0x0, 0x64),
    checkbox(_0x2f10[0x8f]),
    checkbox(_0x2f10[0x90]),
    checkbox(_0x2f10[0x91]),
    slider(_0x2f10[0x92], 0x0, 0x32),
    slider(_0x2f10[0x93], 0x0, 0x32),
    checkbox(_0x2f10[0x94])
];
var e = {};
e[b(m('0x382'))] = ![];
e[m('0x1b7') + m('0x1d3')] = 0x0;
e[m('0x28b') + m('0x314')] = ![];
e[m('0x107')] = ![];
e[m('0xc4') + m('0x215') + m('0x2bd')] = ![];
e[b(m('0x284'))] = ![];
e[b(m('0x180'))] = ![];
e[m('0x240')] = ![];
e[b(m('0x115'))] = 0x0;
e[m('0x3a1') + m('0x1b5')] = ![];
e[b(m('0x60'))] = ![];
e[b(m('0x1c1'))] = 0x0;
e[b(m('0x2c2'))] = ![];
e[m('0x130') + 'nt'] = 0x0;
e[m('0x2aa')] = 0x0;
e[m('0x1fa')] = ![];
e[m('0x282')] = ![];
e[b(m('0xb9'))] = 0x5;
e[b(m('0x7c'))] = 0xf;
e[b(m('0x1e0'))] = ![];
e[m('0x1a') + m('0x28')] = ![];
e[m('0x11b') + m('0x3a6')] = ![];
e[m('0x28a')] = ![];
e[b(m('0x26d'))] = ![];
e[m('0x23b')] = ![];
e[m('0xc9')] = ![];
e[b(m('0x353'))] = ![];
e[m('0x2e4') + 'd'] = 0x0;
e[m('0x22e') + m('0x1d0')] = ![];
e[b('0x84')] = ![];
e[m('0xad')] = ![];
e[m('0x147')] = 0x0;
e[m('0x1f6')] = 0x0;
e[m('0x1e') + m('0xd1')] = ![];
var settings = e;
var playerlist_settings = [];
UI[m('0x27b')](_0x2f10[0x95]);
var hotkeys = [
    UI[b(m('0x309'))](_0x2f10[0x96]),
    UI[m('0x11a')](_0x2f10[0x97]),
    UI[b('0xcd')](_0x2f10[0x98]),
    UI['AddHotkey'](_0x2f10[0x99]),
    UI[b(m('0x309'))](_0x2f10[0x9a]),
    UI[m('0x11a')](_0x2f10[0x9b])
];
var cols = [UI[m('0x303') + m('0x43')](_0x2f10[0x9c])];
UI[b(m('0x2c4'))](_0x2f10[0x95]);
function setvalue(o, p) {
    o[_0x2f10[0x6f]](p);
    UI[_0x2f10[0x9d]][_0x2f10[0x70]](null, o);
    o[_0x2f10[0x72]]();
}
function getvalue(n) {
    return UI[_0x2f10[0x9e]][_0x2f10[0x70]](null, n);
}
var val = 0x0;
var selected_player = -0x1;
var f = {};
f[m('0x282')] = ![];
f[b(m('0x1c9'))] = ![];
f[b(m('0x397'))] = ![];
var indicators = f;
var backtrack_info = [];
function draw() {
    settings[_0x2f10[0x9f]] = getvalue(ui[0x0]);
    settings[_0x2f10[0xa0]] = getvalue(ui[0x1]);
    settings[_0x2f10[0xa1]] = getvalue(ui[0x2]);
    settings[_0x2f10[0xa2]] = getvalue(ui[0x3]);
    settings[_0x2f10[0xa3]] = getvalue(ui[0x4]);
    settings[_0x2f10[0xa4]] = getvalue(ui[0x5]);
    settings[_0x2f10[0xa5]] = getvalue(ui[0x6]);
    settings[_0x2f10[0xa6]] = getvalue(ui[0x7]);
    settings[_0x2f10[0xa7]] = getvalue(ui[0x8]);
    settings[_0x2f10[0xa8]] = getvalue(ui[0x9]);
    settings[_0x2f10[0xa9]] = getvalue(ui[0xa]);
    settings[_0x2f10[0xaa]] = getvalue(ui[0xb]);
    settings[_0x2f10[0xab]] = getvalue(ui[0xc]);
    settings[_0x2f10[0xac]] = getvalue(ui[0xd]);
    settings[_0x2f10[0x81]] = getvalue(ui[0xe]);
    settings[_0x2f10[0xad]] = getvalue(ui[0xf]);
    settings[_0x2f10[0x83]] = getvalue(ui[0x10]);
    settings[_0x2f10[0xae]] = getvalue(ui[0x11]);
    settings[_0x2f10[0xaf]] = getvalue(ui[0x12]);
    settings[_0x2f10[0x86]] = getvalue(ui[0x13]);
    settings[_0x2f10[0xb0]] = getvalue(ui[0x14]);
    settings[_0x2f10[0xb1]] = getvalue(ui[0x15]);
    settings[_0x2f10[0xb2]] = getvalue(ui[0x16]);
    settings[_0x2f10[0xb3]] = getvalue(ui[0x17]);
    settings[_0x2f10[0x8b]] = getvalue(ui[0x18]);
    settings[_0x2f10[0xb4]] = getvalue(ui[0x19]);
    settings[_0x2f10[0xb5]] = getvalue(ui[0x1c]);
    settings[_0x2f10[0xb6]] = getvalue(ui[0x1d]);
    settings[_0x2f10[0xb7]] = getvalue(ui[0x1e]);
    settings[_0x2f10[0xb8]] = getvalue(ui[0x1f]);
    settings[_0x2f10[0xb9]] = getvalue(ui[0x20]);
    settings[_0x2f10[0xba]] = getvalue(ui[0x21]);
    if (SenseUI[b(m('0x2c'))](0x1, 0xc8, 0xc8, 0x244, 0x21c)) {
        SenseUI[m('0x2b0')]();
        SenseUI[m('0x23a') + 't']();
        SenseUI[b(m('0xa1'))](!![]);
        if (SenseUI[m('0x20')](0x0, _0x2f10[0x3])) {
            if (SenseUI[b(m('0xca'))](0x1, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                if (m('0x332') !== m('0x34e')) {
                    settings[_0x2f10[0xb1]] = SenseUI[m('0xce')](_0x2f10[0xbc], settings[_0x2f10[0xb1]]);
                    settings[_0x2f10[0xba]] = SenseUI[b(m('0x2b'))](_0x2f10[0xbd], settings[_0x2f10[0xba]]);
                    setvalue(ui[0x21], settings[_0x2f10[0xba]]);
                    setvalue(ui[0x15], settings[_0x2f10[0xb1]]);
                    SenseUI[m('0x15b')]();
                } else {
                    settings[_0x2f10[0xa5]] = SenseUI[m('0xce')](_0x2f10[0x79], settings[_0x2f10[0xa5]]);
                    settings[_0x2f10[0xa6]] = SenseUI['Checkbox'](_0x2f10[0x7a], settings[_0x2f10[0xa6]]);
                    if (settings[_0x2f10[0xa5]]) {
                        settings[_0x2f10[0xac]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xbf], 0x8, 0xe, null, null, null, ![], settings[_0x2f10[0xac]]);
                        settings[_0x2f10[0x81]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xc0], 0x0, 0x8, null, null, null, ![], settings[_0x2f10[0x81]]);
                        setvalue(ui[0xd], settings[_0x2f10[0xac]]);
                        setvalue(ui[0xe], settings[_0x2f10[0x81]]);
                    }
                    settings[_0x2f10[0xad]] = SenseUI[m('0xce')](_0x2f10[0xc1], settings[_0x2f10[0xad]]);
                    setvalue(ui[0xf], settings[_0x2f10[0xad]]);
                    setvalue(ui[0x7], settings[_0x2f10[0xa6]]);
                    setvalue(ui[0x6], settings[_0x2f10[0xa5]]);
                    SenseUI[m('0x15b')]();
                }
            }
            if (SenseUI[m('0x255')](0x2, _0x2f10[0xbe], 0xe6, 0x0, 0xfa, 0x1ea)) {
                if (m('0x25c') !== m('0x25c')) {
                    ren[_0x2f10[0xd]](n[_0x2f10[0x17]] + o[_0x2f10[0x17]], n[_0x2f10[0x18]] + o[_0x2f10[0x18]], o[_0x2f10[0x19]], 0x1, [
                        K,
                        _0x39e7x33,
                        _0x39e7x34,
                        n[_0x2f10[0x1e]]
                    ]);
                    ren[_0x2f10[0xd]](n[_0x2f10[0x17]] + o[_0x2f10[0x17]] + 0x1, n[_0x2f10[0x18]] + o[_0x2f10[0x18]] - 0x1, o[_0x2f10[0x19]] + 0x1, 0x1, [
                        0x5,
                        0x5,
                        0x5,
                        n[_0x2f10[0x1e]]
                    ]);
                } else {
                    settings[_0x2f10[0xa5]] = SenseUI[m('0xce')](_0x2f10[0x79], settings[_0x2f10[0xa5]]);
                    settings[_0x2f10[0xa6]] = SenseUI[b(m('0x2b'))](_0x2f10[0x7a], settings[_0x2f10[0xa6]]);
                    if (settings[_0x2f10[0xa5]]) {
                        settings[_0x2f10[0xac]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xbf], 0x8, 0xe, null, null, null, ![], settings[_0x2f10[0xac]]);
                        settings[_0x2f10[0x81]] = SenseUI[m('0x202')](_0x2f10[0xc0], 0x0, 0x8, null, null, null, ![], settings[_0x2f10[0x81]]);
                        setvalue(ui[0xd], settings[_0x2f10[0xac]]);
                        setvalue(ui[0xe], settings[_0x2f10[0x81]]);
                    }
                    settings[_0x2f10[0xad]] = SenseUI[b('0x8')](_0x2f10[0xc1], settings[_0x2f10[0xad]]);
                    setvalue(ui[0xf], settings[_0x2f10[0xad]]);
                    setvalue(ui[0x7], settings[_0x2f10[0xa6]]);
                    setvalue(ui[0x6], settings[_0x2f10[0xa5]]);
                    SenseUI[m('0x15b')]();
                }
            }
            SenseUI[m('0x22d')]();
        }
        if (SenseUI[m('0x20')](0x1, _0x2f10[0xc2])) {
            if (SenseUI[b(m('0xca'))](0x3, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                settings[_0x2f10[0xa1]] = SenseUI[m('0xce')](_0x2f10[0x75], settings[_0x2f10[0xa1]]);
                settings[_0x2f10[0xa7]] = SenseUI[m('0x202')](_0x2f10[0xc3], 0x0, 0x3e8, null, null, null, ![], settings[_0x2f10[0xa7]]);
                settings[_0x2f10[0xa3]] = SenseUI[m('0xce')](_0x2f10[0xc4], settings[_0x2f10[0xa3]]);
                settings[_0x2f10[0xa8]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc5], settings[_0x2f10[0xa8]]);
                settings[_0x2f10[0xa9]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc6], settings[_0x2f10[0xa9]]);
                if (settings[_0x2f10[0xa9]]) {
                    if (b(m('0x10d')) !== m('0x63')) {
                        settings[_0x2f10[0xaa]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xc7], 0x0, 0x32, null, null, null, ![], settings[_0x2f10[0xaa]]);
                        setvalue(ui[0xb], settings[_0x2f10[0xaa]]);
                    } else {
                        n[_0x2f10[0x11]][_0x39e7x29][_0x2f10[0x22]] = ![];
                    }
                }
                settings[_0x2f10[0xb2]] = SenseUI[m('0xce')](_0x2f10[0xc8], settings[_0x2f10[0xb2]]);
                setvalue(ui[0x16], settings[_0x2f10[0xb2]]);
                setvalue(ui[0x2], settings[_0x2f10[0xa1]]);
                setvalue(ui[0x4], settings[_0x2f10[0xa3]]);
                setvalue(ui[0x8], settings[_0x2f10[0xa7]]);
                setvalue(ui[0xa], settings[_0x2f10[0xa9]]);
                setvalue(ui[0x9], settings[_0x2f10[0xa8]]);
                SenseUI[m('0x15b')]();
            }
            if (SenseUI[m('0x255')](0x4, _0x2f10[0xc9], 0xe6, 0x0, 0xfa, 0x1ea)) {
                settings[_0x2f10[0x9f]] = SenseUI[b(m('0x2b'))](_0x2f10[0xca], settings[_0x2f10[0x9f]]);
                settings[_0x2f10[0xa0]] = SenseUI[m('0x202')](_0x2f10[0xcb], 0x0, 0x64, null, null, null, ![], settings[_0x2f10[0xa0]]);
                setvalue(ui[0x0], settings[_0x2f10[0x9f]]);
                setvalue(ui[0x1], settings[_0x2f10[0xa0]]);
                SenseUI[b(m('0x2a3'))]();
            }
            SenseUI[b(m('0x1f'))]();
        }
        if (SenseUI[m('0x20')](0x2, _0x2f10[0x4])) {
            if (SenseUI[m('0x255')](0x5, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                if (b(m('0x20f')) === m('0x199')) {
                    if (gs_windows[gs_curwindow][_0x2f10[0x27]] != val) {
                        gs_windows[gs_curwindow][_0x2f10[0x27]] = val;
                        gs_log(_0x2f10[0x35] + val);
                    }
                } else {
                    SenseUI[m('0x15b')]();
                }
            }
            SenseUI['EndTab']();
        }
        if (SenseUI[b(m('0xe1'))](0x3, _0x2f10[0x5])) {
            if (m('0x2c7') !== m('0x2c7')) {
                _0x39e7x2a[_0x2f10[0x1a]] = 0x32;
            } else {
                if (SenseUI[m('0x255')](0x6, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                    if (b(m('0x225')) === m('0xd2')) {
                        if (gs_windows[gs_curwindow][_0x2f10[0x20]] != val) {
                            gs_windows[gs_curwindow][_0x2f10[0x20]] = val;
                            gs_log(_0x2f10[0x33] + val);
                        }
                    } else {
                        settings[_0x2f10[0xa4]] = SenseUI[m('0xce')](_0x2f10[0xcc], settings[_0x2f10[0xa4]]);
                        settings[_0x2f10[0xb4]] = SenseUI[b('0x8')](_0x2f10[0xcd], settings[_0x2f10[0xb4]]);
                        settings[_0x2f10[0xb6]] = SenseUI[b('0x8')](_0x2f10[0xce], settings[_0x2f10[0xb6]]);
                        settings[_0x2f10[0xb7]] = SenseUI[m('0xce')](_0x2f10[0xcf], settings[_0x2f10[0xb7]]);
                        settings[_0x2f10[0xb8]] = SenseUI['Slider'](_0x2f10[0xd0], 0x0, 0x32, null, null, null, !![], settings[_0x2f10[0xb8]]);
                        settings[_0x2f10[0xb9]] = SenseUI[m('0x202')](_0x2f10[0xd1], 0x0, 0x32, null, ![], ![], ![], settings[_0x2f10[0xb9]]);
                        setvalue(ui[0x1f], settings[_0x2f10[0xb8]]);
                        setvalue(ui[0x20], settings[_0x2f10[0xb9]]);
                        setvalue(ui[0x1e], settings[_0x2f10[0xb7]]);
                        setvalue(ui[0x1d], settings[_0x2f10[0xb6]]);
                        setvalue(ui[0x19], settings[_0x2f10[0xb4]]);
                        setvalue(ui[0x5], settings[_0x2f10[0xa4]]);
                        SenseUI[m('0x15b')]();
                    }
                }
                SenseUI[m('0x22d')]();
            }
        }
        if (SenseUI[m('0x20')](0x4, _0x2f10[0x6])) {
            if (SenseUI[b(m('0xca'))](0x6, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                settings[_0x2f10[0xa2]] = SenseUI[b(m('0x2b'))](_0x2f10[0xd2], settings[_0x2f10[0xa2]]);
                settings[_0x2f10[0xab]] = SenseUI[b(m('0x2b'))](_0x2f10[0xd3], settings[_0x2f10[0xab]]);
                settings[_0x2f10[0x8b]] = SenseUI[b(m('0x2b'))](_0x2f10[0xd4], settings[_0x2f10[0x8b]]);
                settings[_0x2f10[0xb5]] = SenseUI[m('0xce')](_0x2f10[0xd5], settings[_0x2f10[0xb5]]);
                settings[_0x2f10[0x83]] = SenseUI[m('0xce')](_0x2f10[0xd6], settings[_0x2f10[0x83]]);
                if (settings[_0x2f10[0x83]]) {
                    if (b(m('0x1ba')) !== m('0x1d1')) {
                        n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x3e]] = n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] - n[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x5c]] / 0x2;
                    } else {
                        settings[_0x2f10[0xae]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xd7], 0x0, 0x64, null, null, null, ![], settings[_0x2f10[0xae]]);
                        settings[_0x2f10[0xaf]] = SenseUI[m('0x202')](_0x2f10[0xd8], 0x0, 0x32, null, null, null, ![], settings[_0x2f10[0xaf]]);
                        setvalue(ui[0x11], settings[_0x2f10[0xae]]);
                        setvalue(ui[0x12], settings[_0x2f10[0xaf]]);
                    }
                }
                setvalue(ui[0x1c], settings[_0x2f10[0xb5]]);
                setvalue(ui[0x18], settings[_0x2f10[0x8b]]);
                setvalue(ui[0xc], settings[_0x2f10[0xab]]);
                setvalue(ui[0x3], settings[_0x2f10[0xa2]]);
                setvalue(ui[0x10], settings[_0x2f10[0x83]]);
                SenseUI[b(m('0x2a3'))]();
            }
            if (SenseUI[m('0x255')](0xa, _0x2f10[0xd9], 0xe6, 0x0, 0x154, 0x3e8)) {
                settings[_0x2f10[0x86]] = SenseUI[b(m('0x2b'))](_0x2f10[0xda], settings[_0x2f10[0x86]]);
                settings[_0x2f10[0xb0]] = SenseUI[b(m('0x2b'))](_0x2f10[0xdb], settings[_0x2f10[0xb0]]);
                settings[_0x2f10[0xb3]] = SenseUI[b(m('0x2b'))](_0x2f10[0xdc], settings[_0x2f10[0xb3]]);
                setvalue(ui[0x17], settings[_0x2f10[0xb3]]);
                setvalue(ui[0x13], settings[_0x2f10[0x86]]);
                setvalue(ui[0x14], settings[_0x2f10[0xb0]]);
                SenseUI[b(m('0x2a3'))]();
            }
            SenseUI[b(m('0x1f'))]();
        }
        if (SenseUI[m('0x20')](0x5, _0x2f10[0x8])) {
            if (SenseUI[m('0x255')](0x7, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                var n = gs_windows[gs_curwindow];
                var o = n[_0x2f10[0x11]][gs_curgroup];
                var p = n[_0x2f10[0x17]] + o[_0x2f10[0x17]] + 0x14;
                var q = n[_0x2f10[0x18]] + o[_0x2f10[0x18]] + 0x14;
                var r = o[_0x2f10[0x19]] - 0x28;
                var t = o[_0x2f10[0x1a]] - 0x28;
                ren[_0x2f10[0xd]](p - 0x1, q - 0x1, r + 0x2, t + 0x2, [
                    0x0,
                    0x0,
                    0x0,
                    n[_0x2f10[0x1e]]
                ]);
                ren[_0x2f10[0xd]](p, q, r, t, [
                    0x24,
                    0x24,
                    0x24,
                    n[_0x2f10[0x1e]]
                ]);
                var u = Entity[m('0x38b')]();
                u[_0x2f10[0xdd]](u[_0x2f10[0x55]](Entity[b(m('0x32c'))]()), 0x1);
                gs_m = Input[m('0x352') + m('0x318')]();
                for (x in u) {
                    ren[_0x2f10[0xf]](p + 0x5, q + 0x5 + x * 0x11, Entity[b(m('0x389'))](u[x]), selected_player == u[x] ? [
                        0x95,
                        0xb8,
                        0x6,
                        n[_0x2f10[0x1e]]
                    ] : [
                        0xb5,
                        0xb5,
                        0xb5,
                        n[_0x2f10[0x1e]]
                    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x12]]);
                    if (gs_inbounds(gs_m, [
                            p,
                            q + 0x5 + x * 0x11
                        ], [
                            p + r,
                            q + 0x5 + 0x11 + x * 0x11
                        ]) && Input[m('0x179') + 'ed'](0x1)) {
                        selected_player = u[x];
                    }
                }
                SenseUI[b(m('0x2a3'))]();
            }
            if (SenseUI[m('0x255')](0x8, _0x2f10[0xde], 0xe6, 0x0, 0xfa, 0x12c)) {
                if (selected_player == -0x1) {
                    SenseUI[m('0x65')](_0x2f10[0xdf], !![]);
                } else {
                    if (b(m('0x1fb')) !== m('0x204')) {
                        if (Entity[m('0x1c2')](selected_player)) {
                            if (!playerlist_settings[selected_player]) {
                                var w = {};
                                w[m('0x2f8')] = ![];
                                playerlist_settings[selected_player] = w;
                                playerlist_settings[selected_player][_0x2f10[0xe0]] = SenseUI[m('0xce')](_0x2f10[0xe1], playerlist_settings[selected_player][_0x2f10[0xe0]]);
                            }
                            if (SenseUI[b(m('0x2db'))](_0x2f10[0xe2], 0xaa, 0x32)) {
                                var x = 0x0;
                                for (; Entity[m('0x374') + m('0x42')](x) != selected_player;) {
                                    if (m('0xd') === m('0x242')) {
                                        o[_0x2f10[0x18]] = o[_0x2f10[0x18]] - (o[_0x2f10[0x18]] + o[_0x2f10[0x1a]] + 0x19 - n[_0x2f10[0x1a]]);
                                    } else {
                                        x++;
                                    }
                                }
                                Cheat[b(m('0x20c'))](_0x2f10[0xe3] + x);
                            }
                        }
                        if (Entity[b(m('0x1b9'))](selected_player)) {
                            if (b(m('0x3af')) === b(m('0x3af'))) {
                                if (!playerlist_settings[selected_player]) {
                                    var z = {};
                                    z[m('0x82') + m('0x2e0')] = ![];
                                    z[m('0x30a')] = ![];
                                    z[b(m('0x13d'))] = ![];
                                    playerlist_settings[selected_player] = z;
                                }
                                playerlist_settings[selected_player][_0x2f10[0xe4]] = SenseUI[m('0xce')](_0x2f10[0xe5], playerlist_settings[selected_player][_0x2f10[0xe4]]);
                                playerlist_settings[selected_player][_0x2f10[0xe6]] = SenseUI[m('0xce')](_0x2f10[0xe1], playerlist_settings[selected_player][_0x2f10[0xe6]]);
                                playerlist_settings[selected_player][_0x2f10[0xe7]] = SenseUI[m('0xce')](_0x2f10[0xe8], playerlist_settings[selected_player][_0x2f10[0xe7]]);
                            } else {
                                K = 0x95;
                                _0x39e7x33 = 0xb8;
                                _0x39e7x34 = 0x6;
                            }
                        }
                    } else {
                        var A = Math[_0x2f10[0xec]](_0x39e7x78[0x1] / 0xb4 * Math[_0x2f10[0xeb]]);
                        var B = Math[_0x2f10[0xed]](_0x39e7x78[0x1] / 0xb4 * Math[_0x2f10[0xeb]]);
                        var C = Math[_0x2f10[0xec]](_0x39e7x78[0x0] / 0xb4 * Math[_0x2f10[0xeb]]);
                        var D = Math[_0x2f10[0xed]](_0x39e7x78[0x0] / 0xb4 * Math[_0x2f10[0xeb]]);
                        return [
                            D * B,
                            D * A,
                            -C
                        ];
                    }
                }
                SenseUI[m('0x15b')]();
            }
            if (SenseUI[m('0x255')](0x9, _0x2f10[0xe9], 0xe6, 0x154, 0xfa, 0xbe)) {
                if (SenseUI[m('0x41')](_0x2f10[0xea], 0xaa, 0x32)) {
                    if (b(m('0x54')) === m('0x220')) {
                        playerlist_settings = [];
                    } else {
                        effects[_0x2f10[0xdd]](x, 0x1);
                        x--;
                    }
                }
                SenseUI[m('0x15b')]();
            }
            SenseUI[m('0x22d')]();
        }
        SenseUI[m('0xec')]();
    }
    if (settings[_0x2f10[0xa4]]) {
        if (m('0x61') !== m('0x61')) {
            effects[x][0x1] = 0xff;
            effects[x][0x6] = Globals[m('0x2d5')]();
            effects[x][0x2] = ![];
        } else {
            var E = Render[b(m('0x38e'))](_0x2f10[0x1], 0x20, 0x226);
            for (x in effects) {
                if (!effects[x][0x0]) {
                    if (m('0x1d') === m('0x1db')) {
                        settings[_0x2f10[0xa2]] = SenseUI[b('0x8')](_0x2f10[0xd2], settings[_0x2f10[0xa2]]);
                        settings[_0x2f10[0xab]] = SenseUI[m('0xce')](_0x2f10[0xd3], settings[_0x2f10[0xab]]);
                        settings[_0x2f10[0x8b]] = SenseUI[m('0xce')](_0x2f10[0xd4], settings[_0x2f10[0x8b]]);
                        settings[_0x2f10[0xb5]] = SenseUI[m('0xce')](_0x2f10[0xd5], settings[_0x2f10[0xb5]]);
                        settings[_0x2f10[0x83]] = SenseUI[b(m('0x2b'))](_0x2f10[0xd6], settings[_0x2f10[0x83]]);
                        if (settings[_0x2f10[0x83]]) {
                            settings[_0x2f10[0xae]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xd7], 0x0, 0x64, null, null, null, ![], settings[_0x2f10[0xae]]);
                            settings[_0x2f10[0xaf]] = SenseUI[m('0x202')](_0x2f10[0xd8], 0x0, 0x32, null, null, null, ![], settings[_0x2f10[0xaf]]);
                            setvalue(ui[0x11], settings[_0x2f10[0xae]]);
                            setvalue(ui[0x12], settings[_0x2f10[0xaf]]);
                        }
                        setvalue(ui[0x1c], settings[_0x2f10[0xb5]]);
                        setvalue(ui[0x18], settings[_0x2f10[0x8b]]);
                        setvalue(ui[0xc], settings[_0x2f10[0xab]]);
                        setvalue(ui[0x3], settings[_0x2f10[0xa2]]);
                        setvalue(ui[0x10], settings[_0x2f10[0x83]]);
                        SenseUI[m('0x15b')]();
                    } else {
                        continue;
                    }
                }
                Render[b(m('0x27a'))](effects[x][0x3], effects[x][0x4], 0x1, effects[x][0x0] + _0x2f10[0x1], [
                    effects[x][0x9][0x0],
                    effects[x][0x9][0x1],
                    effects[x][0x9][0x2],
                    effects[x][0x1]
                ], E);
                effects[x][0x3] += Math[_0x2f10[0xec]](effects[x][0x5] / 0xb4 * Math[_0x2f10[0xeb]]) * Globals[b(m('0x1cc'))]() * effects[x][0x7];
                effects[x][0x4] += Math[_0x2f10[0xed]](effects[x][0x5] / 0xb4 * Math[_0x2f10[0xeb]]) * Globals[m('0x1c0')]() * effects[x][0x7];
                if (effects[x][0x8]) {
                    effects[x][0x7] -= Globals[b(m('0x1cc'))]() * 0x96;
                    if (effects[x][0x7] < 0x64) {
                        effects[x][0x8] = ![];
                    }
                } else {
                    if (b('0x86') === m('0x16a')) {
                        G(_0x2f10[0xf1], [
                            0x0,
                            0xff,
                            0x0,
                            0xff
                        ]);
                    } else {
                        effects[x][0x7] += Globals[m('0x1c0')]() * 0xc8;
                    }
                }
                if (effects[x][0x2]) {
                    if (b(m('0x150')) !== b(m('0x17b'))) {
                        effects[x][0x1] += Globals[m('0x1c0')]() * 0x3e8;
                        if (effects[x][0x1] > 0xff && effects[x][0x6] == 0x0) {
                            effects[x][0x1] = 0xff;
                            effects[x][0x6] = Globals[m('0x2d5')]();
                            effects[x][0x2] = ![];
                        }
                    } else {
                        UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], _0x39e7x71);
                        last_yaw = _0x39e7x71;
                    }
                } else {
                    if (m('0x1e1') === m('0xd3')) {
                        autodirection();
                    } else {
                        if (Globals[b('0x3c')]() - effects[x][0x6] > 0x2) {
                            if (m('0x195') !== 'QiyGL') {
                                effects[x][0x1] -= Globals[m('0x1c0')]() * 0x1f4;
                                if (effects[x][0x1] < 0x0) {
                                    if (b('0xd9') !== m('0xbf')) {
                                        effects[_0x2f10[0xdd]](x, 0x1);
                                        x--;
                                    } else {
                                        o[_0x2f10[0x22]] = !![];
                                        _0x39e7x2c = !![];
                                        o[_0x2f10[0x23]] = gs_m[0x0] - o[_0x2f10[0x17]];
                                        o[_0x2f10[0x24]] = gs_m[0x1] - o[_0x2f10[0x18]];
                                        gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                                    }
                                }
                            } else {
                                var F = gs_windows[gs_curwindow];
                                ren[_0x2f10[0xe]](F[_0x2f10[0x17]], F[_0x2f10[0x18]], F[_0x2f10[0x19]] / 0x2, 0x1, [
                                    0x3b,
                                    0xaf,
                                    0xde,
                                    F[_0x2f10[0x1e]]
                                ], [
                                    0xca,
                                    0x46,
                                    0xcd,
                                    F[_0x2f10[0x1e]]
                                ], ![]);
                                ren[_0x2f10[0xe]](F[_0x2f10[0x17]] + F[_0x2f10[0x19]] / 0x2, F[_0x2f10[0x18]], F[_0x2f10[0x19]] / 0x2, 0x1, [
                                    0xca,
                                    0x46,
                                    0xcd,
                                    F[_0x2f10[0x1e]]
                                ], [
                                    0xc9,
                                    0xe3,
                                    0x3a,
                                    F[_0x2f10[0x1e]]
                                ], ![]);
                            }
                        }
                    }
                }
            }
        }
    }
    if (settings[_0x2f10[0xb4]]) {
        q = Render[m('0x391') + m('0x1ff')]()[0x1] / 0x2;
        p = 0x1e;
        E = Render[m('0x2a7')](_0x2f10[0xee], 0x18, 0x258);
        var G = function (O, P) {
            var Q = Render[m('0x355') + m('0x38')](O[_0x2f10[0xef]](), E);
            Render[b(m('0xf9'))](p, q, Q[0x0] / 0x2, Q[0x1], 0x1, [
                0x0,
                0x0,
                0x0,
                0x0
            ], [
                0x0,
                0x0,
                0x0,
                0x32
            ]);
            Render[m('0x167') + 'ct'](p + Q[0x0] / 0x2, q, Q[0x0] / 0x2, Q[0x1], 0x1, [
                0x0,
                0x0,
                0x0,
                0x32
            ], [
                0x0,
                0x0,
                0x0,
                0x0
            ]);
            Render[m('0x171') + 'om'](p, q, 0x0, O[_0x2f10[0xef]](), P, E);
            q = q + (Q[0x1] + 0xa);
        };
        if (indicators[_0x2f10[0x8b]]) {
            if (m('0x91') !== m('0x16b')) {
                G(_0x2f10[0x8b], [
                    0x0,
                    0xff,
                    0x0,
                    0xff
                ]);
            } else {
                gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
            }
        }
        if (indicators[_0x2f10[0x83]]) {
            G(_0x2f10[0x83], [
                0xff,
                0x0,
                0x0,
                0xff
            ]);
        }
        if (indicators[_0x2f10[0xf0]]) {
            if ('xJmul' !== b(m('0x19d'))) {
                G(_0x2f10[0xf1], [
                    0x0,
                    0xff,
                    0x0,
                    0xff
                ]);
            } else {
                return !![];
            }
        }
    }
    var H = Entity[b('0xf3')]();
    for (x in H) {
        if (Entity[b('0x18')](H[x]) && !Entity[b(m('0x16'))](H[x])) {
            if (b(m('0xc2')) === b(m('0x1b4'))) {
                Render[b(m('0x138'))](p, q, r, t, _0x39e7x11);
            } else {
                if (settings[_0x2f10[0xb7]]) {
                    do_circle(Entity[b(m('0x250'))](H[x]));
                }
                if (settings[_0x2f10[0xb6]]) {
                    if (m('0x28c') !== m('0x48')) {
                        if (backtrack_info[H[x]]) {
                            var I = !![];
                            var J = [];
                            for (p in backtrack_info[H[x]]) {
                                t = backtrack_info[H[x]][p];
                                var K = Render[m('0x36d') + m('0x1ca')](t);
                                if (!I) {
                                    if (m('0x2cb') !== 'fAXxX') {
                                        Render[m('0x243')](K[0x0], K[0x1], J[0x0], J[0x1], [
                                            0xff,
                                            0xff,
                                            0xff,
                                            0xff
                                        ]);
                                    } else {
                                        backtrack_info[H[i]] = [];
                                    }
                                }
                                I = ![];
                                J = K;
                            }
                        }
                    } else {
                        var M = Render[m('0x355') + m('0x38')](_0x39e7x64[_0x2f10[0xef]](), E);
                        Render[m('0x167') + 'ct'](p, q, M[0x0] / 0x2, M[0x1], 0x1, [
                            0x0,
                            0x0,
                            0x0,
                            0x0
                        ], [
                            0x0,
                            0x0,
                            0x0,
                            0x32
                        ]);
                        Render[m('0x167') + 'ct'](p + M[0x0] / 0x2, q, M[0x0] / 0x2, M[0x1], 0x1, [
                            0x0,
                            0x0,
                            0x0,
                            0x32
                        ], [
                            0x0,
                            0x0,
                            0x0,
                            0x0
                        ]);
                        Render[b(m('0x27a'))](p, q, 0x0, _0x39e7x64[_0x2f10[0xef]](), _0x39e7x11, E);
                        q = q + (M[0x1] + 0xa);
                    }
                }
            }
        }
    }
}
function rotate_point2(n, o, p) {
    var q = Math[_0x2f10[0xeb]] / 0xb4 * p;
    var u = Math[_0x2f10[0xed]](q);
    var v = Math[_0x2f10[0xec]](q);
    var w = u * (n[0x0] - o[0x0]) - v * (n[0x1] - o[0x1]) + o[0x0];
    var x = u * (n[0x1] - o[0x1]) + v * (n[0x0] - o[0x0]) + o[0x1];
    return [
        w,
        x
    ];
}
function render_arrow(n) {
    var p = -settings[_0x2f10[0xb8]] * 0x5;
    var q = settings[_0x2f10[0xb9]];
    var r = [
        0x0,
        0x0
    ];
    var s = [
        q,
        p
    ];
    var u = [
        -q,
        p
    ];
    var v = [
        0x0,
        p - q * 1.5
    ];
    var w = Render[m('0x391') + m('0x1ff')]();
    w[0x0] /= 0x2;
    w[0x1] /= 0x2;
    s[0x0] += w[0x0];
    s[0x1] += w[0x1];
    u[0x0] += w[0x0];
    u[0x1] += w[0x1];
    v[0x0] += w[0x0];
    v[0x1] += w[0x1];
    s = rotate_point2(s, w, n);
    u = rotate_point2(u, w, n);
    v = rotate_point2(v, w, n);
    var y = UI[_0x2f10[0xf2]][_0x2f10[0x70]](null, cols[0x0]);
    Render[m('0x1bd')]([
        s,
        u,
        v
    ], y);
    y[0x3] = 0xff;
    Render[b(m('0x22c'))](s[0x0], s[0x1], u[0x0], u[0x1], y);
    Render[m('0x243')](v[0x0], v[0x1], u[0x0], u[0x1], y);
    Render[b(m('0x22c'))](s[0x0], s[0x1], v[0x0], v[0x1], y);
}
function RadToDeg(n) {
    return n * 0xb4 / Math[_0x2f10[0xeb]];
}
function vecsub(n, o) {
    return [
        n[0x0] - o[0x0],
        n[0x1] - o[0x1],
        n[0x2] - o[0x2]
    ];
}
function anglevector(p) {
    var q = Math[_0x2f10[0xec]](p[0x1] / 0xb4 * Math[_0x2f10[0xeb]]);
    var r = Math[_0x2f10[0xed]](p[0x1] / 0xb4 * Math[_0x2f10[0xeb]]);
    var s = Math[_0x2f10[0xec]](p[0x0] / 0xb4 * Math[_0x2f10[0xeb]]);
    var t = Math[_0x2f10[0xed]](p[0x0] / 0xb4 * Math[_0x2f10[0xeb]]);
    return [
        t * r,
        t * q,
        -s
    ];
}
function crossproduct(n, o) {
    return [
        n[0x1] * o[0x2] - n[0x2] * o[0x1],
        n[0x2] * o[0x0] - n[0x0] * o[0x2],
        n[0x0] * o[0x1] - n[0x1] - o[0x0]
    ];
}
function dotproduct(n, o) {
    return n[0x0] * o[0x0] + n[0x1] * o[0x1] + n[0x2] * o[0x2];
}
function do_circle(o) {
    var p = Local[b(m('0xe6'))]();
    var q = Render[m('0x391') + m('0x1ff')]();
    q[0x0] /= 0x2;
    q[0x1] /= 0x2;
    var r = Entity[m('0x30c') + m('0x64')](Entity[m('0x18e') + m('0x1a4')]());
    r[0x2] = 0x0;
    o[0x2] = 0x0;
    var s = calcang(r, o);
    s[0x1] -= p[0x1];
    var t = anglevector(s);
    var u = Math[_0x2f10[0xf3]](t[0x1], t[0x0]) * 0xb4 / Math[_0x2f10[0xeb]];
    u = -u;
    render_arrow(u);
}
function d_line3d(n, o) {
    var p = Render[m('0x36d') + m('0x1ca')](n);
    var q = Render[m('0x36d') + m('0x1ca')](o);
    Render[m('0x243')](p[0x0], p[0x1], q[0x0], q[0x1], [
        0xff,
        0xff,
        0xff,
        0xff
    ]);
}
function rotate_point(n, o, p) {
    var q = Math[_0x2f10[0xeb]] / 0xb4 * p;
    var t = Math[_0x2f10[0xed]](q);
    var u = Math[_0x2f10[0xec]](q);
    var v = t * (o[0x0] - n[0x0]) - u * (o[0x1] - n[0x1]) + n[0x0];
    var w = t * (o[0x1] - n[0x1]) + u * (o[0x0] - n[0x0]) + n[0x1];
    return [
        v,
        w,
        o[0x2]
    ];
}
function draw_3d_box(n, o) {
    var p = Entity[m('0x390')](n, _0x2f10[0xf4], _0x2f10[0xf5]);
    var q = Entity[m('0x390')](n, _0x2f10[0xf4], _0x2f10[0xf6]);
    var r = Entity[b(m('0x250'))](n);
    for (; o > 0xb4;) {
        o = o - 0x168;
    }
    for (; o < -0xb4;) {
        o = o + 0x168;
    }
    var s = rotate_point(r, vec_add(r, p), o);
    var t = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        0x0,
        0x0
    ])), o);
    var u = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        q[0x1],
        0x0
    ])), o);
    var v = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        q[0x1],
        0x0
    ])), o);
    var w = rotate_point(r, vec_add(r, q), o);
    var y = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        0x0,
        q[0x2]
    ])), o);
    var z = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        q[0x1],
        q[0x2]
    ])), o);
    var A = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        0x0,
        q[0x2]
    ])), o);
    d_line3d(s, t);
    d_line3d(t, v);
    d_line3d(u, v);
    d_line3d(u, s);
    d_line3d(v, w);
    d_line3d(t, y);
    d_line3d(u, z);
    d_line3d(s, A);
    d_line3d(w, y);
    d_line3d(y, A);
    d_line3d(A, z);
    d_line3d(w, z);
}
function average_collisions_and_rotate(n, o) {
    var p = Entity[m('0x390')](n, _0x2f10[0xf4], _0x2f10[0xf5]);
    var q = Entity[m('0x390')](n, _0x2f10[0xf4], _0x2f10[0xf6]);
    var r = Entity[m('0x30c') + m('0x64')](n);
    for (; o > 0xb4;) {
        if (b('0x93') !== m('0x2e9')) {
            _0x39e7xe8 = !![];
        } else {
            o = o - 0x168;
        }
    }
    for (; o < -0xb4;) {
        o = o + 0x168;
    }
    var s = rotate_point(r, vec_add(r, p), o);
    var t = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        0x0,
        0x0
    ])), o);
    var u = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        q[0x1],
        0x0
    ])), o);
    var w = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        q[0x1],
        0x0
    ])), o);
    var x = rotate_point(r, vec_add(r, q), o);
    var B = rotate_point(r, vec_add(r, vec_add(p, [
        q[0x0],
        0x0,
        q[0x2]
    ])), o);
    var C = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        q[0x1],
        q[0x2]
    ])), o);
    var D = rotate_point(r, vec_add(r, vec_add(p, [
        0x0,
        0x0,
        q[0x2]
    ])), o);
    var E = (s[0x0] + t[0x0] + u[0x0] + w[0x0] + x[0x0] + B[0x0] + C[0x0] + D[0x0]) / 0x8;
    var F = (s[0x1] + t[0x1] + u[0x1] + w[0x1] + x[0x1] + B[0x1] + C[0x1] + D[0x1]) / 0x8;
    var G = (s[0x2] + t[0x2] + u[0x2] + w[0x2] + x[0x2] + B[0x2] + C[0x2] + D[0x2]) / 0x8;
    return [
        E,
        F,
        G
    ];
}
function vec_sub(n, o) {
    return [
        n[0x0] - o[0x0],
        n[0x1] - o[0x1],
        n[0x2] - o[0x2]
    ];
}
function vec_len(n) {
    return Math[_0x2f10[0xf7]](n[0x0] * n[0x0] + n[0x1] * n[0x1] + n[0x2] * n[0x2]);
}
function vec_add(n, o) {
    return [
        n[0x0] + o[0x0],
        n[0x1] + o[0x1],
        n[0x2] + o[0x2]
    ];
}
function vec_len2d(n) {
    return Math[_0x2f10[0xf7]](n[0x0] * n[0x0] + n[0x1] * n[0x1]);
}
function didhit(n) {
    return n[0x1] < 0x1 && n[0x0] == 0x0;
}
var real = Local[m('0x305')]();
var fake = Local[m('0x252')]();
var delta = real - fake;
for (; delta > 0xb4;) {
    delta = delta - 0x168;
}
for (; delta < -0xb4;) {
    delta = delta + 0x168;
}
var desync_amount = Math[_0x2f10[0xf8]](delta);
function calcang(n, q) {
    var r = [];
    r[0x0] = n[0x0] - q[0x0];
    r[0x1] = n[0x1] - q[0x1];
    r[0x2] = n[0x2] - q[0x2];
    var s = [];
    var t = Local[b(m('0xe6'))]();
    s[0x0] = RadToDeg(Math[_0x2f10[0xfa]](r[0x2] / Math[_0x2f10[0xf9]](r[0x0], r[0x1])));
    s[0x1] = RadToDeg(Math[_0x2f10[0xfa]](r[0x1] / r[0x0]));
    s[0x2] = 0x0;
    if (r[0x0] >= 0x0) {
        s[0x1] += 0xb4;
    }
    for (; s[0x1] > 0xb4;) {
        s[0x1] -= 0x168;
    }
    for (; s[0x1] < -0xb4;) {
        s[0x1] += 0x168;
    }
    return s;
}
function RadToDeg(n) {
    return n * 0xb4 / Math[_0x2f10[0xeb]];
}
function ray_end(n, o, p) {
    var q = vec_sub(o, n);
    q[0x0] *= p[0x1];
    q[0x1] *= p[0x1];
    q[0x2] *= p[0x1];
    q = vec_add(q, n);
    return q;
}
function wall_thickness(n, o, p, q) {
    var r;
    var s;
    var t = Trace[m('0x243')](p, n, o);
    if (didhit(t)) {
        if (m('0x35f') === m('0x191')) {
            _0x39e7x47 = _0x39e7x47 + _0x39e7x40;
        } else {
            r = ray_end(n, o, t);
        }
    } else {
        if (m('0xf2') !== m('0xf2')) {
            for (; !![];) {
            }
        } else {
            return -0x1;
        }
    }
    var u = Trace[m('0x243')](q, o, n);
    if (didhit(u)) {
        s = ray_end(o, n, u);
    } else {
        return -0x1;
    }
    return vec_len(vec_sub(s, r));
}
var last_yaw = 0x0;
function fix_move(n, o, q) {
    var s = function (y) {
        return y / 0xb4 * Math[_0x2f10[0xeb]];
    };
    var t;
    var u;
    var v;
    if (o[0x1] < 0x0) {
        if (m('0x356') === m('0x2ea')) {
            var w = normalize(calc_dir + step);
            var x = normalize(calc_dir - step);
            if (Math[_0x2f10[0xf8]](normalize(wish_direction - w)) >= Math[_0x2f10[0xf8]](normalize(wish_direction - x))) {
                calc_dir = calc_dir - step;
            } else {
                calc_dir = calc_dir + step;
            }
        } else {
            t = 0x168 + o[0x1];
        }
    } else {
        t = o[0x1];
    }
    if (n[0x1] < 0x0) {
        if (b(m('0x34b')) !== b(m('0x34b'))) {
            _0x39e7x44 = _0x39e7x1d;
            val = val - _0x39e7x44;
            _0x39e7x1d = _0x39e7x1d - _0x39e7x44;
            _0x39e7x1e = _0x39e7x1e - _0x39e7x44;
        } else {
            u = 0x168 + n[0x1];
        }
    } else {
        u = n[0x1];
    }
    if (u < t) {
        v = Math[_0x2f10[0xf8]](u - t);
    } else {
        if (b(m('0x14d')) !== m('0x81')) {
            v = 0x168 - Math[_0x2f10[0xf8]](t - u);
        } else {
            SenseUI[b(m('0x2a3'))]();
        }
    }
    return [
        Math[_0x2f10[0xed]](s(v)) * q[0x0] + Math[_0x2f10[0xed]](s(v + 0x5a)) * q[0x1],
        Math[_0x2f10[0xec]](s(v)) * q[0x0] + Math[_0x2f10[0xec]](s(v + 0x5a)) * q[0x1],
        0x0
    ];
}
function move_forward(n, o) {
    var p = Local[b(m('0xe6'))]();
    var q = [
        o ? o : 0x1c2,
        0x0,
        0x0
    ];
    var r = fix_move(n, p, q);
    UserCMD[m('0x241') + 't'](r);
}
function autodirection() {
    var n = 0x0;
    var o = 0x0;
    var p = [];
    var q = Entity[b(m('0x32c'))]();
    var r = Entity[m('0x2b7') + m('0x318')](q, 0x0);
    var t = Entity[m('0x30c') + m('0x64')](q);
    var u = Entity[b(m('0x10b'))](q);
    var w = -0x1;
    var y = 0xb4;
    var A = Entity[m('0x45')]();
    for (i in A) {
        if (m('0x340') !== m('0x340')) {
            wish_direction = _0x39e7xf5[0x1] + _0x39e7xf3[_0x2f10[0x110]];
        } else {
            if (!Entity[m('0x4d')](A[i]) || Entity['IsDormant'](A[i])) {
                if (m('0x2cf') !== m('0x11e')) {
                    continue;
                } else {
                    y = E;
                    w = A[i];
                }
            }
            var B = Local[m('0xd5') + m('0x173')]();
            var C = calcang(u, Entity[b(m('0x250'))](A[i]));
            var D = vec_sub(C, B);
            for (; D[0x1] > 0xb4;) {
                if (b(m('0x277')) !== m('0x159')) {
                    D[0x1] -= 0x168;
                } else {
                    if (Cheat[_0x2f10[0x50]][b(m('0x31a'))]() != _0x2f10[0x51] || whitelistt[_0x2f10[0x55]](Duktape[_0x2f10[0x54]](_0x2f10[0x52], Duktape[_0x2f10[0x54]](_0x2f10[0x53], Cheat[b(m('0x231'))]()))) == -0x1 || Function[_0x2f10[0x58]][_0x2f10[0x57]][_0x2f10[0x56]] == _0x2f10[0x1]) {
                        for (; !![];) {
                        }
                    }
                    check = Globals[m('0x2d5')]();
                }
            }
            for (; D[0x1] < -0xb4;) {
                if (m('0x321') !== m('0x321')) {
                    _0x39e7x89 = _0x39e7x89 + 0x168;
                } else {
                    D = D + 0x168;
                }
            }
            var E = vec_len2d(D);
            if (E < y) {
                y = E;
                w = A[i];
            }
        }
    }
    var F = 0x2 * Math[_0x2f10[0xeb]] / 0x12;
    var G = Math[_0x2f10[0xf8]](vec_len2d(vec_sub(r, t)));
    if (settings[_0x2f10[0xa9]]) {
        G = settings[_0x2f10[0xaa]];
    }
    if (w != -0x1) {
        if ('repjx' === b(m('0x184'))) {
            var H = vec_sub(_0x39e7xa6, _0x39e7xa5);
            H[0x0] *= _0x39e7x9a[0x1];
            H[0x1] *= _0x39e7x9a[0x1];
            H[0x2] *= _0x39e7x9a[0x1];
            H = vec_add(H, _0x39e7xa5);
            return H;
        } else {
            rotat = 0x0;
            for (; rotat < Math[_0x2f10[0xeb]] * 0x2; rotat = rotat + F) {
                if (m('0x392') !== b(m('0xe8'))) {
                    var I = [
                        G * Math[_0x2f10[0xed]](rotat) + u[0x0],
                        G * Math[_0x2f10[0xec]](rotat) + u[0x1],
                        u[0x2]
                    ];
                    var J = wall_thickness(Entity[m('0x3a8') + m('0xbc')](w), I, w, q);
                    if (J > o && J < settings[_0x2f10[0xa7]]) {
                        o = J;
                        n = rotat;
                        p = I;
                    }
                } else {
                    in_transition = !![];
                }
            }
            var K = n * 0xb4 / Math[_0x2f10[0xeb]];
            K = normalize(K);
            if (K != 0xb4) {
                UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], K);
                last_yaw = K;
            }
        }
    }
}
function normalize(n) {
    for (; n > 0xb4;) {
        if (b(m('0x230')) === b(m('0x349'))) {
            UserCMD[m('0x370')](_0x39e7xe2);
        } else {
            n = n - 0x168;
        }
    }
    for (; n < -0xb4;) {
        n = n + 0x168;
    }
    return n;
}
function anglevec(p) {
    var q = Math[_0x2f10[0xec]](p[0x1]);
    var r = Math[_0x2f10[0xed]](p[0x1]);
    var s = Math[_0x2f10[0xec]](p[0x0]);
    var t = Math[_0x2f10[0xed]](p[0x0]);
    return [
        t * r,
        t * q,
        -s
    ];
}
function vecadd(n, o) {
    return [
        n[0x0] + o[0x0],
        n[0x1] + o[0x1],
        n[0x2] + o[0x2]
    ];
}
function vecsub(n, o) {
    return [
        n[0x0] - o[0x0],
        n[0x1] - o[0x1],
        n[0x2] - o[0x2]
    ];
}
function vecmulfl(n, o) {
    return [
        n[0x0] * o,
        n[0x1] * o,
        n[0x2] * o
    ];
}
function autodir_v2() {
    var n = Entity[m('0x18e') + m('0x1a4')]();
    var o = Entity[m('0x2b7') + m('0x318')](n, 0x0);
    var q = Entity[b(m('0x250'))](n);
    var s = Entity[b(m('0x10b'))](n);
    var t = -0x1;
    var w = 0xb4;
    var y = Entity[m('0x45')]();
    for (i in y) {
        if (!Entity[b(m('0x260'))](y[i]) || Entity[m('0xd4')](y[i])) {
            continue;
        }
        var z = Local[m('0xd5') + m('0x173')]();
        var A = calcang(s, Entity[b(m('0x250'))](y[i]));
        var B = vec_sub(A, z);
        for (; B[0x1] > 0xb4;) {
            if (b(m('0x26b')) === b(m('0x253'))) {
                _0x39e7x23[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x27]] = val;
                gs_log(_0x2f10[0x65] + val);
            } else {
                B[0x1] -= 0x168;
            }
        }
        for (; B[0x1] < -0xb4;) {
            B = B + 0x168;
        }
        var C = vec_len2d(B);
        if (C < w) {
            w = C;
            t = y[i];
        }
    }
    if (t == -0x1) {
        if (b(m('0xe5')) === b(m('0x1f2'))) {
            autostrafer();
        } else {
            return;
        }
    }
    var D = calcang(s, Entity[b(m('0x10b'))](t))[0x1];
    var E = normalize(D + 0x5a);
    var F = normalize(D - 0x5a);
    var G = 0xa;
    if (settings[_0x2f10[0xa9]]) {
        G = settings[_0x2f10[0xaa]];
    }
    var H = vecmulfl(anglevec([
        0x0,
        E,
        0x0
    ]), G);
    var I = vecmulfl(anglevec([
        0x0,
        F,
        0x0
    ]), G);
    H = vec_add(s, H);
    I = vec_add(s, I);
    var J = wall_thickness(Entity[b(m('0x10b'))](t), H, t, n);
    var K = wall_thickness(Entity[b(m('0x10b'))](t), I, t, n);
    var L = 0x0;
    if (K > J && K < settings[_0x2f10[0xa7]]) {
        if (m('0x40') !== b(m('0x9b'))) {
            _0x39e7x4b = gs_windows[gs_curwindow][_0x2f10[0x3a]][i][_0x2f10[0x1f]];
        } else {
            L = 0x5a;
        }
    }
    if (J > K && J < settings[_0x2f10[0xa7]]) {
        L = -0x5a;
    }
    UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], L);
}
var last_str = _0x2f10[0x1];
var clantag_was_on = ![];
function isbehind(n) {
    var o = vec_sub(Entity[m('0x30c') + m('0x64')](n), Entity[b(m('0x10b'))](Entity[m('0x18e') + m('0x1a4')]()));
    o[0x2] = 0x0;
    var p = Entity[m('0x390')](n, _0x2f10[0xfe], _0x2f10[0xff]);
    p[0x0] = p[0x0] / 0xb4 * Math[_0x2f10[0xeb]];
    p[0x1] = p[0x1] / 0xb4 * Math[_0x2f10[0xeb]];
    var q = anglevec(p);
    q[0x2] = 0x0;
    return o[0x0] * q[0x0] + o[0x1] * q[0x1] > 0x12;
}
function knifebot() {
    var n = Entity[m('0x18e') + m('0x1a4')]();
    var o = Entity[b(m('0x13f'))]();
    if (!Entity[m('0x151')](Entity[b(m('0x27c'))](n))[_0x2f10[0x101]](_0x2f10[0x100])) {
        return;
    }
    var p = Entity[m('0x74')](n);
    var q = Entity[b(m('0x297'))](p, _0x2f10[0x102], _0x2f10[0x103]);
    var r = Entity[m('0x390')](n, _0x2f10[0x104], _0x2f10[0x105]);
    var t = r * Globals['TickInterv' + 'al']();
    var u = -0x1;
    var v = 0x41;
    for (i in o) {
        if (Entity[m('0x4d')](o[i])) {
            if (b(m('0x1d2')) !== b(m('0x1d2'))) {
                var w = Local[b(m('0xe6'))]();
                var x = Render[m('0x391') + m('0x1ff')]();
                x[0x0] /= 0x2;
                x[0x1] /= 0x2;
                var y = Entity[m('0x30c') + m('0x64')](Entity[m('0x18e') + m('0x1a4')]());
                y[0x2] = 0x0;
                _0x39e7x18[0x2] = 0x0;
                var A = calcang(y, _0x39e7x18);
                A[0x1] -= w[0x1];
                var B = anglevector(A);
                var C = Math[_0x2f10[0xf3]](B[0x1], B[0x0]) * 0xb4 / Math[_0x2f10[0xeb]];
                C = -C;
                render_arrow(C);
            } else {
                var D = Entity[m('0x3a8') + m('0xbc')](n);
                var E = Entity[b(m('0xb3'))](o[i], 0x3);
                var F = vec_sub(D, E);
                F = vec_len(F);
                if (F < v) {
                    if (m('0x210') !== m('0x210')) {
                        i = 0x1;
                        for (; i < 0xa4; i++) {
                            gs_keystates[i] = ![];
                            if (Input[b(m('0x290'))](i) && !gs_keystates2[i]) {
                                gs_keystates[i] = !![];
                                gs_keystates2[i] = !![];
                            }
                            if (!Input[m('0x179') + 'ed'](i) && gs_keystates2[i]) {
                                gs_keystates2[i] = ![];
                            }
                        }
                    } else {
                        v = F;
                        u = o[i];
                    }
                }
                E = Entity[m('0x2b7') + m('0x318')](o[i], 0x5);
                F = vec_sub(D, E);
                F = vec_len(F);
                if (F < v) {
                    if (b(m('0x268')) === m('0x145')) {
                        k = 0x0;
                        for (; k < gs_curchild[_0x2f10[0x30]][_0x2f10[0x2e]]; k++) {
                            if (gs_curchild[_0x2f10[0x30]][k] == i) {
                                _0x39e7x32 = 0x95;
                                _0x39e7x33 = 0xb8;
                                _0x39e7x34 = 0x6;
                                _0x39e7x35 = SenseUI[_0x2f10[0x9]][_0x2f10[0x13]];
                            }
                        }
                    } else {
                        v = F;
                        u = o[i];
                    }
                }
                E = Entity[b(m('0xb3'))](o[i], 0x4);
                F = vec_sub(D, E);
                F = vec_len(F);
                if (F < v) {
                    v = F;
                    u = o[i];
                }
                E = Entity[b(m('0x250'))](o[i]);
                E[0x2] += 0x1e;
                F = vec_sub(D, E);
                F = vec_len(F);
                if (F < v) {
                    if (m('0x131') !== m('0x125')) {
                        v = F;
                        u = o[i];
                    } else {
                        return _0x39e7x78 * 0xb4 / Math[_0x2f10[0xeb]];
                    }
                }
            }
        }
    }
    if (u == -0x1) {
        return;
    }
    var G = UserCMD[m('0x5f')]();
    var I = !settings[_0x2f10[0xb3]];
    D = Entity[b(m('0x10b'))](n);
    E = Entity[m('0x2b7') + m('0x318')](u, 0x3);
    var J = calcang(D, E);
    var K = ![];
    if (isbehind(o[i]) && v < 0x46 && settings[_0x2f10[0x86]]) {
        attacked = !![];
        G = G | 0x800;
        K = !![];
    } else {
        var L = ![];
        var M = Entity[b(m('0x297'))](u, _0x2f10[0x106], _0x2f10[0x107]);
        if (M <= 0x37) {
            if ('RkxtV' !== m('0x2c9')) {
                L = !![];
            } else {
                last_rot[_0x39e7x8b] = _0x39e7x71;
            }
        }
        if (L && settings[_0x2f10[0xb0]]) {
            G = G | 0x800;
            var N = Exploit[m('0x3b1')]() == 0x1 && UI[b(m('0x19e'))](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
            K = !![];
        } else {
            if (!settings[_0x2f10[0xb0]]) {
                G = G | (L ? 0x800 : 0x1);
                N = Exploit[m('0x3b1')]() == 0x1 && UI[b(m('0x19e'))](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
                if (G & 0x1 && N && UI[_0x2f10[0x9e]][_0x2f10[0x70]](null, settings) & 0x4) {
                    if (m('0x368') !== m('0x368')) {
                        backtrack_info[o[i]][_0x2f10[0x12c]]();
                    } else {
                        UI[m('0x116') + 'ey'](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
                    }
                }
                K = !![];
            }
        }
    }
    if (K) {
        if (b('0xd7') !== b(m('0x33a'))) {
            var O = !![];
            if (settings[_0x2f10[0xb3]]) {
                O = ![];
                var P = Local[b(m('0xe6'))]();
                F = vec_sub(J, P);
                F[0x1] = normalize(F[0x1]);
                if (Math[_0x2f10[0xf9]](F[0x0], F[0x1]) < 0xf) {
                    O = !![];
                }
                F = vecmulfl(F, Math[_0x2f10[0x10c]]() * 0.15 + 0.2);
                F = vec_add(F, P);
                J = F;
            }
            if (q < t && O) {
                if (m('0x1dd') === b(m('0x10'))) {
                    knifebot();
                } else {
                    UserCMD[b(m('0x2ae'))](G);
                }
            }
            UserCMD[m('0x77') + m('0x173')](J, I);
        } else {
            Ragebot[m('0xcf') + m('0x2d') + m('0x388')](o[i], Entity[m('0x390')](o[i], _0x2f10[0x106], _0x2f10[0x107]));
        }
    }
}
var g = {};
g[m('0x337')] = ![];
var h = {};
h[m('0x1df')] = ![];
h[m('0x354')] = 0x0;
h[m('0x37e') + 'd'] = 0x0;
var i = {};
i[m('0x1df')] = ![];
i[m('0x6b') + 'ng'] = ![];
i[m('0x2a0')] = 0x0;
i[b('0xe0')] = 0x0;
var j = {};
j[m('0x347')] = -0xb5;
var k = {};
k['fd'] = g;
k['jitter'] = h;
k[m('0x23b')] = i;
k[m('0x34c') + 'r'] = j;
var globals = k;
var last_rot = [];
function is_door_opening(n) {
    var o = Entity[b(m('0x297'))](globals[_0x2f10[0x8b]][_0x2f10[0x10d]], _0x2f10[0x106], _0x2f10[0x10e])[0x1];
    if (!last_rot[n]) {
        if (b('0x87') !== m('0x154')) {
            _0x39e7xee = 0x10e;
        } else {
            last_rot[n] = o;
        }
    }
    if (o > last_rot[n]) {
        last_rot[n] = o;
        return !![];
    }
    last_rot[n] = o;
    return ![];
}
function vecangle(n) {
    var o;
    var p;
    var q;
    if (n[0x1] == 0x0 && n[0x0] == 0x0) {
        if (m('0x1b6') === b(m('0xf1'))) {
            p = 0x0;
            if (n[0x2] > 0x0) {
                if (b(m('0x362')) === m('0x8')) {
                    q = 0x10e;
                } else {
                    effects[_0x39e7x62][0x1] -= Globals[m('0x1c0')]() * 0x1f4;
                    if (effects[_0x39e7x62][0x1] < 0x0) {
                        effects[_0x2f10[0xdd]](_0x39e7x62, 0x1);
                        _0x39e7x62--;
                    }
                }
            } else {
                q = 0x5a;
            }
        } else {
            ren[_0x2f10[0xd]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x19]] - 0x5, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x1a]] - 0x1, 0x5, 0x1, [
                _0x39e7x32,
                _0x39e7x33,
                _0x39e7x34,
                _0x39e7x23[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x19]] - 0x4, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x1a]] - 0x2, 0x4, 0x1, [
                _0x39e7x32,
                _0x39e7x33,
                _0x39e7x34,
                _0x39e7x23[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x19]] - 0x3, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x1a]] - 0x3, 0x3, 0x1, [
                _0x39e7x32,
                _0x39e7x33,
                _0x39e7x34,
                _0x39e7x23[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x19]] - 0x2, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x1a]] - 0x4, 0x2, 0x1, [
                _0x39e7x32,
                _0x39e7x33,
                _0x39e7x34,
                _0x39e7x23[_0x2f10[0x1e]]
            ]);
            ren[_0x2f10[0xd]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x19]] - 0x1, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x1a]] - 0x5, 0x1, 0x1, [
                _0x39e7x32,
                _0x39e7x33,
                _0x39e7x34,
                _0x39e7x23[_0x2f10[0x1e]]
            ]);
        }
    } else {
        if (m('0x1c6') === m('0x1c6')) {
            p = Math[_0x2f10[0xf3]](n[0x1], n[0x0]) * 0xb4 / Math[_0x2f10[0xeb]];
            if (p < 0x0) {
                p = p + 0x168;
            }
            o = Math[_0x2f10[0xf7]](n[0x0] * n[0x0] + n[0x1] * n[0x1]);
            q = Math[_0x2f10[0xf3]](-n[0x2], o) * 0xb4 / Math[_0x2f10[0xeb]];
            if (q < 0x0) {
                q = q + 0x168;
            }
        } else {
            Exploit[b(m('0x168'))](settings[_0x2f10[0xac]]);
            Exploit[b(m('0x30d'))](settings[_0x2f10[0x81]]);
        }
    }
    return [
        q,
        p,
        0x0
    ];
}
var calc_dir = 0x0;
var in_transition = ![];
var wish_direction = 0x0;
function autostrafer() {
    return;
    var p = {};
    p[b(m('0x28d'))] = 0x0;
    p[m('0x15e')] = 0xb4;
    p[m('0x1c8')] = 0x5a;
    p[m('0x385')] = -0x5a;
    var q = p;
    var r = Entity[m('0x390')](Entity[m('0x18e') + m('0x1a4')](), _0x2f10[0x106], _0x2f10[0x10f]) == _0x2f10[0x10f];
    if (!r) {
        in_transition = ![];
        calc_dir = q[_0x2f10[0x110]];
        return;
    }
    var s = Local[m('0xd5') + m('0x173')]();
    var t = function (M) {
        var N = [
            q[_0x2f10[0x110]],
            q[_0x2f10[0x111]],
            q[_0x2f10[0x112]],
            q[_0x2f10[0x113]]
        ];
        var O;
        var Q = 0xb5;
        for (i in N) {
            if (m('0x205') !== m('0x205')) {
                _0x39e7x23[_0x2f10[0x11]][gs_curgroup][_0x2f10[0x20]] = val;
                gs_log(_0x2f10[0x61] + val);
            } else {
                var R = s[0x1] + N[i];
                var S = Math[_0x2f10[0xf8]](normalize(M - R));
                if (S < Q) {
                    if (b(m('0x23e')) === b(m('0x23e'))) {
                        O = R;
                        Q = S;
                    } else {
                        _0x39e7xc5 = S;
                        _0x39e7xe1 = _0x39e7x65[i];
                    }
                }
            }
        }
        return O;
    };
    var u = Entity[b(m('0x297'))](Entity[m('0x18e') + 'ayer'](), _0x2f10[0x106], _0x2f10[0x114]);
    var v = vecangle(u)[0x1];
    var w = UserCMD[m('0x5f')]();
    if (w & 0x1 << 0x3) {
        wish_direction = s[0x1] + q[_0x2f10[0x110]];
    } else {
        if (m('0x25a') !== m('0x25a')) {
            settings[_0x2f10[0xa4]] = SenseUI[b(m('0x2b'))](_0x2f10[0xcc], settings[_0x2f10[0xa4]]);
            settings[_0x2f10[0xb4]] = SenseUI[m('0xce')](_0x2f10[0xcd], settings[_0x2f10[0xb4]]);
            settings[_0x2f10[0xb6]] = SenseUI[m('0xce')](_0x2f10[0xce], settings[_0x2f10[0xb6]]);
            settings[_0x2f10[0xb7]] = SenseUI[m('0xce')](_0x2f10[0xcf], settings[_0x2f10[0xb7]]);
            settings[_0x2f10[0xb8]] = SenseUI[m('0x202')](_0x2f10[0xd0], 0x0, 0x32, null, null, null, !![], settings[_0x2f10[0xb8]]);
            settings[_0x2f10[0xb9]] = SenseUI[m('0x202')](_0x2f10[0xd1], 0x0, 0x32, null, ![], ![], ![], settings[_0x2f10[0xb9]]);
            setvalue(ui[0x1f], settings[_0x2f10[0xb8]]);
            setvalue(ui[0x20], settings[_0x2f10[0xb9]]);
            setvalue(ui[0x1e], settings[_0x2f10[0xb7]]);
            setvalue(ui[0x1d], settings[_0x2f10[0xb6]]);
            setvalue(ui[0x19], settings[_0x2f10[0xb4]]);
            setvalue(ui[0x5], settings[_0x2f10[0xa4]]);
            SenseUI[b(m('0x2a3'))]();
        } else {
            if (w & 0x1 << 0x4) {
                wish_direction = s[0x1] + q[_0x2f10[0x111]];
            } else {
                if (w & 0x1 << 0x9) {
                    wish_direction = s[0x1] + q[_0x2f10[0x112]];
                } else {
                    if (b(m('0x2c8')) === b(m('0x8b'))) {
                        UI[m('0x116') + 'ey'](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
                    } else {
                        if (w & 0x1 << 0xa) {
                            wish_direction = s[0x1] + q[_0x2f10[0x113]];
                        } else {
                            if (b('0x63') !== b('0xd')) {
                                w = w | 0x1 << 0x3;
                                wish_direction = s[0x1];
                            } else {
                                return [
                                    _0x39e7x78[0x0] + _0x39e7x34[0x0],
                                    _0x39e7x78[0x1] + _0x39e7x34[0x1],
                                    _0x39e7x78[0x2] + _0x39e7x34[0x2]
                                ];
                            }
                        }
                    }
                }
            }
        }
    }
    var y = Math[_0x2f10[0x116]](Math[_0x2f10[0x115]](0x1e / Math[_0x2f10[0xf9]](u[0x0], u[0x1])) / 0xb4 * Math[_0x2f10[0xeb]] * 0.5, 0x2d);
    if (in_transition) {
        if (b('0x8d') !== b(m('0x378'))) {
            Ragebot[m('0xcf') + m('0x1ed')](_0x39e7xc4);
        } else {
            var z = y + calc_dir;
            step = Math[_0x2f10[0xf8]](normalize(calc_dir - z));
            if (Math[_0x2f10[0xf8]](normalize(wish_direction - calc_dir)) > step) {
                if (m('0x24c') !== m('0x21a')) {
                    var A = normalize(calc_dir + step);
                    var B = normalize(calc_dir - step);
                    if (Math[_0x2f10[0xf8]](normalize(wish_direction - A)) >= Math[_0x2f10[0xf8]](normalize(wish_direction - B))) {
                        if (m('0x20e') === m('0x1bc')) {
                            if (val > _0x39e7x1e) {
                                return _0x39e7x1e;
                            }
                            if (_0x39e7x1d > val) {
                                return _0x39e7x1d;
                            }
                            return val;
                        } else {
                            calc_dir = calc_dir - step;
                        }
                    } else {
                        calc_dir = calc_dir + step;
                    }
                } else {
                    var C = average_collisions_and_rotate(globals[_0x2f10[0x8b]][_0x2f10[0x10d]], Entity[m('0x390')](globals[_0x2f10[0x8b]][_0x2f10[0x10d]], _0x2f10[0x106], _0x2f10[0x10e])[0x1]);
                    var D = calcang(_0x39e7x119, C);
                    UserCMD['SetViewAng' + m('0x173')](D, !![]);
                    UserCMD[b(m('0x2ae'))](UserCMD[m('0x5f')]() | 0x1 << 0x5);
                    globals[_0x2f10[0x8b]][_0x2f10[0x10d]] = 0x0;
                    globals[_0x2f10[0x8b]][_0x2f10[0x128]] = ![];
                    globals[_0x2f10[0x8b]][_0x2f10[0x129]] = 0x0;
                }
            } else {
                in_transition = ![];
            }
        }
    } else {
        if (m('0x2cd') !== b(m('0x1cb'))) {
            return;
        } else {
            rough_dir = t(v);
            calc_dir = rough_dir;
            if (rough_dir != wish_direction) {
                if (b(m('0xa2')) === m('0x79')) {
                    if (SenseUI[b(m('0xca'))](0x6, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                        settings[_0x2f10[0xa4]] = SenseUI[m('0xce')](_0x2f10[0xcc], settings[_0x2f10[0xa4]]);
                        settings[_0x2f10[0xb4]] = SenseUI[m('0xce')](_0x2f10[0xcd], settings[_0x2f10[0xb4]]);
                        settings[_0x2f10[0xb6]] = SenseUI['Checkbox'](_0x2f10[0xce], settings[_0x2f10[0xb6]]);
                        settings[_0x2f10[0xb7]] = SenseUI[m('0xce')](_0x2f10[0xcf], settings[_0x2f10[0xb7]]);
                        settings[_0x2f10[0xb8]] = SenseUI['Slider'](_0x2f10[0xd0], 0x0, 0x32, null, null, null, !![], settings[_0x2f10[0xb8]]);
                        settings[_0x2f10[0xb9]] = SenseUI[m('0x202')](_0x2f10[0xd1], 0x0, 0x32, null, ![], ![], ![], settings[_0x2f10[0xb9]]);
                        setvalue(ui[0x1f], settings[_0x2f10[0xb8]]);
                        setvalue(ui[0x20], settings[_0x2f10[0xb9]]);
                        setvalue(ui[0x1e], settings[_0x2f10[0xb7]]);
                        setvalue(ui[0x1d], settings[_0x2f10[0xb6]]);
                        setvalue(ui[0x19], settings[_0x2f10[0xb4]]);
                        setvalue(ui[0x5], settings[_0x2f10[0xa4]]);
                        SenseUI[b(m('0x2a3'))]();
                    }
                    SenseUI[m('0x22d')]();
                } else {
                    in_transition = !![];
                }
            }
        }
    }
    var E = [];
    E[0x0] = 0x0;
    E[0x1] = Globals[m('0x193')]() % 0x2 ? 0x1c2 : -0x1c2;
    var F = (Globals[b(m('0x322'))]() % 0x2 ? y : -y) + calc_dir;
    var H = (s[0x1] - F) / 0xb4 * Math[_0x2f10[0xeb]];
    var I = Math[_0x2f10[0xed]](H);
    var J = Math[_0x2f10[0xec]](H);
    var K = I * E[0x0] - J * E[0x1];
    var L = J * E[0x0] + I * E[0x1];
    E[0x0] = K;
    E[0x1] = L;
    E[0x2] = UserCMD[b(m('0xc7'))]()[0x2];
    UserCMD[b(m('0x1bb'))](E);
}
var jumping = ![];
var thrown = ![];
var throwing = ![];
var lasthp = 0x0;
function grenade_griefer() {
    var o = Entity[b(m('0x32c'))]();
    var p = Entity[b(m('0x389'))](Entity[m('0x74')](o));
    if (p != _0x2f10[0x117] && !thrown) {
        jumping = ![];
        throwing = ![];
        return;
    }
    var q = Entity[b(m('0x250'))](o);
    var r = vec_add(q, [
        0x1,
        0x0,
        0x0
    ]);
    var t = vec_add(q, [
        -0x1,
        0x0,
        0x0
    ]);
    var u = vec_add(q, [
        0x0,
        0x1,
        0x0
    ]);
    var v = vec_add(q, [
        0x0,
        -0x2,
        0x0
    ]);
    var w = Trace[m('0x243')](o, r, vec_add(r, [
        0x0,
        0x0,
        -0x14
    ]));
    var x = Trace[b(m('0x22c'))](o, t, vec_add(t, [
        0x0,
        0x0,
        -0x14
    ]));
    var z = Trace[m('0x243')](o, u, vec_add(u, [
        0x0,
        0x0,
        -0x14
    ]));
    var A = Trace[m('0x243')](o, v, vec_add(v, [
        0x0,
        0x0,
        -0x14
    ]));
    var B = Trace[b(m('0x22c'))](o, q, vec_add(q, [
        0x0,
        0x0,
        -0x14
    ]));
    var C = Entity[m('0x390')](o, _0x2f10[0x106], _0x2f10[0x107]);
    if (lasthp != C) {
        thrown = ![];
        throwing = ![];
        jumping = ![];
        lasthp = C;
        return;
    }
    if (w[0x1] == B[0x1] && x[0x1] == B[0x1] && z[0x1] == B[0x1] && A[0x1] == B[0x1] || jumping) {
        if (!jumping) {
            UserCMD[m('0x370')](0x1 << 0x1);
            UserCMD[m('0x241') + 't']([
                0x0,
                0x0,
                0x0
            ]);
            jumping = !![];
            return;
        }
        var D = Entity[m('0x390')](o, _0x2f10[0x106], _0x2f10[0x114])[0x2];
        if (D == 0x0) {
            if (m('0x19b') !== b(m('0x6'))) {
                if (SenseUI[b(m('0xca'))](0x3, _0x2f10[0xbb], 0x0, 0x0, 0xd2, 0x1ea)) {
                    settings[_0x2f10[0xa1]] = SenseUI[b(m('0x2b'))](_0x2f10[0x75], settings[_0x2f10[0xa1]]);
                    settings[_0x2f10[0xa7]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xc3], 0x0, 0x3e8, null, null, null, ![], settings[_0x2f10[0xa7]]);
                    settings[_0x2f10[0xa3]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc4], settings[_0x2f10[0xa3]]);
                    settings[_0x2f10[0xa8]] = SenseUI[m('0xce')](_0x2f10[0xc5], settings[_0x2f10[0xa8]]);
                    settings[_0x2f10[0xa9]] = SenseUI['Checkbox'](_0x2f10[0xc6], settings[_0x2f10[0xa9]]);
                    if (settings[_0x2f10[0xa9]]) {
                        settings[_0x2f10[0xaa]] = SenseUI[m('0x202')](_0x2f10[0xc7], 0x0, 0x32, null, null, null, ![], settings[_0x2f10[0xaa]]);
                        setvalue(ui[0xb], settings[_0x2f10[0xaa]]);
                    }
                    settings[_0x2f10[0xb2]] = SenseUI[b(m('0x2b'))](_0x2f10[0xc8], settings[_0x2f10[0xb2]]);
                    setvalue(ui[0x16], settings[_0x2f10[0xb2]]);
                    setvalue(ui[0x2], settings[_0x2f10[0xa1]]);
                    setvalue(ui[0x4], settings[_0x2f10[0xa3]]);
                    setvalue(ui[0x8], settings[_0x2f10[0xa7]]);
                    setvalue(ui[0xa], settings[_0x2f10[0xa9]]);
                    setvalue(ui[0x9], settings[_0x2f10[0xa8]]);
                    SenseUI[b(m('0x2a3'))]();
                }
                if (SenseUI[m('0x255')](0x4, _0x2f10[0xc9], 0xe6, 0x0, 0xfa, 0x1ea)) {
                    settings[_0x2f10[0x9f]] = SenseUI[m('0xce')](_0x2f10[0xca], settings[_0x2f10[0x9f]]);
                    settings[_0x2f10[0xa0]] = SenseUI[b(m('0x3aa'))](_0x2f10[0xcb], 0x0, 0x64, null, null, null, ![], settings[_0x2f10[0xa0]]);
                    setvalue(ui[0x0], settings[_0x2f10[0x9f]]);
                    setvalue(ui[0x1], settings[_0x2f10[0xa0]]);
                    SenseUI[b(m('0x2a3'))]();
                }
                SenseUI['EndTab']();
            } else {
                UserCMD[b(m('0x2ae'))](0x1 << 0x2);
                throwing = ![];
                return;
            }
        }
        if (thrown) {
            UserCMD['SetViewAng' + m('0x173')]([
                -0x59,
                0x0,
                0x0
            ], !![]);
            return;
        }
        if (D < 0x5 && !throwing) {
            if (m('0x364') === m('0x363')) {
                _0x39e7x24[_0x2f10[0x3b]] = _0x39e7x24[_0x2f10[0x3b]][_0x2f10[0x3f]](0x1, -0x2);
                _0x39e7x30 = Render[m('0x355') + m('0x38')](_0x39e7x24[_0x2f10[0x3b]], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
                _0x39e7x3a = _0x39e7xf - 0x12 - _0x39e7x30[0x0] - 0x3;
            } else {
                throwing = !![];
            }
        }
        if (throwing) {
            UserCMD[b(m('0x2ae'))](0x1 << 0xb);
            UserCMD[b(m('0x196'))]([
                -0x59,
                0x0,
                0x0
            ], !![]);
            thrown = !![];
        }
    }
}
var last_ent_shot = -0x1;
function cm() {
    var o = Ragebot[b(m('0x4'))]();
    var q = Entity[m('0x18e') + m('0x1a4')]();
    var r = Entity[m('0x45')]();
    var s = Entity[b(m('0x250'))](q);
    var t = Entity[b(m('0x10b'))](q);
    if (settings[_0x2f10[0xa1]]) {
        UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], 0x0);
        if (!(UI[b(m('0x19e'))](_0x2f10[0xfb], _0x2f10[0x11c], _0x2f10[0x11d]) && settings[_0x2f10[0xa3]])) {
            UI[m('0x4f')](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0x11e], !![]);
            if (settings[_0x2f10[0xa8]]) {
                if (b(m('0x3a5')) === m('0x396')) {
                    autodir_v2();
                } else {
                    _0x39e7x24[_0x2f10[0x21]] = !![];
                    _0x39e7x2c = !![];
                    _0x39e7x24[_0x2f10[0x28]] = gs_m[0x0] - _0x39e7x24[_0x2f10[0x19]];
                    _0x39e7x24[_0x2f10[0x29]] = gs_m[0x1] - _0x39e7x24[_0x2f10[0x1a]];
                    gs_windows[gs_curwindow][_0x2f10[0x22]] = ![];
                }
            } else {
                if (m('0x14c') === m('0x14c')) {
                    autodirection();
                } else {
                    ren[_0x2f10[0xf]](_0x39e7x23[_0x2f10[0x17]] + _0x39e7x24[_0x2f10[0x17]] + 0x12, _0x39e7x23[_0x2f10[0x18]] + _0x39e7x24[_0x2f10[0x18]] - 0x6, _0x39e7x24[_0x2f10[0x3b]], [
                        _0x39e7x32,
                        _0x39e7x33,
                        _0x39e7x34,
                        _0x39e7x23[_0x2f10[0x1e]]
                    ], SenseUI[_0x2f10[0x9]][_0x2f10[0x13]]);
                }
            }
        }
    }
    if (settings[_0x2f10[0xa2]]) {
        if (m('0x2e8') !== m('0x2e8')) {
            _0x39e7x24[_0x2f10[0x1a]] = gs_clamp(_0x39e7x24[_0x2f10[0x1a]] - (_0x39e7x24[_0x2f10[0x1a]] + _0x39e7x24[_0x2f10[0x18]] + 0x19 - _0x39e7x23[_0x2f10[0x1a]]), 0x32, _0x39e7x23[_0x2f10[0x1a]] - 0x32);
        } else {
            _currentModifierKeys = UserCMD[b(m('0x5e'))]();
            UserCMD[b(m('0x2ae'))](_currentModifierKeys | 0x1 << 0x16);
        }
    }
    if (settings[_0x2f10[0xa5]]) {
        Exploit[b(m('0x168'))](settings[_0x2f10[0xac]]);
        Exploit[b(m('0x30d'))](settings[_0x2f10[0x81]]);
    } else {
        Exploit[m('0x76') + m('0x3b5')](0xc);
        Exploit[m('0x224') + m('0x286')](0x2);
    }
    if (settings[_0x2f10[0xa6]] && UI[m('0x279') + m('0x214')](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b])) {
        if (m('0x24e') === b(m('0xc8'))) {
            r = Entity[b(m('0x13f'))]();
            for (i in r) {
                if (m('0x9c') !== b(m('0x21d'))) {
                    if (!Entity[m('0x4d')](r[i]) || Entity[b(m('0x16'))](r[i])) {
                        if (m('0x27d') === m('0x27d')) {
                            continue;
                        } else {
                            y = _0x39e7xc7;
                            W = r[i];
                        }
                    }
                    if (Exploit[m('0x3b1')]() == 0x1) {
                        Ragebot[b('0xa2')](r[i], Math[_0x2f10[0x63]](Entity[m('0x390')](r[i], _0x2f10[0x106], _0x2f10[0x107]) / 0x2));
                    } else {
                        if (Entity[m('0x390')](r[i], _0x2f10[0x106], _0x2f10[0x107]) <= 0x32) {
                            Ragebot[m('0xcf') + m('0x2d') + m('0x388')](r[i], Entity[b(m('0x297'))](r[i], _0x2f10[0x106], _0x2f10[0x107]));
                        }
                    }
                } else {
                    _0x39e7x71 = _0x39e7x71 + 0x168;
                }
            }
        } else {
            settings[_0x2f10[0x9f]] = SenseUI[m('0xce')](_0x2f10[0xca], settings[_0x2f10[0x9f]]);
            settings[_0x2f10[0xa0]] = SenseUI[m('0x202')](_0x2f10[0xcb], 0x0, 0x64, null, null, null, ![], settings[_0x2f10[0xa0]]);
            setvalue(ui[0x0], settings[_0x2f10[0x9f]]);
            setvalue(ui[0x1], settings[_0x2f10[0xa0]]);
            SenseUI[m('0x15b')]();
        }
    }
    if (settings[_0x2f10[0xab]]) {
        var u = _0x2f10[0x11f];
        i = 0x0;
        for (; i < Math[_0x2f10[0x120]](Globals[b(m('0x322'))]() / 0x10) % u[_0x2f10[0x2e]]; i++) {
            u = u + u[_0x2f10[0x121]](0x0, 0x1);
            u = u[_0x2f10[0x121]](0x1);
        }
        if (u != last_str) {
            if (m('0x3c') === b(m('0x343'))) {
                var x = _0x2f10[0x11f];
                i = 0x0;
                for (; i < Math[_0x2f10[0x120]](Globals[m('0x193')]() / 0x10) % x[_0x2f10[0x2e]]; i++) {
                    x = x + x[_0x2f10[0x121]](0x0, 0x1);
                    x = x[_0x2f10[0x121]](0x1);
                }
                if (x != last_str) {
                    last_str = x;
                    Local[b(m('0x1c4'))](x);
                }
                clantag_was_on = !![];
            } else {
                last_str = u;
                Local[m('0x51')](u);
            }
        }
        clantag_was_on = !![];
    } else {
        if (clantag_was_on) {
            if (b(m('0x21c')) !== m('0x186')) {
                gs_windows[_0x39e7x29][_0x2f10[0x21]] = ![];
            } else {
                clantag_was_on = ![];
                Local[m('0x51')](_0x2f10[0x1]);
            }
        }
    }
    _currentModifierKeys = UserCMD[b(m('0x5e'))]();
    indicators[_0x2f10[0x83]] = ![];
    if (settings[_0x2f10[0x83]] && UI[_0x2f10[0x118]][_0x2f10[0x70]](null, hotkeys[0x2]) && !(_currentModifierKeys & 0x1 << 0x3 || _currentModifierKeys & 0x1 << 0x4 || _currentModifierKeys & 0x1 << 0x9 || _currentModifierKeys & 0x1 << 0xa)) {
        if (b(m('0x238')) !== b(m('0x1a1'))) {
            var y = 0x1f4;
            var z = -0x1;
            r = Entity[m('0x262') + 'es']();
            for (i in r) {
                if (m('0x197') !== b(m('0x2ac'))) {
                    if (!Entity[m('0x4d')](r[i]) || Entity['IsDormant'](r[i]) || r[i] == q) {
                        continue;
                    }
                    if (playerlist_settings[r[i]]) {
                        var A = playerlist_settings[r[i]][_0x2f10[0xe0]];
                        if (A) {
                            if (m('0x333') === b(m('0x36e'))) {
                                gs_windows[gs_curwindow][_0x2f10[0x37]] = val;
                                gs_log(_0x2f10[0x38] + val);
                            } else {
                                continue;
                            }
                        }
                    }
                    var B = Entity[m('0x30c') + m('0x64')](r[i]);
                    var o = vec_sub(B, s);
                    var A = Math[_0x2f10[0xf9]](o[0x0], o[0x1]);
                    if (A < y) {
                        if (b(m('0x1e8')) !== b(m('0x1e8'))) {
                            Exploit[m('0x76') + m('0x3b5')](0xc);
                            Exploit[m('0x224') + m('0x286')](0x2);
                        } else {
                            y = A;
                            z = r[i];
                        }
                    }
                } else {
                    _0x39e7x50 = !![];
                }
            }
            if (z != -0x1) {
                if (m('0x134') === b(m('0x109'))) {
                    var C = !![];
                    var F = [];
                    for (_0x39e7xd in backtrack_info[r[_0x39e7x62]]) {
                        var H = backtrack_info[r[_0x39e7x62]][_0x39e7xd];
                        var I = Render[m('0x36d') + m('0x1ca')](H);
                        if (!C) {
                            Render[m('0x243')](I[0x0], I[0x1], F[0x0], F[0x1], [
                                0xff,
                                0xff,
                                0xff,
                                0xff
                            ]);
                        }
                        C = ![];
                        F = I;
                    }
                } else {
                    indicators[_0x2f10[0x83]] = !![];
                    if (Entity[m('0x3a8') + m('0xbc')](z)[0x2] < s[0x2]) {
                        var M = vecmulfl(Entity[b(m('0x297'))](z, _0x2f10[0x106], _0x2f10[0x114]), settings[_0x2f10[0xae]] / 0x64);
                        var N = Entity[b(m('0x250'))](z);
                        var O = vec_add(M, N);
                        var P = calcang(s, O)[0x1];
                        o = vec_sub(s, O);
                        A = Math[_0x2f10[0xf9]](o[0x0], o[0x1]) * settings[_0x2f10[0xaf]];
                        move_forward([
                            0x0,
                            P,
                            0x0
                        ], A);
                    } else {
                        if (m('0x1e6') === b(m('0x27f'))) {
                            var Q = Render[m('0x36d') + m('0x1ca')](Entity[m('0x30c') + m('0x64')](z));
                            o = Q[0x0] - Render[m('0x391') + m('0x1ff')]()[0x0] / 0x2;
                            var R = o / (Render[m('0x391') + m('0x1ff')]()[0x0] / 0x2);
                            var U = 0x0;
                            if (R > 0.005) {
                                if (b(m('0x11d')) !== b(m('0x11d'))) {
                                    gs_windows[gs_curwindow][_0x2f10[0x3a]][gs_curtab] = !![];
                                } else {
                                    U = 0x1c2;
                                }
                            }
                            if (R < -0.005) {
                                if (b(m('0x251')) !== m('0x2ed')) {
                                    _0x39e7x47 = _0x39e7x41;
                                } else {
                                    U = -0x1c2;
                                }
                            }
                            UserCMD[m('0x241') + 't']([
                                0x0,
                                U,
                                0x0
                            ]);
                        } else {
                            gs_curchild[_0x2f10[0x1f]] = _0x2f10[0x1];
                            gs_curchild[_0x2f10[0x2d]] = 0x0;
                            gs_isblocked = ![];
                        }
                    }
                }
            }
            r = Entity['GetEnemies']();
        } else {
            _0x39e7x63(_0x2f10[0x8b], [
                0x0,
                0xff,
                0x0,
                0xff
            ]);
        }
    }
    indicators[_0x2f10[0xf0]] = ![];
    if (settings[_0x2f10[0xad]] && UI[_0x2f10[0x118]][_0x2f10[0x70]](null, hotkeys[0x1]) && UI[m('0x279') + m('0x214')](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b])) {
        M = Entity[m('0x390')](q, _0x2f10[0x106], _0x2f10[0x114]);
        M[0x0] *= 0.2;
        M[0x1] *= 0.2;
        M[0x2] *= 0.2;
        M = vec_add(t, M);
        for (i in r) {
            if (!Entity[b(m('0x260'))](r[i]) || Entity[m('0xd4')](r[i])) {
                continue;
            }
            var V = Trace[m('0x243')](r[i], Entity[b(m('0x10b'))](r[i]), M);
            if (V && V[0x1] && V[0x1] == 0x1) {
                if (m('0x89') === b(m('0x379'))) {
                    selected_player = _0x39e7x61[_0x39e7x62];
                } else {
                    UI[m('0x116') + 'ey'](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
                    break;
                }
            }
        }
        indicators[_0x2f10[0xf0]] = !![];
    }
    for (i in r) {
        var W = r[i];
        if (playerlist_settings[W]) {
            if (!Entity[m('0x4d')](r[i]) || Entity[m('0xd4')](r[i])) {
                continue;
            }
            var X = playerlist_settings[W][_0x2f10[0xe4]];
            var Y = playerlist_settings[W][_0x2f10[0xe6]];
            var Z = playerlist_settings[W][_0x2f10[0xe7]];
            if (X) {
                Ragebot[m('0xcf') + 'tSafety'](W);
            }
            if (Y) {
                if (b(m('0x198')) !== b(m('0xc5'))) {
                    Ragebot[b(m('0x19a'))](W);
                } else {
                    do_circle(Entity[m('0x30c') + m('0x64')](r[_0x39e7x62]));
                }
            }
            if (Z) {
                Ragebot[m('0xcf') + 't'](W);
            }
        }
    }
    if (settings[_0x2f10[0x86]]) {
        if (b(m('0x221')) === 'mSnXQ') {
            _0x39e7x24[_0x2f10[0x1a]] = _0x39e7x24[_0x2f10[0x5c]] + 0xf;
        } else {
            knifebot();
        }
    }
    if (settings[_0x2f10[0xb1]]) {
        if (b('0xa') === m('0x114')) {
            i = 0x1;
            for (; i < 0xc; i++) {
                Ragebot[m('0x1e2') + 'xSafety'](i);
            }
        } else {
            gs_curchild[_0x2f10[0x30]][gs_curchild[_0x2f10[0x2c]][i]] = ![];
        }
    }
    if (settings[_0x2f10[0xb2]]) {
        if (b(m('0x317')) !== m('0x203')) {
            _currentModifierKeys = _currentModifierKeys | (_0x39e7xe5 ? 0x800 : 0x1);
            var a0 = Exploit[m('0x3b1')]() == 0x1 && UI[m('0x279') + 'tive'](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
            if (_currentModifierKeys & 0x1 && a0 && UI[_0x2f10[0x9e]][_0x2f10[0x70]](null, settings) & 0x4) {
                UI[b(m('0x2dc'))](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
            }
            _0x39e7xe4 = !![];
        } else {
            var a1 = Local[m('0x252')]();
            var A = Local[m('0x305')]();
            o = a1 - A;
            o = normalize(o);
            if (Math[_0x2f10[0xf8]](o) > 0x3a) {
                if (globals[_0x2f10[0x123]][_0x2f10[0x122]] > Globals[m('0x1ad') + m('0x1ea')]()) {
                    if (m('0x126') === b(m('0x17e'))) {
                        _0x39e7xe8 = ![];
                        var a2 = Local[m('0xd5') + m('0x173')]();
                        var a3 = vec_sub(ac, a2);
                        a3[0x1] = normalize(a3[0x1]);
                        if (Math[_0x2f10[0xf9]](a3[0x0], a3[0x1]) < 0xf) {
                            _0x39e7xe8 = !![];
                        }
                        a3 = vecmulfl(a3, Math[_0x2f10[0x10c]]() * 0.15 + 0.2);
                        a3 = vec_add(a3, a2);
                        ac = a3;
                    } else {
                        globals[_0x2f10[0x123]][_0x2f10[0x124]] = !globals[_0x2f10[0x123]][_0x2f10[0x124]];
                        UI[m('0x116') + 'ey'](_0x2f10[0xfb], _0x2f10[0x125], _0x2f10[0x126]);
                    }
                }
                globals[_0x2f10[0x123]][_0x2f10[0x122]] = Globals[b(m('0x1c3'))]();
                UI[b(m('0x163'))](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], globals[_0x2f10[0x123]][_0x2f10[0x124]] ? 0x0 : 0xb4);
            } else {
                if (m('0x386') !== b(m('0x94'))) {
                    gs_keystates2[i] = ![];
                } else {
                    UI[b(m('0x163'))](_0x2f10[0xfb], _0x2f10[0xfc], _0x2f10[0xfd], 0x0);
                }
            }
        }
    }
    indicators[_0x2f10[0x8b]] = ![];
    if (settings[_0x2f10[0x8b]] && UI[_0x2f10[0x118]][_0x2f10[0x70]](null, hotkeys[0x3])) {
        var a5 = Entity[m('0x12') + m('0xed')](0x8e);
        y = 0x78;
        z = -0x1;
        var a6 = [];
        for (i in a5) {
            if (b(m('0x2f4')) === b(m('0x2d0'))) {
                effects[_0x39e7x62][0x1] += Globals[m('0x1c0')]() * 0x3e8;
                if (effects[_0x39e7x62][0x1] > 0xff && effects[_0x39e7x62][0x6] == 0x0) {
                    effects[_0x39e7x62][0x1] = 0xff;
                    effects[_0x39e7x62][0x6] = Globals[m('0x2d5')]();
                    effects[_0x39e7x62][0x2] = ![];
                }
            } else {
                var a7 = average_collisions_and_rotate(a5[i], Entity[m('0x390')](a5[i], _0x2f10[0x106], _0x2f10[0x10e])[0x1]);
                var a8 = vec_len(vec_sub(s, a7));
                if (a8 < y) {
                    y = a8;
                    z = a5[i];
                    a6 = a7;
                }
            }
        }
        if (z != -0x1) {
            var aa = Entity[m('0x390')](q, _0x2f10[0xfe], _0x2f10[0x105]) * Globals[m('0x34f') + 'al']();
            var ab = Entity[m('0x390')](Entity[m('0x74')](q), _0x2f10[0x102], _0x2f10[0x103]) <= aa && Entity[m('0x390')](Entity[m('0x74')](q), _0x2f10[0x102], _0x2f10[0x127]) > 0x0;
            if (!(UserCMD[m('0x5f')]() & 0x1 && ab || UserCMD[m('0x5f')]() & 0x1 << 0xb && Entity[b(m('0x389'))](Entity[m('0x74')](q))[_0x2f10[0x101]](_0x2f10[0x100]))) {
                if (b(m('0x201')) === m('0x96')) {
                    UserCMD[b(m('0x2ae'))](0x1 << 0x2);
                    throwing = ![];
                    return;
                } else {
                    var ac = calcang(t, a6);
                    UserCMD[m('0x77') + m('0x173')](ac, !![]);
                }
            }
            if (globals[_0x2f10[0x8b]][_0x2f10[0x124]] && !(UserCMD[m('0x5f')]() & 0x1 && ab || UserCMD[b(m('0x5e'))]() & 0x1 << 0xb && Entity[m('0x151')](Entity[b(m('0x27c'))](q))[_0x2f10[0x101]](_0x2f10[0x100]))) {
                UserCMD[b(m('0x2ae'))](UserCMD[m('0x5f')]() | 0x1 << 0x5);
                globals[_0x2f10[0x8b]][_0x2f10[0x128]] = !![];
                globals[_0x2f10[0x8b]][_0x2f10[0x10d]] = z;
            }
            indicators[_0x2f10[0x8b]] = !![];
            globals[_0x2f10[0x8b]][_0x2f10[0x124]] = !globals[_0x2f10[0x8b]][_0x2f10[0x124]];
        }
    } else {
        if (globals[_0x2f10[0x8b]][_0x2f10[0x128]]) {
            if (globals[_0x2f10[0x8b]][_0x2f10[0x129]] > 0x5 && is_door_opening(globals[_0x2f10[0x8b]][_0x2f10[0x10d]])) {
                if (m('0x395') !== b(m('0x30'))) {
                    _0x39e7xab = ray_end(_0x39e7xa6, _0x39e7xa5, _0x39e7xad);
                } else {
                    a6 = average_collisions_and_rotate(globals[_0x2f10[0x8b]][_0x2f10[0x10d]], Entity[m('0x390')](globals[_0x2f10[0x8b]][_0x2f10[0x10d]], _0x2f10[0x106], _0x2f10[0x10e])[0x1]);
                    ac = calcang(t, a6);
                    UserCMD[m('0x77') + m('0x173')](ac, !![]);
                    UserCMD[m('0x370')](UserCMD[m('0x5f')]() | 0x1 << 0x5);
                    globals[_0x2f10[0x8b]][_0x2f10[0x10d]] = 0x0;
                    globals[_0x2f10[0x8b]][_0x2f10[0x128]] = ![];
                    globals[_0x2f10[0x8b]][_0x2f10[0x129]] = 0x0;
                }
            }
            globals[_0x2f10[0x8b]][_0x2f10[0x129]]++;
        }
    }
    if (settings[_0x2f10[0x8d]]) {
        autostrafer();
    }
    if (settings[_0x2f10[0xb5]] && UI[_0x2f10[0x118]][_0x2f10[0x70]](null, hotkeys[0x4])) {
        if (b(m('0x119')) === b(m('0x2de'))) {
            return [
                a7[0x0] - _0x39e7x34[0x0],
                a7[0x1] - _0x39e7x34[0x1],
                a7[0x2] - _0x39e7x34[0x2]
            ];
        } else {
            grenade_griefer();
        }
    } else {
        jumping = ![];
    }
    if (settings[_0x2f10[0xb6]]) {
        var ad = 0xc;
        if (UI[m('0x2c3')](_0x2f10[0xc9], _0x2f10[0x109], _0x2f10[0x12a], _0x2f10[0x12b])) {
            ad = ad + 0xc;
        }
        if (Exploit[m('0x3b1')]() == 0x1 && !Entity[m('0x151')](Entity[m('0x74')](q))[_0x2f10[0x101]](_0x2f10[0x100])) {
            if (m('0x18b') !== m('0x292')) {
                ad = ad + 0x8;
            } else {
                _0x39e7x24[_0x2f10[0x19]] = _0x39e7x24[_0x2f10[0x19]] - (_0x39e7x24[_0x2f10[0x19]] + _0x39e7x24[_0x2f10[0x17]] + 0x19 - _0x39e7x23[_0x2f10[0x19]]);
            }
        }
        for (i in r) {
            if (settings[_0x2f10[0xb6]] && Entity[m('0x4d')](r[i]) && !Entity['IsDormant'](r[i])) {
                var ae = Entity[b(m('0xb3'))](r[i], 0x0);
                if (!backtrack_info[r[i]]) {
                    backtrack_info[r[i]] = [];
                }
                backtrack_info[r[i]][_0x2f10[0x6f]](ae);
                for (; backtrack_info[r[i]][_0x2f10[0x2e]] > ad;) {
                    backtrack_info[r[i]][_0x2f10[0x12c]]();
                }
            } else {
                if (m('0x29c') === m('0x229')) {
                    Render[m('0x167') + 'ct'](_0x39e7xd, _0x39e7xe, _0x39e7xf, ae, _0x39e7x13 ? 0x0 : 0x1, _0x39e7x11, _0x39e7x12);
                } else {
                    backtrack_info[r[i]] = [];
                }
            }
        }
    }
    if (settings[_0x2f10[0xba]] && UI[_0x2f10[0x118]][_0x2f10[0x70]](null, hotkeys[0x5])) {
        if ('NSPUX' === m('0x29e')) {
            _currentModifierKeys = _currentModifierKeys | 0x800;
            var af = Exploit[m('0x3b1')]() == 0x1 && UI[b(m('0x19e'))](_0x2f10[0x108], _0x2f10[0x109], _0x2f10[0x10a], _0x2f10[0x10b]);
            _0x39e7xe4 = !![];
        } else {
            for (i in r) {
                if (last_ent_shot == r[i]) {
                    last_ent_shot = -0x1;
                    continue;
                }
                Ragebot[b(m('0x19a'))](r[i]);
            }
        }
    }
}
function weapon_fire() {
    last_ent_shot = Entity[m('0x374') + m('0x42')](Event[b(m('0x121'))](_0x2f10[0x12d]));
}
var effects = [];
function unload() {
    Exploit[b(m('0x168'))](0xc);
    Exploit[m('0x224') + m('0x286')](0x2);
}
var kills = 0x0;
var texts = [
    _0x2f10[0x12e],
    _0x2f10[0x12f],
    _0x2f10[0x130],
    _0x2f10[0x131],
    _0x2f10[0x132],
    _0x2f10[0x133]
];
function player_death() {
    if (Entity[b(m('0x104'))](Event[b(m('0x121'))](_0x2f10[0x134])) == Entity[b(m('0x32c'))]() && settings[_0x2f10[0xa4]]) {
        if (m('0x357') !== m('0x1ac')) {
            if (kills > texts[_0x2f10[0x2e]]) {
                kills = texts[_0x2f10[0x2e]];
            }
            var n = Render[b(m('0x3f'))]()[0x0] / 0x2;
            var o = Render[b(m('0x3f'))]()[0x1] / 0x2;
            effects[_0x2f10[0x6f]]([
                texts[kills],
                0x0,
                !![],
                n,
                o,
                Math[_0x2f10[0x10c]]() * 0x168,
                0x0,
                0x12c,
                !![],
                [
                    Math[_0x2f10[0x10c]]() * 0xff / 0x2 + 0xff / 0x2,
                    Math[_0x2f10[0x10c]]() * 0xff / 0x2 + 0xff / 0x2,
                    Math[_0x2f10[0x10c]]() * 0xff / 0x2 + 0xff / 0x2
                ]
            ]);
            kills++;
        } else {
            last_ent_shot = Entity[b('0xbc')](Event[m('0x1da')](_0x2f10[0x12d]));
        }
    }
}
function rroundstart() {
    if (settings[_0x2f10[0xa4]]) {
        kills = 0x0;
    }
}
Cheat[b(m('0x1b8'))](_0x2f10[0x59], _0x2f10[0x135]);
Cheat[m('0x4b') + m('0x2b8')](_0x2f10[0x136], _0x2f10[0x137]);
Cheat[b(m('0x1b8'))](_0x2f10[0x138], _0x2f10[0x138]);
Cheat[m('0x4b') + m('0x2b8')](_0x2f10[0x139], _0x2f10[0x13a]);
Cheat[b(m('0x1b8'))](_0x2f10[0x13b], _0x2f10[0x13c]);
UI.AddMultiDropdown( "AutoMindmg weapons", [ "Auto", "AWP", "R8", "Duals" ] );
UI.AddLabel("(more like better dynamic mindmg)")
UI.AddHotkey("Dynamic DT hc");
UI.AddMultiDropdown( "Dynamic DT hc weapons", [ "Auto", "R8", "Duals" ] );

function onCM(){
    inaccuracy = Local.GetInaccuracy();
    spread = Local.GetSpread();
    localPlayer_index = Entity.GetLocalPlayer();
    localPlayer_eyepos = Entity.GetEyePosition(localPlayer_index);
    const aumnwp = UI.GetValue("AutoMindmg weapons");
    var localplayer_index = Entity.GetLocalPlayer( );
    var localplayer_weapon = Entity.GetWeapon(localplayer_index);
    var weapon_name = Entity.GetName(localplayer_weapon);
    var target = Ragebot.GetTarget()
    var enemy_player_weapon = Entity.GetWeapon(target);
    var enemy_weapon_name = Entity.GetName(enemy_player_weapon);
    var health = Entity.GetProp(target, "CBasePlayer", "m_iHealth")
    var charge = Exploit.GetCharge()
    var active = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && charge == 1
    for ( i = 0; i < target.length; i++){
        hitbox_pos_head = Entity.GetHitboxPosition(target[i], 0);
        hitbox_pos_body = Entity.GetHitboxPosition(target[i], 3);
        hitbox_pos_thorax = Entity.GetHitboxPosition(target[i], 4);
        hitbox_pos_chest = Entity.GetHitboxPosition(target[i], 5);
        hitbox_pos_upp_chest = Entity.GetHitboxPosition(target[i], 6);
        result_head = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_head);
        result_body = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_body);
        result_thorax = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_thorax);
        result_chest = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_chest);
        result_upp_chest = Trace.Line(localPlayer_index, localPlayer_eyepos, hitbox_pos_upp_chest);
    }
    if(result_head == undefined)return;
    if(result_body == undefined)return;
    if(result_thorax == undefined)return;
    if(result_chest == undefined)return;
    if(result_upp_chest == undefined)return;
    for (k = 0; k < 12; k++)   {
        if(active && inaccuracy > 0.3 && spread > 0.3 && aumnwp & (1 << 0) && (weapon_name == "scar 20" || weapon_name == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 3)}
        else if(active && inaccuracy < 0.3 && spread < 0.3 && aumnwp & (1 << 0) && (weapon_name == "scar 20" || weapon_name == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, (health / 2) + 3)}
        else if(UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && aumnwp & (1 << 0) && (weapon_name == "scar 20" || weapon_name == "g3sg1") && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health)}
        else if(inaccuracy > 0.5 && spread > 0.5 && aumnwp & (1 << 2) && weapon_name == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 3)}
        else if(inaccuracy > 0.2 && spread > 0.2 && aumnwp & (1 << 2) && weapon_name == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 2)}
        else if(inaccuracy < 0.15 && spread < 0.15 && aumnwp & (1 << 2) && weapon_name == "r8 revolver" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health)}
        else if((result_head > 0.80 || result_body > 0.85 || result_thorax > 0.85 || result_chest > 0.85 || result_upp_chest > 0.85) && aumnwp & (1 << 1) && weapon_name == "awp" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health)}
        else if((result_head < 0.80 || result_body < 0.85 || result_thorax < 0.85 || result_chest < 0.85 || result_upp_chest < 0.85) && aumnwp & (1 << 1) && weapon_name == "awp" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health * 0.75)}
        else if(health <= 50 && aumnwp & (1 << 4) && weapon_name == "dual berretas" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 3)}
        else if(inaccuracy < 0.4 && spread < 0.4 && aumnwp & (1 << 3) && weapon_name == "dual berretas" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 4)}
        else if(inaccuracy > 0.4 && spread > 0.4 && aumnwp & (1 << 3) && weapon_name == "dual berretas" && Entity.IsAlive(target) && Entity.IsValid(target)){
            Ragebot.OverrideMinimumDamage(k, health / 5)}
}
}

function dtHC(){
    inaccuracy = Local.GetInaccuracy();
    spread = Local.GetSpread();
    const dthcwp = UI.GetValue("AutoMindmg weapons");
    var localplayer_index = Entity.GetLocalPlayer( );
    var localplayer_weapon = Entity.GetWeapon(localplayer_index);
    var weapon_name = Entity.GetName(localplayer_weapon);
    var target = Ragebot.GetTarget()
    var enemy_player_weapon = Entity.GetWeapon(target);
    var enemy_weapon_name = Entity.GetName(enemy_player_weapon);
    var active2 = UI.IsHotkeyActive("Rage", "GENERAL", "Exploits", "Doubletap") && charge == 1 && UI.IsHotkeyActive("Dynamic DT hc");
    var dthcc = UI.GetValue(exploits, "Doubletap hitchance");
    if(active2 && inaccuracy > 0.4 && spread > 0.4 && (weapon_name == "scar 20" || weapon_name == "g3sg1" || weapon_name == "r8 revolver") && aumnwp & (1 << 0))
        Ragebot.OverrideHitchance((inaccuracy/2.35)*100 + (spread/2.35)*100);
    else if(active2 && inaccuracy > 0.2 && spread > 0.2 && (weapon_name == "scar 20" || weapon_name == "g3sg1" || weapon_name == "r8 revolver") && aumnwp & (1 << 0))
        Ragebot.OverrideHitchance((inaccuracy/2.85)*100 + (spread/2.85)*100);
    else if(active2 && inaccuracy < 0.2 && spread < 0.2 && (weapon_name == "scar 20" || weapon_name == "g3sg1" || weapon_name == "r8 revolver") && aumnwp & (1 << 0))
        Ragebot.OverrideHitchance(5);
    else if(active2 && inaccuracy > 0.4 && spread > 0.4 && weapon_name == "r8 revolver" && aumnwp & (1 << 1))
        Ragebot.OverrideHitchance((inaccuracy/2.35)*100 + (spread/2.35)*100);
    else if(active2 && inaccuracy > 0.2 && spread > 0.2 && weapon_name == "r8 revolver" && aumnwp & (1 << 1))
        Ragebot.OverrideHitchance((inaccuracy/2.85)*100 + (spread/2.85)*100);
    else if(active2 && inaccuracy < 0.2 && spread < 0.2 && weapon_name == "r8 revolver" && aumnwp & (1 << 1))
        Ragebot.OverrideHitchance(5);
    else if(active2 && inaccuracy > 0.4 && spread > 0.4 && weapon_name == "dual berretas" && aumnwp & (1 << 2))
        Ragebot.OverrideHitchance((inaccuracy/2.2)*100 + (spread/2.2)*100);
    else if(active2 && inaccuracy > 0.2 && spread > 0.2 && weapon_name == "dual berretas" && aumnwp & (1 << 2))
        Ragebot.OverrideHitchance((inaccuracy/2.5)*100 + (spread/2.5)*100);
    else if(active2 && inaccuracy < 0.2 && spread < 0.2 && weapon_name == "dual berretas" && aumnwp & (1 << 2))
        Ragebot.OverrideHitchance(10);
}


Cheat.RegisterCallback("CreateMove", "onCM", "dtHC")
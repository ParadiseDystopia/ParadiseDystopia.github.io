function VisualsWeapons() 
{
    localplayer_index = Entity.GetLocalPlayer( );
    localplayer_weapon = Entity.GetWeapon(localplayer_index);
    weapon_name = Entity.GetName(localplayer_weapon);
}

function Colors() 
{

    //others
    var scriptitems = ["Misc", "JAVASCRIPT", "Script Items"];
    var enabled = UI.GetValue(scriptitems, "Visuals Colors Enable");

    autovisiblecolor =  UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible Auto Color")
    scoutvisiblecolor  = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible Scout Color")
    awpvisiblecolor  = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible AWP Color")
    //hidden
    autohiddencolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden Auto Color")
    scouthiddencolor  = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden Scout Color")
    awphiddenecolor  = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden AWP Color")
    //transparency VISIBLE
    autotransparencyvisible = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale Auto Visible")
    scouttransparencyvisible = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale Scout Visible")
    awptransparencyvisible = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale AWP Visible")
    //transparency HIDDEN
    autotransparencyhidden = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale Auto Hidden")
    scouttransparencyhidden = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale Scout Hidden")
    awptransparencyhidden = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Transparency Scale AWP Hidden")

    //type chams
    var typevisibleauto = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Visible Auto Type" );
    var typevisiblescout = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Visible Scout Type" );
    var typevisibleawp = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Visible AWP Type" );

    var typehiddenauto = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hidden Auto Type" );
    var typehiddenscout = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hidden Scout Type" );
    var typehiddenawp = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Hidden AWP Type" );

    //ESP
    // Auto ESP
    autoboxcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Box Auto Color")
    autoglowcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Glow Auto Color")
    autonamecolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Name Auto Color")
    autohealthcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Health Auto Color")
    autoammocolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Ammo Auto Color")
    autoskeletoncolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Skeleton Auto Color")
    //HUD
    autooutoffovcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Out of fov Auto Color")
    autofootstepscolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Footsteps Auto Color")
    
    // Scout ESP
    scoutboxcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Box Scout Color")
    scoutglowcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Glow Scout Color")
    scoutnamecolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Name Scout Color")
    scouthealthcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Health Scout Color")
    scoutammocolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Ammo Scout Color")
    scoutskeletoncolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Skeleton Scout Color")
    //HUD
    scoutoutoffovcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Out of fov Scout Color")
    scoutfootstepscolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Footsteps Scout Color")
    
    // AWP ESP
    awpnamecolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Name AWP Color")
    awpboxcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Box AWP Color")
    awpglowcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Glow AWP Color")
    awpnamecolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Name AWP Color")
    awphealthcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Health AWP Color")
    awpammocolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Ammo AWP Color")
    awpskeletoncolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Skeleton AWP Color")
    //HUD
    awpoutoffovcolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Out of fov AWP Color")
    awpfootstepscolor = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Footsteps AWP Color")
    
    //other

    autovisiblecolorsecvis = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible Auto Color (secondary)")
    autovisiblecolorsechid = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden Auto Color (secondary)")

    scoutvisiblecolorsecvis = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible Scout Color (secondary)")
    scoutvisiblecolorsechid = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden Scout Color (secondary)")

    awpvisiblecolorsecvis = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Visible AWP Color (secondary)")
    awpvisiblecolorsechid = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Hidden AWP Color (secondary)")

    if(enabled)
    {

        // AUTO
    if(weapon_name == "scar 20" || weapon_name == "g3sg1") {
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color",  autovisiblecolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color (secondary)",  autovisiblecolorsecvis);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color",  autohiddencolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color (secondary)",  autovisiblecolorsechid);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Visible transparency", autotransparencyvisible);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden transparency", autotransparencyhidden);
        
        //ESP
        UI.SetColor("Visual", "ENEMIES", "ESP", "Box", autoboxcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Glow", autoglowcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Name", autonamecolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Health color override", autohealthcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Ammo", autoammocolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Skeleton", autoskeletoncolor)
        //HUD
        UI.SetColor("Visual", "ENEMIES", "HUD", "Out of fov", autooutoffovcolor)
        UI.SetColor("Visual", "ENEMIES", "HUD", "Footsteps", autofootstepscolor)

        //type
        if (typevisibleauto == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        //hidden
        if (typehiddenauto == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
    }
    //SCOUT
    if(weapon_name == "ssg 08") {
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color",  scoutvisiblecolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color (secondary)",  scoutvisiblecolorsecvis);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color",  scouthiddencolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color (secondary)",  scoutvisiblecolorsechid);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Visible transparency", scouttransparencyvisible);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden transparency", scouttransparencyhidden);
        
        //ESP
        UI.SetColor("Visual", "ENEMIES", "ESP", "Box", scoutboxcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Glow", scoutglowcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Name", scoutnamecolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Health color override", scouthealthcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Ammo", scoutammocolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Skeleton", scoutskeletoncolor)
        //HUD
        UI.SetColor("Visual", "ENEMIES", "HUD", "Out of fov", scoutoutoffovcolor)
        UI.SetColor("Visual", "ENEMIES", "HUD", "Footsteps", scoutfootstepscolor)

        //type
        if (typevisiblescout == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        if (typevisiblescout == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        if (typevisiblescout == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        if (typevisiblescout == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        if (typevisiblescout == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        if (typevisiblescout == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisiblescout) }
        //type hidden
        if (typehiddenscout == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
        if (typehiddenscout == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
        if (typehiddenscout == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
        if (typehiddenscout == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
        if (typehiddenscout == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
        if (typehiddenscout == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenscout) }
    }
    //AWP
    if(weapon_name == "awp") {
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color",  awpvisiblecolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color (secondary)",  awpvisiblecolorsecvis);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color",  awphiddenecolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color (secondary)",  awpvisiblecolorsechid);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Visible transparency", awptransparencyvisible);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden transparency", awptransparencyhidden);

        //ESP
        UI.SetColor("Visual", "ENEMIES", "ESP", "Box", awpboxcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Glow", awpglowcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Name", awpnamecolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Health color override", awphealthcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Ammo", awpammocolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Skeleton", awpskeletoncolor)
        //HUD
        UI.SetColor("Visual", "ENEMIES", "HUD", "Out of fov", awpoutoffovcolor)
        UI.SetColor("Visual", "ENEMIES", "HUD", "Footsteps", awpfootstepscolor)

        //type
        if (typevisibleawp == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        if (typevisibleawp == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        if (typevisibleawp == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        if (typevisibleawp == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        if (typevisibleawp == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        if (typevisibleawp == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleawp) }
        
        if (typehiddenawp == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
        if (typehiddenawp == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
        if (typehiddenawp == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
        if (typehiddenawp == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
        if (typehiddenawp == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
        if (typehiddenawp == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenawp) }
    }

}
}

function menu_close(){

    var scriptitems = ["Misc", "JAVASCRIPT", "Script Items"];
    var enabledui = UI.GetValue(scriptitems, "Visuals Colors Menu");
    var enabledauto = UI.GetValue(scriptitems, "Auto Visuals");
    var enabledscout = UI.GetValue(scriptitems, "Scout Visuals");
    var enabledawp = UI.GetValue(scriptitems, "AWP Visuals");

    UI.SetEnabled(scriptitems, "Auto Visuals", enabledui)
    UI.SetEnabled(scriptitems, "Scout Visuals", enabledui)
    UI.SetEnabled(scriptitems, "AWP Visuals", enabledui)
    UI.SetEnabled(scriptitems, "-----------------------------------------      ", enabledui);
    //menu
    
    //auto
    UI.SetEnabled(scriptitems, "-----------------------------------------       ", enabledauto)
    UI.SetEnabled(scriptitems, "           -Auto Color-", enabledauto);
    UI.SetEnabled(scriptitems, "Visible Auto Type", enabledauto);
    UI.SetEnabled(scriptitems, "Hidden Auto Type", enabledauto);
    UI.SetEnabled(scriptitems, "Visible Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Visible Auto Color (secondary)", enabledauto); 
    UI.SetEnabled(scriptitems, "Hidden Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Hidden Auto Color (secondary)", enabledauto); 
    UI.SetEnabled(scriptitems, "Transparency Scale Auto Visible", enabledauto);
    UI.SetEnabled(scriptitems, "Transparency Scale Auto Hidden", enabledauto);
    UI.SetEnabled(scriptitems, "Box Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Glow Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Name Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Health Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Ammo Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Skeleton Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "                     -HUD-", enabledauto);
    UI.SetEnabled(scriptitems, "Out of fov Auto Color", enabledauto);
    UI.SetEnabled(scriptitems, "Footsteps Auto Color", enabledauto);

    //scout
    UI.SetEnabled(scriptitems, "-----------------------------------------        ", enabledscout)
    UI.SetEnabled(scriptitems, "           -Scout Color-", enabledscout);
    UI.SetEnabled(scriptitems, "Visible Scout Type", enabledscout);
    UI.SetEnabled(scriptitems, "Visible Scout Color (secondary)", enabledscout); 
    UI.SetEnabled(scriptitems, "Hidden Scout Type", enabledscout);
    UI.SetEnabled(scriptitems, "Hidden Scout Color (secondary)", enabledscout); 
    UI.SetEnabled(scriptitems, "Visible Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Hidden Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Transparency Scale Scout Visible", enabledscout);
    UI.SetEnabled(scriptitems, "Transparency Scale Scout Hidden", enabledscout);
    UI.SetEnabled(scriptitems, "Box Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Glow Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Name Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Health Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Ammo Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Skeleton Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "                     -HUD- ", enabledscout);
    UI.SetEnabled(scriptitems, "Out of fov Scout Color", enabledscout);
    UI.SetEnabled(scriptitems, "Footsteps Scout Color", enabledscout);
    
    //awp
    UI.SetEnabled(scriptitems, "-----------------------------------------         ", enabledawp)
    UI.SetEnabled(scriptitems, "           -AWP Settings-", enabledawp);
    UI.SetEnabled(scriptitems, "Visible AWP Type", enabledawp);
    UI.SetEnabled(scriptitems, "Visible AWP Color (secondary)", enabledawp); 
    UI.SetEnabled(scriptitems, "Hidden AWP Type", enabledawp);
    UI.SetEnabled(scriptitems, "Hidden AWP Color (secondary)", enabledawp); 
    UI.SetEnabled(scriptitems, "Visible AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Hidden AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Transparency Scale AWP Visible", enabledawp);
    UI.SetEnabled(scriptitems, "Transparency Scale AWP Hidden", enabledawp);
    UI.SetEnabled(scriptitems, "Box AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Glow AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Name AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Health AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Ammo AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Skeleton AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "                     -HUD-  ", enabledawp);
    UI.SetEnabled(scriptitems, "Out of fov AWP Color", enabledawp);
    UI.SetEnabled(scriptitems, "Footsteps AWP Color", enabledawp);
}

function ColorEnabled(){
    menu_close();
}

function main()
{
    UI.AddLabel("-----------------------------------------");
    UI.AddCheckbox("Visuals Colors Enable");
    UI.AddCheckbox("Visuals Colors Menu");
    UI.AddLabel("-----------------------------------------      ");
    UI.AddCheckbox("Auto Visuals");
    UI.AddCheckbox("Scout Visuals");
    UI.AddCheckbox("AWP Visuals");
    //auto
    UI.AddLabel("-----------------------------------------       ");
    UI.AddLabel("           -Auto Color-");
    UI.AddDropdown( "Visible Auto Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddDropdown( "Hidden Auto Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddColorPicker("Visible Auto Color");
    UI.AddColorPicker("Visible Auto Color (secondary)");
    UI.AddColorPicker("Hidden Auto Color");
    UI.AddColorPicker("Hidden Auto Color (secondary)");
    UI.AddSliderInt("Transparency Scale Auto Visible", 0, 100);
    UI.AddSliderInt("Transparency Scale Auto Hidden", 0, 100);
    UI.AddColorPicker("Box Auto Color")
    UI.AddColorPicker("Glow Auto Color")
    UI.AddColorPicker("Name Auto Color")
    UI.AddColorPicker("Health Auto Color")
    UI.AddColorPicker("Ammo Auto Color")
    UI.AddColorPicker("Skeleton Auto Color")
    UI.AddLabel("                     -HUD-")
    UI.AddColorPicker("Out of fov Auto Color")
    UI.AddColorPicker("Footsteps Auto Color")

    //scout
    UI.AddLabel("-----------------------------------------        ");
    UI.AddLabel("           -Scout Color-")
    UI.AddDropdown( "Visible Scout Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddDropdown( "Hidden Scout Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddColorPicker("Visible Scout Color");
    UI.AddColorPicker("Visible Scout Color (secondary)");
    UI.AddColorPicker("Hidden Scout Color");
    UI.AddColorPicker("Hidden Scout Color (secondary)");
    UI.AddSliderInt("Transparency Scale Scout Visible", 0, 100);
    UI.AddSliderInt("Transparency Scale Scout Hidden", 0, 100);
    UI.AddColorPicker("Box Scout Color")
    UI.AddColorPicker("Glow Scout Color")
    UI.AddColorPicker("Name Scout Color")
    UI.AddColorPicker("Health Scout Color")
    UI.AddColorPicker("Ammo Scout Color")
    UI.AddColorPicker("Skeleton Scout Color")
    UI.AddLabel("                     -HUD- ")
    UI.AddColorPicker("Out of fov Scout Color")
    UI.AddColorPicker("Footsteps Scout Color")

    //awp
    UI.AddLabel("-----------------------------------------         ");
    UI.AddLabel("           -AWP Settings-");
    UI.AddDropdown( "Visible AWP Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddDropdown( "Hidden AWP Type", [ "Custom", "Flat", "Pulse", "Wireframe","Glow", "Glow (two-color)" ] );
    UI.AddColorPicker("Visible AWP Color");
    UI.AddColorPicker("Visible AWP Color (secondary)");
    UI.AddColorPicker("Hidden AWP Color");
    UI.AddColorPicker("Hidden AWP Color (secondary)");
    UI.AddSliderInt("Transparency Scale AWP Visible", 0, 100);
    UI.AddSliderInt("Transparency Scale AWP Hidden", 0, 100);
    UI.AddColorPicker("Box AWP Color")
    UI.AddColorPicker("Glow AWP Color")
    UI.AddColorPicker("Name AWP Color")
    UI.AddColorPicker("Health AWP Color")
    UI.AddColorPicker("Ammo AWP Color")
    UI.AddColorPicker("Skeleton AWP Color")
    UI.AddLabel("                     -HUD-  ")
    UI.AddColorPicker("Out of fov AWP Color")
    UI.AddColorPicker("Footsteps AWP Color")
    UI.AddLabel("-----------------------------------------");
    
    //callback
    Cheat.RegisterCallback("Draw", "VisualsWeapons");
    Cheat.RegisterCallback("Draw", "Colors");
    Cheat.RegisterCallback("Draw","ColorEnabled");
}
main()

/*

Things to do!

Add ESP & HUD to AWP
Add hidden type to AWP

*/

//coding
/*
    if(weapon_name == "g3sg1") {
        UI.SetColor("Visual", "ENEMIES", "Chams", "Visible Color",  autovisiblecolor);
        UI.SetColor("Visual", "ENEMIES", "Chams", "Hidden Color",  autohiddencolor);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Visible transparency", autotransparencyvisible);
        UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden transparency", autotransparencyhidden);
        
        //ESP
        UI.SetColor("Visual", "ENEMIES", "ESP", "Box", autoboxcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Glow", autoglowcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Name", autonamecolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Health color override", autohealthcolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Ammo", autoammocolor)
        UI.SetColor("Visual", "ENEMIES", "ESP", "Skeleton", autoskeletoncolor)
        //HUD
        UI.SetColor("Visual", "ENEMIES", "HUD", "Out of fov", autooutoffovcolor)
        UI.SetColor("Visual", "ENEMIES", "HUD", "Footsteps", autofootstepscolor)

        //type
        if (typevisibleauto == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        if (typevisibleauto == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Visible type", typevisibleauto) }
        //hidden
        if (typehiddenauto == 0) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 1) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 2) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 3) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 4) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
        if (typehiddenauto == 5) { UI.SetValue("Visual", "ENEMIES", "Chams", "Hidden type", typehiddenauto) }
    }
*/
